
import azure.functions as func
from SaveMetadataAndClauseValidationResult.SaveMetadataAndClauseValidationResult import sql_metadata_bp
from SaveUserFeedback.SaveUserFeedback import sql_feedback_bp
from UpdateWaiverReviewFile.UpdateWaiverReviewFile import upload_bp
from ProcessClauseValidationAndGetResult.ProcessClauseValidationAndGetResult import waiver_review_bp

##A1

app = func.FunctionApp(http_auth_level=func.AuthLevel.ANONYMOUS)

app.register_functions(sql_metadata_bp)
app.register_functions(sql_feedback_bp)
app.register_functions(upload_bp)
app.register_functions(waiver_review_bp)


