## Import Libraries
# Import Azure libraries

import azure.functions as func
from azure.identity import DefaultAzureCredential

# Import other libraries
import os
import logging
import urllib.request
import json
import ast
import ssl
import datetime
from pytz import timezone
import pyodbc, struct

# Declare function blueprint to create a separate route for the ProcessClauseValidationAndGetResult Azurefunction
waiver_review_bp = func.Blueprint() 

def getManagedIdentityToken():
    '''
    Function to fetch the access token for Azure function to get authenticated to access the AML Endpoint
 
        Parameters:
        - None
 
        return:
        - access token for the authentication
    '''
    objCredential = DefaultAzureCredential()
    objAccessToken = objCredential.get_token('https://ml.azure.com/')
    objAccessToken = objAccessToken[0]
    
    return objAccessToken

def allowSelfSignedHttps(allowed):
    '''
    Function to bypass the server certificate verification on client side
 
        Parameters:
        - True / False 
 
        return:
        - None
    '''

    if allowed and not os.environ.get('PYTHONHTTPSVERIFY', '') and getattr(ssl, '_create_unverified_context', None):
        ssl._create_default_https_context = ssl._create_unverified_context

def getCurrentTime():
    '''
    Function to capture the current time and return the current time in the format MM-DD-YYYY HH:MM:SS
 
        Parameters:
        - None
 
        return:
        - returns timestamp of the format MM-DD-YYYY HH:MM:SS
    '''
    
    currentTime = datetime.datetime.now(timezone('US/Eastern'))
    currentTime.strftime('%Y-%m-%d %H:%M:%S')
    return currentTime

def getProductTypeClassName(strProductType):

    '''
    Function to map the Product type selected by the user in the frontend with the class name on the backend.
    Thsi function utilizes the product type to class mapping dictionary saved on the Azure Functions portal under Environment Variables
    'Product_Type_Class_Name_Mapping'
 
        Parameters:
        - Product type selected by the user on the front end
 
        return:
        - returns timestamp of the format MM-DD-YYYY HH:MM:SS
    '''

    ## get dictProductType from Azure Function env variables

    dictProductType = os.getenv('Product_Type_Class_Name_Mapping')
    dictProductType = ast.literal_eval(dictProductType)  
    strProductTypeClassName = dictProductType.get(strProductType) ## Map the Product type to the class name

    return strProductTypeClassName

def getSqlConnection():
    '''
    Function to authenticate the Azure function to access the SQL Managed Instance through Managed Identity.
    This function utilizes the environment variable 'SQl_Managed_Instances_Connection_String' saved in the Azure Functions Portal
    under Environment Variables section
 
        Parameters:
        - None
 
        return:
        - Database connection object (dbConn)
    '''

    connection_string = os.getenv('SQl_Managed_Instances_Connection_String')
    credential = DefaultAzureCredential(exclude_interactive_browser_credential=False)
    token_bytes = credential.get_token("https://database.windows.net/.default").token.encode("UTF-16-LE")
    token_struct = struct.pack(f'<I{len(token_bytes)}s', len(token_bytes), token_bytes)
    SQL_COPT_SS_ACCESS_TOKEN = 1256  # This connection option is defined by microsoft in msodbcsql.h
    conn = pyodbc.connect(connection_string, attrs_before={SQL_COPT_SS_ACCESS_TOKEN: token_struct})
    logging.info(conn)

    return conn

def captureProcessStartTime(datetimeProcessStartTime, intRunID):
    '''
    Function to capture the Process Start time right before triggering the AML Endpoint URL.
 
        Parameters:
        - Current timestamp 
        - Current process' RunID
 
        return:
        - None
    '''

    try:
        #strRunID = str(intRunID)
        dbConn = getSqlConnection()        
        with dbConn.cursor() as cursor:
            query = """ EXEC UpdateProcessStartTime @process_start_time = ?, @run_id = ?"""
            values = (datetimeProcessStartTime, intRunID)
            cursor.execute(query, (values))  
            strLogString = f'RunID_{intRunID} Process start time captured successfully'
            logging.info(strLogString)
        dbConn.close()

    except:
       pass

def captureProcessEndTimeAndProcessStatus(datetimeProcessEndTime, strProcessStatus, intRunID):
    '''
    Function to capture the Process end time and process status right after finish running the AML Endpoint URL.
    If the AML Endpoint encounters an error then this function will called from the except block with the current time and 
    process status as 'Failure'
 
        Parameters:
        - Current timestamp 
        - Current process' RunID
        - Process Status (Success/Failure)
 
        return:
        - None
    '''

    try:
        #strRunID = str(intRunID)
        dbConn = getSqlConnection()        
        with dbConn.cursor() as cursor:
            query = """ EXEC UpdateProcessEndTimeAndStatus @process_end_time = ?, @process_status = ?, @run_id = ?"""
            values = (datetimeProcessEndTime, strProcessStatus, intRunID)
            cursor.execute(query, (values)) 
            strLogString = f'RunID_{intRunID} Process end time and process status captured successfully'
            logging.info(strLogString) 
        dbConn.close()

    except:
        pass

@waiver_review_bp.route(route = 'ProcessClauseValidationAndGetResult')
def ProcessClauseValidationAndGetResult(req: func.HttpRequest) -> func.HttpResponse:   
    '''
    Main function to trigger the AML endpoint by constructing the HTTP Request with paramters received from the UI,
    request body with access token retrieved from the Manged Identity and input for waiver review.
 
        Parameters:
        - Run ID
        - File name
        - Product type
 
        return:
        - If Success:
            - Returns back the Results of the Waiver Review in a JSON file to the UI for displaying the same to the user 
              with status code 200
        - If Failure:
            - Returns back a string value with the details of the error the UI with status code 500
    ''' 
    try:
        # 1. Get Parameters from the HTTP Request sent from the UI

        strProductType = req.params.get('product_type') # Product type chosen by the User in the UI
        strUploadedFileName = req.params.get('file_name') # Name of the file uploaded by the user in the UI
        intRunID = req.params.get('run_id') # Run ID created in the tbl_Metadata table for saving the metadata information
        intRunID = int(intRunID)
        #strRunID = str(intRunID)

        strLogString = f'RunID_{intRunID} - ProcessClauseValidationAndGetResult Azure Function Triggered successfully'
        logging.info(strLogString)

    except Exception as err:
        strLogString = f"ERROR - in getting the query parameter contents in the http request - " + str(err)
        logging.error(strLogString)  # Log the error message
        strReturnString = 'ERROR in processing the waiver form'
        return func.HttpResponse(strReturnString, status_code = 500)

    #2. Invoke the Azure Machine Learning Endpoint for Reviewing the Waiver and pass the above parameters
    #2.a. Get the AAD token to authenticate the Azure function to Invoke the AML endpoint 

    try:
        accessToken = getManagedIdentityToken()
        #logging.info(accessToken)

    except Exception as err:
        strLogString = "ERROR in geting access token for authenticating the Azure function to Invoke the AML endpoint"
        logging.error(strLogString)  # Log the error message
        strReturnString = 'ERROR in processing the waiver form'
        return func.HttpResponse(strReturnString, status_code = 500)
    
    #2.b. Construct the HTTP Request with body and headers with access_token to Invoke the AML Endpoint    
    try:
        allowSelfSignedHttps(True) # this line is needed if you use self-signed certificate in your scoring service.

        strProductTypeClassName = getProductTypeClassName(strProductType)

        #2.b.1 Construct the body of the HTTP Request with the parameters received from the UI
        dictData = {"strWaiverFileName" : strUploadedFileName,
                "intRunID" : intRunID,
                "strProductType" : strProductType,
                'strProductTypeClassName': strProductTypeClassName} 
        
        endpointUrlBody = str.encode(json.dumps(dictData))

        logging.info(endpointUrlBody)

        #2.c. Define the URL and the HTTP Request with body and headers

        endpointURL = os.getenv('AzureMLStudio_Endpoint')
        endpointDeploymentName = os.getenv('AzureMLStudio_Endpoint_Deployment')

        # The azureml-model-deployment header will force the request to go to a specific deployment.
        # Remove this header to have the request observe the endpoint traffic rules
        endpointUrlHheaders = {'Content-Type':'application/json', 'Authorization':('Bearer '+ accessToken), 'azureml-model-deployment': endpointDeploymentName }

        httpRequest = urllib.request.Request(endpointURL, endpointUrlBody, endpointUrlHheaders)
    
        # Log AML trigger     
        strLogString = f'RunID_{intRunID} AML Endpoint triggered Successfully'
        logging.info(strLogString)

        # Trigger the AML Endpoint and await the JSON Response
        endpointResponse = urllib.request.urlopen(httpRequest)
        endpointResult = endpointResponse.read() # Read the JSON response

        # Capture Process end time and process status as 'SUCCESS' in the tbl_Metadata table
        datetimeProcessEndTime = getCurrentTime()
        strProcessStatus = 'SUCCESS'
        captureProcessEndTimeAndProcessStatus(datetimeProcessEndTime, strProcessStatus, intRunID)

        # Return the JSON to the UI for dispalying it to the User
        return func.HttpResponse(endpointResult, mimetype="application/json", status_code = 200)

    except:    
        # Capture Process end time and process status as 'FAILURE' in the tbl_Metadata table           
        datetimeProcessEndTime = getCurrentTime()
        strProcessStatus = 'FAILURE'
        captureProcessEndTimeAndProcessStatus(datetimeProcessEndTime, strProcessStatus, intRunID)

        strReturnString = 'ERROR in processing the waiver form'

        return func.HttpResponse(strReturnString, status_code = 500)
    
    