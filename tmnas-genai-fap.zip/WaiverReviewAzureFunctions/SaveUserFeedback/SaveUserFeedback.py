import azure.functions as func
from azure.identity import DefaultAzureCredential
import pyodbc
import struct
import os
import logging
import datetime 
from pytz import timezone
import json


# Declare function blueprint to create a separate route for the SaveUserFeedback Azurefunction
sql_feedback_bp = func.Blueprint()

def getSqlConnection():
    '''
    Function to authenticate the Azure function to access the SQL Managed Instance through Managed Identity.
    This function utilizes the environment variable 'SQl_Managed_Instances_Connection_String' saved in the Azure Functions Portal
    under Environment Variables section
 
        Parameters:
        - None
 
        return:
        - Database connection object (dbConn)
    '''

    connection_string = os.getenv('SQl_Managed_Instances_Connection_String')
    credential = DefaultAzureCredential(exclude_interactive_browser_credential=False)
    token_bytes = credential.get_token("https://database.windows.net/.default").token.encode("UTF-16-LE")
    token_struct = struct.pack(f'<I{len(token_bytes)}s', len(token_bytes), token_bytes)
    SQL_COPT_SS_ACCESS_TOKEN = 1256  # This connection option is defined by microsoft in msodbcsql.h
    conn = pyodbc.connect(connection_string, attrs_before={SQL_COPT_SS_ACCESS_TOKEN: token_struct})
    return conn

def getCurrentTime():
    '''
    Function to capture the current time and return the current time in the format MM-DD-YYYY HH:MM:SS
 
        Parameters:
        - None
 
        return:
        - returns timestamp of the format MM-DD-YYYY HH:MM:SS
    '''
    
    currentTime = datetime.datetime.now(timezone('US/Eastern'))
    currentTime.strftime('%Y-%m-%d %H:%M:%S')
    return currentTime

def UpdateUserFeedback(intResultsID, datetimeFeedbackCaptureTime, strUserResponse, strFeedbackText):

    '''
    Function to capture the feedback entered by the User in the UI. This function executes the Stored procedure
    'UpdateUserFeedback' configured in the SQL Managed Instance. 
 
        Parameters:
        - Results ID
        - Current timestamp
        - User response (Thumbs Up / Thumbs Down)
        - Feedback text (text feedback entered by the User in the UI)
 
        return:
        - Feedback ID
    '''
    # Authenticate Azure function to connect to the Azure SQL Manged Instance
    dbConn = getSqlConnection()

    # Execute the Stored Procedure UpdateUserFeedback with the inputs

    with dbConn.cursor() as cursor:
        query = """ EXEC UpdateUserFeedback @results_id = ?, @feedback_capture_time = ?, @user_response = ?, @feedback_text = ?"""
        values = (intResultsID, datetimeFeedbackCaptureTime, strUserResponse, strFeedbackText)

        cursor.execute(query, (values))
        feedbackID = cursor.fetchone()[0] # Fetch the Feedback ID retured from the Stored Procdure

    dbConn.close() # Close the DB Conncetion

    return feedbackID

@sql_feedback_bp.route(route = 'SaveUserFeedback')
def SaveUserFeedback(req: func.HttpRequest) -> func.HttpResponse:

    '''
    Main function to trigger the Feedback Azure Function.
 
        Parameters:
        - Results ID
        - Current timestamp
        - User response (Thumbs Up / Thumbs Down)
        - Feedback text (text feedback entered by the User in the UI)
 
        return:
        - If Success:
            - Returns back the JSON response with the SUCCESS message and the Feedback ID with status code 200
        - If Failure:
            - Returns back a string value with the details of the error the UI with status code 500
    '''
    

    try:
        # 1. Get Parameters from the HTTP Request sent from the UI
        datetimeFeedbackCaptureTime = getCurrentTime()

        dictDbData = req.get_body()
        dictDbData = dictDbData.decode()
        dictDbData = json.loads(dictDbData)

        intResultsID = dictDbData.get('results_id')
        intResultsID = int(intResultsID)
        strUserResponse = dictDbData.get('user_response')
        strFeedbackText = dictDbData.get('feedback_text')

        #2. Log the Azure Function trigger message
        strLogString = f'ResultsID_{intResultsID} - SaveUserFeedback Azure Function Triggered Successfully'
        logging.info(strLogString) 

    except Exception as err:
        strLogString = f"ERROR - in getting the feedback contents in the http request body - " + str(err)
        logging.error(strLogString)  # Log the error message
        strReturnString = "Couldn't send feedback. Please try again."
        return func.HttpResponse(strReturnString, status_code = 500)

    try:
        # 3. Update the user feedback in the tbl_Feedback table
        intFeedbackID = UpdateUserFeedback(intResultsID, datetimeFeedbackCaptureTime, strUserResponse, strFeedbackText)

        # Complie the JSON response to the UI
        dictJsonResponse = {'process_status' : 'SUCCESS',
            'intFeedbackID' :intFeedbackID} 
        
        # Log the feedback Update status
        strLogString = f'ResultsID_{intResultsID} - User feedback saved successfully'
        logging.info(strLogString) 

        # Return the JSON Response        
        return func.HttpResponse(json.dumps(dictJsonResponse), mimetype="application/json", status_code = 200)
    
    except Exception as err:
        # Compile the error message
        strLogString = f"ResultsID_{intResultsID} - ERROR - Feedback Capture Failed - " + str(err)
        logging.error(strLogString)  # Log the error message
        strReturnString = "Couldn't send feedback. Please try again."
        return func.HttpResponse(strReturnString, status_code = 500)
