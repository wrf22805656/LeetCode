import azure.functions as func
from azure.identity import DefaultAzureCredential, ManagedIdentityCredential, InteractiveBrowserCredential
import pyodbc
import struct
import os
import logging
import datetime 
from pytz import timezone
import json

# Declare function blueprint to create a separate route for the SaveMetdataAndClauseValidationResult Azurefunction
sql_metadata_bp = func.Blueprint()

def getSqlConnection():
    '''
    Function to authenticate the Azure function to access the SQL Managed Instance through Managed Identity.
    This function utilizes the environment variable 'SQl_Managed_Instances_Connection_String' saved in the Azure Functions Portal
    under Environment Variables section
 
        Parameters:
        - None
 
        return:
        - Database connection object (dbConn)
    '''

    connection_string = os.getenv('SQl_Managed_Instances_Connection_String')
    credential = DefaultAzureCredential(exclude_interactive_browser_credential=False)
    token_bytes = credential.get_token("https://database.windows.net/.default").token.encode("UTF-16-LE")
    token_struct = struct.pack(f'<I{len(token_bytes)}s', len(token_bytes), token_bytes)
    SQL_COPT_SS_ACCESS_TOKEN = 1256  # This connection option is defined by microsoft in msodbcsql.h
    conn = pyodbc.connect(connection_string, attrs_before={SQL_COPT_SS_ACCESS_TOKEN: token_struct})
    return conn

def updateDataExtractionMetadata(strExtractedFileName, intRunID):
    '''
    Function to capture the name of the extracted file sent from the Data Extraction step of the AML endpoint.
    This function executes the Stored procedure 'UpdateExtractedFileName' configured in the SQL Managed Instance. 
 
        Parameters:
        - Run ID
        - Extracted File name
 
        return:
        - None
    '''
    # Authenticate Azure function to connect to the Azure SQL Manged Instance
    dbConn = getSqlConnection()   

    # Execute the Stored Procedure UpdateExtractedFileName with the inputs     
    with dbConn.cursor() as cursor:
        query = """ EXEC UpdateExtractedFileName @run_id = ?, @extracted_file_name = ?"""
        values = (intRunID, strExtractedFileName)
        cursor.execute(query, (values))
    dbConn.close() # Close the DB Conncetion

    return

def updateDataVectorizationMetadata(strVectorIndexName, intRunID):

    '''
    Function to capture the name of the vector index sent from the Data Vectorization step of the AML endpoint.
    This function executes the Stored procedure 'UpdateVectorIndexName' configured in the SQL Managed Instance. 
 
        Parameters:
        - Run ID
        - Vector index name
 
        return:
        - None
    '''
    # Authenticate Azure function to connect to the Azure SQL Manged Instance
    dbConn = getSqlConnection()        

    # Execute the Stored Procedure UpdateVectorIndexName with the inputs
    with dbConn.cursor() as cursor:
        query = """ EXEC UpdateVectorIndexName @run_id = ?, @vector_index_name = ?"""
        values = (intRunID, strVectorIndexName)
        cursor.execute(query, (values))  
    dbConn.close() # Close the DB Conncetion

    return

def getCurrentTime():
    '''
    Function to capture the current time and return the current time in the format MM-DD-YYYY HH:MM:SS
 
        Parameters:
        - None
 
        return:
        - returns timestamp of the format MM-DD-YYYY HH:MM:SS
    '''
    
    currentTime = datetime.datetime.now(timezone('US/Eastern'))
    currentTime.strftime('%Y-%m-%d %H:%M:%S')
    return currentTime


def UpdateClauseValidationResults(intRunID, 
                                  strProductType,
                                  intReqNo, 
                                  datetimeResultsCaptureTime, 
                                  strValidationOutput, 
                                  strBriefSummary, 
                                  strDetailedSummary, 
                                  strActualQuote, 
                                  dbConn): 
    
    '''
    Function to capture the results of the Clause Validation funciton in the AML endpoint.
    This function executes the Stored procedure 'UpdateClauseValidationResults' configured in the SQL Managed Instance. 
 
        Parameters:
        - Run ID
        - Product type
        - Requirement Number
        - Current time stamp
        - Validation Output (Passed Validation / Needs Review)
        - Brief Summary
        - Detailed Summary
        - Actual Quote
        - DB Connection object
 
        return:
        - Results ID
    '''
    # Execute the Stored Procedure UpdateVectorIndexName with the inputs

    with dbConn.cursor() as cursor:
        query = """ EXEC UpdateClauseValidationResults @run_id = ?, @product_type = ?, @clause_no = ?, @results_capture_time = ?, @final_results = ?, @brief_summary = ?, @detailed_summary = ?, @actual_quote = ?"""
        values = (intRunID, strProductType, intReqNo, datetimeResultsCaptureTime, strValidationOutput, strBriefSummary, strDetailedSummary, strActualQuote)
        cursor.execute(query, (values))  
        intresultsID = cursor.fetchone()[0] # Fetch the ResultsID returned from the Stored Procedure

    return intresultsID  
    

@sql_metadata_bp.route(route = 'SaveMetadataAndClauseValidationResult')
def SaveMetadataAndClauseValidationResult(req: func.HttpRequest) -> func.HttpResponse:
    '''
    Main function to trigger the Save Metadata and Clause Validation Results Azure Function.
    This function has three blocks and each block will be run based on the function name in the HTTPRequest parameter
    1. Block to update the Data Extraction Metadata (function_name in the HTTPRequest paramter should be 'DataExtraction')
    2. Block to update the Data Vectorization Metadata (function_name in the HTTPRequest paramter should be 'DataVectorization')
    3. Block to update the Clause Validation Metadata (function_name in the HTTPRequest paramter should be 'Clause Validation')
 
        Parameters:
        - Function name attached in the HTTPRequest parameter
        - Metadata to be captured in the database attached in the HTTPRequest body
 
        return:
        - If function name is Data Extraction :
            - Returns back 'SUCCESS' message
        - If function name is Data Vectorization :
            - Returns back 'SUCCESS' message
        - If function name is Clause Validation:
            - Returns back the JSON response with the Result IDs created with respect to each Requirement in the Waiver Review            
    '''
    try:
        # 1. Get Parameters from the HTTP Request sent from the AML Endpoint
        strFuncName = req.params.get('function_name')
        dictDbData = req.get_body()
        dictDbData = dictDbData.decode()
        dictDbData = json.loads(dictDbData)
        dictDataExtractionMetadata = dictDbData.get('db_info')
        intRunID = int(dictDataExtractionMetadata.get('run_id'))        

    except Exception as err:
        strLogString = f"ERROR - in getting the query parameter contents in the http request - " + str(err)
        logging.error(strLogString)  # Log the error message
        strReturnString = 'ERROR in storing the values in the database'
        return strReturnString


    if strFuncName == 'DataExtraction':
        #2. Get contenst from the body of the HTTP Request sent from the AML Endpoint
        dictDataExtractionMetadata = dictDbData.get('db_info')
        strExtractedFileName = dictDataExtractionMetadata.get('extracted_file_name')
        intRunID = int(dictDataExtractionMetadata.get('run_id'))
        strProductType = dictDataExtractionMetadata.get('product_type')

        strLogString = f'RunID_{intRunID} Azure Function to Save Data Extraction Metadata triggered successfully'
        logging.info(strLogString)

        try:
            # Update the Data Extraction Metadata to the tbl_Metdata table
            updateDataExtractionMetadata(strExtractedFileName, intRunID)
            strLogString = f'RunID_{intRunID} Data Extraction Metadata saved successfully'
            logging.info(strLogString)
            return 'SUCCESS'

        except Exception as err:
            # Log the errors
            strLogString = f'RunID_{intRunID} ERROR - in saving the Data Extraction Metadata in tbl_Metadata - ' + str(err)
            logging.error(strLogString)
            return strLogString

    elif strFuncName == 'DataVectorization':
        #3. Get contenst from the body of the HTTP Request sent from the AML Endpoint
        dictDataVectorizationMetadata = dictDbData.get('db_info')
        strVectorIndexName = dictDataVectorizationMetadata.get('vector_index_name')
        intRunID = int(dictDataVectorizationMetadata.get('run_id'))
        #strRunID = str(intRunID)
        strProductType = dictDataVectorizationMetadata.get('product_type')

        strLogString = f'RunID_{intRunID} Azure Function to Save Data Vectorization Metadata triggered successfully'
        logging.info(strLogString)

        try:
            # Update the Data Vectorization Metadata to the tbl_Metdata table
            updateDataVectorizationMetadata(strVectorIndexName, intRunID)
            strLogString = f'RunID_{intRunID} Data Vectorization Metadata saved successfully'
            logging.info(strLogString)
            return 'SUCCESS'

        except Exception as err:
            # Log the errors
            strLogString = f'RunID_{intRunID} ERROR - in saving the Data Vectorization Metadata in tbl_Metadata - ' + str(err)
            logging.error(strLogString)
            return strLogString

    elif strFuncName == 'ClauseValidation':
        #3. Get contenst from the body of the HTTP Request sent from the AML Endpoint
        dictClauseValidationResults = dictDbData.get('db_info')
        listClauseValidationResults = dictClauseValidationResults.get('listClauseValidationResults')
        intRunID = int(dictClauseValidationResults.get('run_id'))
        #strRunID = str(intRunID)
        strProductType = dictClauseValidationResults.get('product_type')
        #listResultsID = []
        dictResultsID = {}

        strLogString = f'RunID_{intRunID} Azure Function to Save Clause Validation Results triggered successfully'
        logging.info(strLogString)

        dbConn = getSqlConnection()

        for i in range(len(listClauseValidationResults)):
            strReqNo = listClauseValidationResults[i].get('strReqNo')
            intReqNo = int(strReqNo.split(' ')[1])
            datetimeResultsCaptureTime = getCurrentTime()            
            strValidationOutput = listClauseValidationResults[i].get('strValidationOutput')
            strBriefSummary = listClauseValidationResults[i].get('strBriefSummary')
            strDetailedSummary = listClauseValidationResults[i].get('strDetailedSummary')
            strActualQuote = listClauseValidationResults[i].get('strActualQuote')

            try:
                # Update the Clause Validation Results to the tbl_Results table
                intResultID = UpdateClauseValidationResults(intRunID, 
                                                            strProductType, 
                                                            intReqNo, 
                                                            datetimeResultsCaptureTime, 
                                                            strValidationOutput, 
                                                            strBriefSummary, 
                                                            strDetailedSummary, 
                                                            strActualQuote, 
                                                            dbConn)
                dictResultsID.update({strReqNo : intResultID})   

                  

                strLogString = f'RunID_{intRunID} - Clause Validation results for the Requirement {intReqNo} saved successfully'
                logging.info(strLogString)           

            except Exception as err:
                # Log the errors
                dictResultsID.update({strReqNo : ''})
                strLogString = f'RunID_{intRunID} - ERROR - Saving Clause Validation results for the Requirement {intReqNo} failed' + str(err)
                logging.error(strLogString)

        dbConn.close()
        return (func.HttpResponse(json.dumps(dictResultsID), mimetype="application/json"))
    
    else:
        pass




