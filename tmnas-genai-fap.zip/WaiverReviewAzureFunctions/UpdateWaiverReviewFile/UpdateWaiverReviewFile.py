#####################################################################################################################


#####################################################################################################################


## Import Libraries
# Import Azure libraries

import azure.functions as func
from azure.identity import DefaultAzureCredential, ManagedIdentityCredential
from azure.storage.blob import BlobServiceClient

# Import other Libraries

import time
import pyodbc
import struct
import os
import logging
import json
import datetime
from pytz import timezone
# Declare function blueprint to create a separate route for the UpdateWaiverReviewFile Azurefunction

upload_bp = func.Blueprint() 


def getSqlConnection():
    '''
    Function to authenticate the Azure function to access the SQL Managed Instance through Managed Identity.
    This function utilizes the environment variable 'SQl_Managed_Instances_Connection_String' saved in the Azure Functions Portal
    under Environment Variables section
 
        Parameters:
        - None
 
        return:
        - Database connection object (dbConn)
    '''

    dbConnectionString = os.getenv('SQl_Managed_Instances_Connection_String')
    dbCredential = DefaultAzureCredential(exclude_interactive_browser_credential=False)
    token_bytes = dbCredential.get_token("https://database.windows.net/.default").token.encode("UTF-16-LE")
    token_struct = struct.pack(f'<I{len(token_bytes)}s', len(token_bytes), token_bytes)
    SQL_COPT_SS_ACCESS_TOKEN = 1256  # This connection option is defined by microsoft in msodbcsql.h
    dbConn = pyodbc.connect(dbConnectionString, attrs_before={SQL_COPT_SS_ACCESS_TOKEN: token_struct})

    return dbConn

def getCurrentTime():
    '''
    Function to capture the current time and return the current time in the format MM-DD-YYYY HH:MM:SS
 
        Parameters:
        - None
 
        return:
        - returns timestamp of the format MM-DD-YYYY HH:MM:SS
    '''
    
    currentTime = datetime.datetime.now(timezone('US/Eastern'))
    currentTime.strftime('%Y-%m-%d %H:%M:%S')
    return currentTime


def captureProcessStartTime(datetimeProcessStartTime, intRunID):
    '''
    Function to capture the Process Start time right before triggering the AML Endpoint URL.
 
        Parameters:
        - Current timestamp 
        - Current process' RunID
 
        return:
        - None
    '''

    try:
        #strRunID = str(intRunID)
        dbConn = getSqlConnection()        
        with dbConn.cursor() as cursor:
            query = """ EXEC UpdateProcessStartTime @process_start_time = ?, @run_id = ?"""
            values = (datetimeProcessStartTime, intRunID)
            cursor.execute(query, (values))  
            strLogString = f'RunID_{intRunID} Process start time captured successfully'
            logging.info(strLogString)
        dbConn.close()

    except:
       pass

def captureProcessEndTimeAndProcessStatus(datetimeProcessEndTime, strProcessStatus, intRunID):
    '''
    Function to capture the Process end time and process status right after finish running the AML Endpoint URL.
    If the AML Endpoint encounters an error then this function will called from the except block with the current time and 
    process status as 'Failure'
 
        Parameters:
        - Current timestamp 
        - Current process' RunID
        - Process Status (Success/Failure)
 
        return:
        - None
    '''

    try:
        #strRunID = str(intRunID)
        dbConn = getSqlConnection()        
        with dbConn.cursor() as cursor:
            query = """ EXEC UpdateProcessEndTimeAndStatus @process_end_time = ?, @process_status = ?, @run_id = ?"""
            values = (datetimeProcessEndTime, strProcessStatus, intRunID)
            cursor.execute(query, (values)) 
            strLogString = f'RunID_{intRunID} Process end time and process status captured successfully'
            logging.info(strLogString) 
        dbConn.close()

    except:
        pass

def getRunID(strProductType, strUserEmail, strLoginTime, dbConn):
    '''
    Function to generate the RunID for the process triggered by the User in the UI. This function executes the Stored procedure
    'CreateRunID' configured in the SQL Managed Instance. 
 
        Parameters:
        - User email
        - Login time of the user in the UI
        - product type selected by the user in the UI
 
        return:
        - RunID created in the tbl_Metadata table
    '''

    with dbConn.cursor() as cursor:
        query = """ EXEC CreateRunID @user_email = ?, @login_time = ?, @product_desc = ?""" # Execute the Stored Procedure
        values = (strUserEmail, strLoginTime, strProductType)
        cursor.execute(query, (values))
        intRunID = cursor.fetchone()[0] # Fetch the Run ID retured from the Stored Procdure
    return intRunID

def updateUploadedFileName(dbConn, uploadedFileName, intRunID):
    '''
    Function to updated the uploaded file name in the tbl_Metadata. This function executes the Stored procedure
    'UpdateUploadedFileName' configured in the SQL Managed Instance. 
 
        Parameters:
        - DB Connection Object
        - Uploaded file name
        - Run ID
 
        return:
        - None
    '''

    with dbConn.cursor() as cursor:
        query = """ EXEC UpdateUploadedFileName @run_id = ?, @uploaded_file_name = ?"""
        values = (intRunID, uploadedFileName)
        cursor.execute(query, (values))

    return 

def getBlobConnection():
    '''
    Function to authenticate the Azure function to access the Azure Blob Storage. 
 
        Parameters:
        - None
 
        return:
        - Blob Service Client object
    '''

    storageAccountURL = os.getenv("Storage_Account_URL")
    credential = ManagedIdentityCredential()
    # Create the BlobServiceClient object
    blobServiceClient = BlobServiceClient(storageAccountURL, credential=credential)
    
    return blobServiceClient

def uploadFiletoBlobContainer(blobServiceClient, strFileName, inputFile):
    '''
    Function to add the file uploaded by the user in the UI to the Azure Blob Container. 
 
        Parameters:
        - Blob Service Client
        - File name
        - Input File
 
        return:
        - Uploaded File Name
    '''

    containerName = os.getenv('Upload_Container_Name') # get the name of the container from the Azure Function portal's Environment Variables
    container_client = blobServiceClient.get_container_client(containerName) 
    blob_client = container_client.get_blob_client(strFileName)
    inputFile.seek(0)
    blob_client.upload_blob(data=inputFile, overwrite=True)

    return strFileName

def checkMaliciousFile(blobServiceClient, strFileName):
    '''
    Function to check whether the user uploaded file is malicious or not. This function reads the tags created by the 
    Microsoft Defender to categorize it to Malicious or threat free
 
        Parameters:
        - Blob service client
        - File name
 
        return:
        - Returns back a String saying whether the file is 'Malicious' or 'No threats found'
    '''
    containerName = os.getenv('Upload_Container_Name') # get the name of the container from the Azure Function portal's Environment Variables
    blobClient = blobServiceClient.get_blob_client(container=containerName, blob=strFileName)
    blobTags = blobClient.get_blob_tags()

    if bool(blobTags):
        strThreatCategory = blobTags.get('Malware Scanning scan result')

    else:
        time.sleep(5)
        strThreatCategory = checkMaliciousFile(blobServiceClient, strFileName)

    if strThreatCategory == 'No threats found':
        return 'No threats found'
    
    else:
        return 'Malicious file'
   
@upload_bp.route(route = 'UpdateWaiverReviewFile')
def UpdateWaiverReviewFile(req: func.HttpRequest) -> func.HttpResponse:
    '''
    Main function to create RunID, add the user uploaded file to the Azure Blob Container and return the RunID and 
    the Uploaded file name to the UI.
 
        Parameters:
        - User email
        - User login time
        - Product type
 
        return:
        - Returns back a JSON response with the RunID, Uploaded file name and Product type
    '''

    logging.info('UpdateWaiverReviewFile Azure Function Triggered successfully')

    try:

        # 1. Get Parameters from the UI 

        strProductType = req.params.get('product_type') # Product type chosen by the User in the UI
        strUserEmail = req.params.get('user_email') # User log in email captured by the UI
        strLoginTime = req.params.get('login_time') # user log in time captured by the UI

        for inputFile in req.files.values(): # input_file is the file uploaded by the user in the UI
            strFileNameUploaded = inputFile.filename # capture name of the file uploaded by the user
            strFileName = strFileNameUploaded.rsplit('.',1) [0]
            strFileType = strFileNameUploaded.rsplit('.',1) [1]

        # 1.a. Check for the file type. Raise Exception when the file type is not pdf

        if strFileType != 'pdf':
            strLogString = f'ERROR - Exception raised for the uploaded File type {strFileType}. Only waiver forms of file type .pdf is accepted for processing'
            logging.error(strLogString)
            strReturnString = 'Only waiver forms of file type PDF is accepted for processing. Please upload PDF version of the waiver form'
            return func.HttpResponse(strReturnString, status_code = 500)
        
        else:
            pass

    except Exception as err:
        strLogString = f"ERROR - in getting the query parameter contents and uploaded file in the http request - " + str(err)
        logging.error(strLogString)  # Log the error message
        strReturnString = 'Upload Failed. Please try again.'
        return func.HttpResponse(strReturnString, status_code = 500)

    #2. Connect to tbl_Metdata to create a new runID
    # 2.a. Authenticate Azure function to connect to the Azure SQL Manged Instance
    try:
        dbConn = getSqlConnection()      
        logging.info('Connection to Database is Successful')  

    except Exception as err:
        strLogString = 'ERROR in the SQL Managed Instance Authentication - ' + str(err)
        logging.error(strLogString)
        strReturnString = 'Upload Failed. Please try again.'
        return func.HttpResponse(strReturnString, status_code = 500)
    
    #2.b. Create new runID in the tbl_Metadata table
    try:
        intRunID = getRunID(strProductType, strUserEmail, strLoginTime, dbConn)
        strRunID = str(intRunID)
        strLogString = f'RunID_{strRunID} - Run ID created successfully'
        logging.info(strLogString)

    except Exception as err:
        strLogString = f'ERROR in creating runID in the tbl_Metadata - ' + str(err)
        logging.error(strLogString)
        strReturnString = 'Upload Failed. Please try again.'
        return func.HttpResponse(strReturnString, status_code = 500)
    
    #2.c. Update strFileName with the runID to make it unique:
    strFileName = strFileName + '_' + str(intRunID) + '.' + strFileType

    #2.d. Capture Process start time in the Database as a Metadata
    try:
        datetimeProcessStartTime = getCurrentTime()
        captureProcessStartTime(datetimeProcessStartTime, intRunID)

    except Exception as err:
        strLogString = f'ERROR in capturing the process start time - ' + str(err)
        logging.error(strLogString)
        strReturnString = 'Upload Failed. Please try again.'
        return func.HttpResponse(strReturnString, status_code = 500)


    #3. Upload file to the blob container
    #3.a. Get the Blob Service Client by authtenticating through Managed Identities and upload thefile to blob storage
    try: 
        blobServiceClient = getBlobConnection()
        uploadedFileName = uploadFiletoBlobContainer(blobServiceClient, strFileName, inputFile)
        strLogString = f'RunID_{strRunID} - User uploaded file has been added to the Blob Storage successfully'
        logging.info(strLogString)

    except Exception as err:
        datetimeProcessEndTime = getCurrentTime()
        strProcessStatus = 'FAILURE'
        captureProcessEndTimeAndProcessStatus(datetimeProcessEndTime, strProcessStatus, intRunID)

        strLogString = f"RunID_{strRunID} - ERROR in Uploading file to Blob Container - " + str(err)
        logging.error(strLogString)
        strReturnString = 'Upload Failed. Please try again.'
        return func.HttpResponse(strReturnString, status_code = 500)
    
    #3.b. Check for Malicious content in the uploaded file
    try:
        strThreatCategory = checkMaliciousFile(blobServiceClient, uploadedFileName)

        if strThreatCategory == 'Malicious file':
            updateUploadedFileName(dbConn, uploadedFileName, intRunID)

            datetimeProcessEndTime = getCurrentTime()
            strProcessStatus = 'FAILURE'
            captureProcessEndTimeAndProcessStatus(datetimeProcessEndTime, strProcessStatus, intRunID)

            containerName = os.getenv('Upload_Container_Name')
            blobClient = blobServiceClient.get_blob_client(container=containerName, blob=strFileName)
            blobClient.delete_blob()

            strLogString = f'RunID_{strRunID} - User Uploaded a Malicious file. Hence, the uploaded waiver form cannot be processed further'
            logging.info(strLogString)
            strReturnString = 'WARNING: File poses a security threat and could not be processed. Please select another file.'

            return func.HttpResponse(strReturnString, status_code = 500)
        
        else:
            pass

    except Exception as err:
        datetimeProcessEndTime = getCurrentTime()
        strProcessStatus = 'FAILURE'
        captureProcessEndTimeAndProcessStatus(datetimeProcessEndTime, strProcessStatus, intRunID)
        strLogString = f"RunID_{strRunID} - ERROR in validating whether the uploaded file is malicious - " + str(err)
        logging.error(strLogString)
        strReturnString = 'Upload Failed. Please try again.'
        return func.HttpResponse(strReturnString, status_code = 500)
    
    #4. Updating the Metadata table with the Uploaded filename
    try:
        updateUploadedFileName(dbConn, uploadedFileName, intRunID)
        strLogString = f'RunID_{strRunID} - Uploaded file name updated in the Metadata table successfully'
        logging.info(strLogString)        

    except Exception as err:
        datetimeProcessEndTime = getCurrentTime()
        strProcessStatus = 'FAILURE'
        captureProcessEndTimeAndProcessStatus(datetimeProcessEndTime, strProcessStatus, intRunID)
        strLogString = f"RunID_{strRunID} - ERROR in updating the Uploaded file name in the tbl_Metadata table - " + str(err)
        logging.error(strLogString)
        strReturnString = 'Upload Failed. Please try again.'
        return func.HttpResponse(strReturnString, status_code = 500)
    
    #5. Construct return values in a JSON    
    jsonResponse = {"run_id": intRunID,
               "file_name": uploadedFileName,
               "product_type":strProductType}
    dbConn.close()   

    return func.HttpResponse(json.dumps(jsonResponse), mimetype="application/json", status_code = 200)