# Databricks notebook source
# MAGIC %run /Workspace/Shared/TDM/TestDataManager

# COMMAND ----------

import json




metadata_sfk_stratified_python = json.loads("""
{
    "source":{
      "type":"db",
      "asset":{
         "system":"snowflake",
         "connection_name":"snowflake_test",
         "database_name":"SNOWFLAKE_SAMPLE_DATA",
         "schema_name":"TPCDS_SF10TCL",
         "table_name":"CUSTOMER"
      }
   },
   "sampling":{
      "sampling_operator":"python",
      "method":"stratified",
      "sampling_pct": "60",
      "strat_column":"C_BIRTH_COUNTRY"
   },
   "classification": {
        "app": "custom",
        "app_connection_name": "big_test",
        "object_name": "SF_MRR_SAMPLE_DATA_CDS_PERF11.SNOWFLAKE_SAMPLE_DATA.TPCDS_SF10TCL.CUSTOMER"
    },
   "transformer": {
        "app": "faker"
    },
      "target":{
      "type":"file",
      "asset":{
         "system":"azure_blob",
         "connection_name":"azure_blob_test",
         "file_name":"tdm_prim/customer_tdm_ou.txt",
         "file_format":"csv",
         "write_options": {
            "header":true
                     }
      }
   }
}""")


pipeline = TestDataManager(metadata=metadata_sfk_stratified_python)
pipeline.run()