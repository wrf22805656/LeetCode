# Databricks notebook source
import sys
print(sys.version)

# COMMAND ----------

import json
from azure.storage.blob import BlobServiceClient
from azure.storage.blob import BlobType
from pyspark.dbutils import DBUtils
from pyspark.sql import SparkSession
import logging


#print(data)

import json
from azure.storage.blob import BlobServiceClient
from pyspark.dbutils import DBUtils
from pyspark.sql import SparkSession
import logging

class BlobClient1:
    def __init__(self, logger: logging.Logger = logging.getLogger(__name__)):
        self.storage_account_name = 'cdapsadlsstgacct'
        self.container_name = 'tdm-source'
        self.storage_account_credential_secret = 'cdapsadlsstgacct'
        self.secret_scope = 'cda-aiml-keyvault'
        self.account_url = f"https://{self.storage_account_name}.blob.core.windows.net"
        self.spark = SparkSession.builder.getOrCreate()
        self.dbutils = DBUtils(self.spark)
        self.credential = self.dbutils.secrets.get(
            scope=self.secret_scope, key=self.storage_account_credential_secret
        )
 

    def fetch_file_urls(self):
        url_list = []
        blob_list = self.blob_container_client.list_blobs(
            name_starts_with=self.path + "/"
        )
        for blob in blob_list:
            url = self.blob_container_client.url + "/" + blob.name
            url_list.append(url)
        return url_list

    def load_data_from_blob(self, file_path):
        """
        Loads the data from the specified CSV file in the blob storage.

        Args:
            file_path (str): The name of the CSV file.

        Returns:
            df_extract (DataFrame): The loaded data from the CSV file.
        """
        # Print the storage account key to verify
        print(self.credential)

        # Set Spark configuration to use the storage account key
        self.spark.conf.set(f"fs.azure.account.key.{self.storage_account_name}.blob.core.windows.net", self.credential)

        # Construct the full file path in Azure Blob Storage
        #blob_path = f"wasbs://{self.container_name}@{self.storage_account_name}.blob.core.windows.net/{file_path}"
        blob_path='wasbs://tdm-source@cdapsadlsstgacct.blob.core.windows.net/fake_us_customer_data.csv'

        # Read the CSV file from Azure Blob Storage using PySpark
        df_extract = self.spark.read.csv(blob_path, header=True, inferSchema=True)
        return df_extract

# Example usage
b = BlobClient1()
df = b.load_data_from_blob('fake_us_customer_data.csv')
df.show()
