# Databricks notebook source
# MAGIC %pip install Faker==33.3.1
# MAGIC %pip install azure-identity==1.19.0
# MAGIC %pip install azure-keyvault-secrets==4.9.0
# MAGIC %pip install azure-storage-blob==12.24.1
# MAGIC %pip install fuzzywuzzy==0.18.0
# MAGIC %pip install python-Levenshtein==0.27.1
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %run /Workspace/EY/EY_TDM/TDM/common/nb_test_data_manager

# COMMAND ----------

import json




metadata_sfk_random_python = json.loads("""
{
    "source":{
      "type":"db",
      "asset":{
         "system":"snowflake",
         "connection_name":"snowflake_test",
         "database_name":"SNOWFLAKE_SAMPLE_DATA",
         "schema_name":"TPCDS_SF10TCL",
         "table_name":"CUSTOMER"
      }
   },
   "sampling":{
      "sampling_operator":"sql",
      "method":"random",
      "sampling_pct": ".001"
   },
   "classification": {
        "app": "BigID",
        "app_connection_name": "big_test",
        "object_name": "SF_MRR_SAMPLE_DATA_CDS_PERF11.SNOWFLAKE_SAMPLE_DATA.TPCDS_SF10TCL.CUSTOMER"
    },
   "transformer": {
        "app": "faker"
    },
   "target":{
      "type":"file",
      "asset":{
         "system":"azure_blob",
         "connection_name":"fis_azure_blob_source",
         "file_name":"tdm_out/customer_sfk.txt",
         "file_format":"csv",
         "write_options": {
            "header":true
                     }
      }
   }
}""")


pipeline = TestDataManager(metadata=metadata_sfk_random_python)
pipeline.run()