# Databricks notebook source
# MAGIC %pip install Faker==33.3.1
# MAGIC %pip install azure-identity==1.19.0
# MAGIC %pip install azure-keyvault-secrets==4.9.0
# MAGIC %pip install azure-storage-blob==12.24.1
# MAGIC %pip install fuzzywuzzy==0.18.0
# MAGIC %pip install python-Levenshtein==0.27.1
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %run /Workspace/EY/EY_TDM/TDM/common/nb_test_data_manager

# COMMAND ----------

# MAGIC %run /Workspace/EY/EY_TDM/TDM/common/nb_logger

# COMMAND ----------

import json
logger = Logger(__name__).get_logger()



metadata_blob_header_radom = json.loads("""
{
   "source":{
      "type":"file",
      "asset":{
         "system":"azure_blob",
         "connection_name":"fis_azure_blob_source",
         "file_name":"customer_data.csv",
         "file_format":"csv",
         "read_options": {
            "header":true
         }
      }
   },
   "sampling":{
      "sampling_operator":"python",
      "method":"random",
      "sampling_pct":80
   },   
  "classification": {
    "app": "manual",
    "data": [
     

      {
        "column_name": "First_Name",
        "attribute_list": [
          {
            "attribute_original_name": "classifier.US Given Name",
            "calc_confidence_level": 1.0,
            "attribute_type": "Classification"
          }
        ]
      },
      {
        "column_name": "Last_Name",
        "attribute_list": [
          {
            "attribute_original_name": "classifier.US Family Name",
            "calc_confidence_level": 1.0,
            "attribute_type": "Classification"
          }
        ]
      },
      {
        "column_name": "Email",
        "attribute_list": [
          {
            "attribute_original_name": "classifier.Email",
            "calc_confidence_level": 1.0,
            "attribute_type": "Classification"
          }
        ]
      },
      {
        "column_name": "Phone_Number",
        "attribute_list": [
          {
            "attribute_original_name": "classifier.US Phone Number (Wide)",
            "calc_confidence_level": 1.0,
            "attribute_type": "Classification"
          }
        ]
      },
      {
        "column_name": "Address",
        "attribute_list": [
          {
            "attribute_original_name": "classifier.US Address",
            "calc_confidence_level": 1.0,
            "attribute_type": "Classification"
          }
        ]
      },
      {
        "column_name": "City",
        "attribute_list": [
          {
            "attribute_original_name": "classifier.Name of a City",
            "calc_confidence_level": 1.0,
            "attribute_type": "Classification"
          }
        ]
      },
      {
        "column_name": "State",
        "attribute_list": [
          {
            "attribute_original_name": "classifier.US State or territory Abbreviation",
            "calc_confidence_level": 1.0,
            "attribute_type": "Classification"
          }
        ]
      },
      {
        "column_name": "Zip_Code",
        "attribute_list": [
          {
            "attribute_original_name": "classifier.ZIP Code (Wide)",
            "calc_confidence_level": 1.0,
            "attribute_type": "Classification"
          }
        ]
      },
      {
        "column_name": "SSN",
        "attribute_list": [
          {
            "attribute_original_name": "classifier.US SSN",
            "calc_confidence_level": 1.0,
            "attribute_type": "Classification"
          }
        ]
      },
      {
        "column_name": "IP_Address",
        "attribute_list": [
          {
            "attribute_original_name": "classifier.IPv4",
            "calc_confidence_level": 1.0,
            "attribute_type": "Classification"
          }
        ]
      }
    ]
  }
,
   "transformer": {
        "app": "faker"
    },
      "target":{
      "type":"file",
      "asset":{
         "system":"azure_blob",
         "connection_name":"fis_azure_blob_source",
         "file_name":"tdm_out/fake_customer_data.csv",
         "file_format":"csv",
         "write_options": {
            "header":true
                     }
      }
   }
}""")

try:
  logger.info("Starting the test data generation process")
  pipeline = TestDataManager(metadata=metadata_blob_header_radom)
  pipeline.run()
  logger.info("Test data generation process completed")
except Exception as e:
  logger.error(f"Test data generation process failed with error: {e}")
  raise e 
