# Databricks notebook source
# MAGIC %run /Workspace/EY/EY_TDM/TDM/common/nb_logger

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.window import Window
from pyspark.sql.functions import ceil
logger = Logger(__name__).get_logger()


class DataSampler:
    def __init__(self, metadata):
        logger.info(f"Initializing DataSampler with metadata: {metadata}")
        self.metadata = metadata

    def sample_data(self, data):
        """
        Samples data based on metadata configurations.
        """
        try:
            self.sampling = self.metadata.get('sampling', {})
            sampling_operator = self.sampling.get("sampling_operator")
            sampling_method = self.sampling.get("method")
            
            if sampling_operator is None:
                raise ValueError("Sampling operator is missing in the metadata")
            
            if sampling_operator == "sql":
                # SQL-based sampling is already handled in the DataExtractor
                logger.info("Skipping sampling as SQL-based sampling is already handled in the DataExtractor")
                return data
            
            elif sampling_operator == "python":
                if sampling_method is None:
                    raise ValueError("Sampling method (stratified or random) must be specified in the metadata")
                
                if sampling_method == "stratified":
                    return self.stratified_sampling(data)
                elif sampling_method == "random":
                    return self.random_sampling(data)
                else:
                    raise ValueError(f"Unsupported sampling method: {sampling_method}")
            else:
                raise ValueError(f"Unsupported sampling operator: {sampling_operator}")
        
        except Exception as e:
            # Log the exception details and raise it
            logger.info(f"Error in sample_data: {str(e)}")
            raise

    def random_sampling(self, data):
        """
        Applies random sampling based on the fraction (percentage) specified in metadata.
        The fraction will be passed as a percentage in metadata and converted to decimal.
        """
        try:
            sampling_pct = self.sampling.get("sampling_pct", 10)  # Default to 10% if not specified
            sampling_fraction = float(sampling_pct) / 100.0  # Convert percentage to fraction

            logger.info(f"Random Sampling started with {sampling_pct}% of the data")
            
            if sampling_fraction <= 0 or sampling_fraction > 1:
                raise ValueError("Sampling fraction must be between 0 and 1.")

            data_record_cnt= data.count()
            target_sample_size = sampling_fraction * data_record_cnt
     

            sampling_fraction_derived=target_sample_size/data_record_cnt

            df_sample = data.sample(withReplacement=False, fraction=sampling_fraction_derived, seed=42)
            df_sample.cache()
            df_sample_limited = df_sample.limit((int(target_sample_size)))
            logger.info(f"Random Sampling completed with {sampling_pct}% of the data")
            return df_sample_limited
        
        except Exception as e:
            logger.info(f"Error in random_sampling: {str(e)}")
            raise

    def stratified_sampling(self, data):
        """
        Applies stratified sampling based on the strata_column and fraction (percentage) specified in metadata.
        The fraction will be passed as a percentage in metadata and converted to decimal.
        """
        try:
            strata_column = self.sampling.get("strat_column")
            if strata_column is None:
                raise ValueError("Strata column must be specified for stratified sampling")
            
            sampling_pct = self.sampling.get("sampling_pct", 10)  # Default to 10% if not specified
            sampling_fraction = float(sampling_pct) / 100.0  # Convert percentage to fraction

            logger.info(f"Stratified Sampling started with {sampling_pct}% of the data")
            
            if sampling_fraction <= 0 or sampling_fraction > 1:
                raise ValueError("Sampling fraction must be between 0 and 1.")
            
            # Apply window function to create a row number per strata group
            window_spec = Window.partitionBy(strata_column).orderBy(F.rand())

            # Add a random row number to each row within its strata
            sampled_data = data.withColumn("row_num", F.row_number().over(window_spec))

            # Calculate the number of rows to sample based on the fraction and group size
            group_size = data.groupby(strata_column).count()
            fraction_count = group_size.withColumn("sample_size", (F.col("count") * sampling_fraction).cast("int"))
     

            # Join the sampled data with the group size info
            sampled_data_with_size = sampled_data.join(fraction_count, on=strata_column)

            # Filter out the rows that are beyond the sample size for each group
            final_sample = sampled_data_with_size.filter(F.col("row_num") <= F.col("sample_size"))

            # Drop the extra columns used for sampling (row_num, group_size, and sample_size)
            final_sample = final_sample.drop("row_num", "group_size", "sample_size")

            final_sample.cache()

            logger.info(f"Stratified Sampling completed with {sampling_pct}% of the data")

            return final_sample

        except Exception as e:
            logger.info(f"Error in stratified_sampling: {str(e)}")
            raise