# Databricks notebook source
# MAGIC %run /Workspace/EY/EY_TDM/TDM/common/nb_logger

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import udf, col
from pyspark.sql.types import StringType
import pandas as pd
import random
from faker import Faker
import sys
logger = Logger(__name__).get_logger()



class DataGenerator:
    def __init__(self):
        """
        Initialize the Spark session and logging.
        """
        try:
            self.spark = SparkSession.builder.appName("FakeDataGenerator").getOrCreate()
            logger.info("DataGenerator initialized successfully.")
        except Exception as e:
            logger.error(f"Failed to initialize DataGenerator: {e}")
            raise RuntimeError(f"Initialization failed: {e}")

    def parse_classification_data(self, classification_data):
        """
        Parse classification metadata to extract column and classification details.
        :param classification_data: List of classification metadata from BigID.
        :return: A pandas DataFrame with parsed classification details.
        """
        try:
            parsed_data = []
            for item in classification_data:
                column_name = item['column_name']

                classification_list = [
                    class_item for class_item in item.get('attribute_list', [])
                    if class_item['attribute_type'] == 'Classification'
                ]

                if classification_list:
                    max_confidence = max(
                        class_item['calc_confidence_level'] for class_item in classification_list
                    )
                    max_confidence_classifications = [
                        class_item for class_item in classification_list
                        if class_item['calc_confidence_level'] == max_confidence
                    ]

                    # Pick one randomly if there are ties
                    selected_classification = random.choice(max_confidence_classifications)

                    parsed_data.append({
                        "column_name": column_name,
                        "classification_name": selected_classification['attribute_original_name'],
                        #"rank": selected_classification['rank'],
                        "confidence_level": selected_classification['calc_confidence_level']
                    })

            logger.info("Classification data parsed successfully.")
            test = pd.DataFrame(parsed_data)
            return pd.DataFrame(parsed_data)
        except Exception as e:
            logger.error(f"Error parsing classification data: {e}")
            raise RuntimeError(f"Failed to parse classification data: {e}")

    def generate_fake_data_udf(self, column_name, classification_df):
        """
        Generate a UDF to replace column values with fake data based on classification.
        :param column_name: The column name for which fake data is generated.
        :param classification_df: DataFrame containing classification data.
        :return: A PySpark UDF.
        """
        logger.info(f"Test: {column_name}")
        def fake_data_udf(original_value):
            try:

                # Fetch classification row
                classification_row = classification_df[classification_df["column_name"] == column_name]
                if not classification_row.empty:
                    classification_name = classification_row.iloc[0]["classification_name"]
                    logger.info(f"Classification found: {classification_name}")

                    # Use the custom data generator for generating fake data
                    fake_data = DataTransformer.generate_fake_data(classification_name)
                    if fake_data:
                        logger.info(f"Fake data generated: {fake_data}")
                        return fake_data

                return original_value  # Return original value if no classification or mapping exists
            except Exception as e:
                logger.error(f"Error generating fake data for column '{column_name}': {e}")
                raise

        return udf(fake_data_udf, StringType())

    def apply_fake_data(self, data_sampler_output, classification_data):
        """
        Apply fake data to the sampled data based on classification metadata.
        Fake data is applied only to columns with available classification data.
        :param data_sampler_output: Input PySpark DataFrame from the data sampler.
        :param classification_data: List of classification metadata from BigID.
        :return: A PySpark DataFrame with fake data applied.
        """
        try:
            # Parse classification data into DataFrame
            classification_df = self.parse_classification_data(classification_data)
            display("parsed classification data")
            display(classification_df)

            # Get the list of columns with classification data available
            classified_columns = classification_df["column_name"].tolist()

            # Apply fake data UDF only for classified columns
            for column in classified_columns:
                if column in data_sampler_output.columns:  # Check if column exists in the input DataFrame
                    fake_udf = self.generate_fake_data_udf(column, classification_df)
                    data_sampler_output = data_sampler_output.withColumn(
                        column, fake_udf(col(column))
                    )
            logger.info("Fake data applied successfully.")
            return data_sampler_output
        except Exception as e:
            logger.error(f"Error applying fake data: {e}")
            raise RuntimeError(f"Failed to apply fake data: {e}")


