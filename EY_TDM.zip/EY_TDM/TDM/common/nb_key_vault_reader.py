# Databricks notebook source
# MAGIC %run /Workspace/EY/EY_TDM/TDM/common/nb_logger

# COMMAND ----------

from azure.identity import DefaultAzureCredential
from azure.keyvault.secrets import SecretClient

class KeyVaultReader:
    def __init__(self, key_vault_url):
        self.key_vault_url = key_vault_url
        self.credential = DefaultAzureCredential()
        self.secret_client = SecretClient(vault_url=self.key_vault_url, credential=self.credential)

    def get_secret(self, secret_name):
        """
        Retrieves a secret from Azure Key Vault.
        Args:
            secret_name (str): The name of the secret to retrieve.
        Returns:
            str: The value of the secret.
        """
        secret = self.secret_client.get_secret(secret_name)
        return secret.value