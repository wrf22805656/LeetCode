# Databricks notebook source
# MAGIC %md
# MAGIC

# COMMAND ----------

# MAGIC %run /Workspace/EY/EY_TDM/TDM/common/nb_logger

# COMMAND ----------

# MAGIC %run /Workspace/EY/EY_TDM/TDM/common/nb_data_extractor

# COMMAND ----------

# MAGIC %run /Workspace/EY/EY_TDM/TDM/common/nb_data_writer

# COMMAND ----------

# MAGIC %run /Workspace/EY/EY_TDM/TDM/common/nb_data_sampler

# COMMAND ----------

# MAGIC %run /Workspace/EY/EY_TDM/TDM/common/nb_data_transformer

# COMMAND ----------

# MAGIC %run /Workspace/EY/EY_TDM/TDM/common/nb_data_classifier

# COMMAND ----------

# MAGIC %run /Workspace/EY/EY_TDM/TDM/common/nb_bigid_manager

# COMMAND ----------

# MAGIC %run /Workspace/EY/EY_TDM/TDM/common/nb_data_generator

# COMMAND ----------

# MAGIC %run /Workspace/EY/EY_TDM/TDM/common/nb_classifier_config

# COMMAND ----------

import json
logger = Logger(__name__).get_logger()


class TestDataManager:
    def __init__(self, metadata, connection_config='/Workspace/EY/EY_TDM/TDM/common/connection_config.yaml'):
        self.metadata = metadata
        self.connection_config = connection_config
        self.df_ext = None  # Extracted data
        self.df_sample = None  # Sampled data
        self.classification_data = None  # Classification metadata
        logger.info("TestDataManager initialized.")

        # Ensure mandatory keys exist
        if "source" not in self.metadata:
            raise ValueError("Metadata is missing the 'source' section. It is mandatory.")
        if "target" not in self.metadata:
            raise ValueError("Metadata is missing the 'target' section. It is mandatory.")
        if "transformer" not in self.metadata:
            raise ValueError("Metadata is missing the 'transformer' section. It is mandatory.")


    def extract_data(self):
        """Extract data from the source."""
        logger.info("Starting data extraction...")
        data_extractor = DataExtractor(metadata=self.metadata, config_path=self.connection_config)
        self.df_ext = data_extractor.extract_data()
        logger.info("Data extraction completed successfully.")
        display(self.df_ext)


    def sample_data(self):
        """Perform data sampling if required."""
        if "sampling" in self.metadata:
            logger.info("Starting data sampling...")
            data_sampler = DataSampler(metadata=self.metadata)
            self.df_sample = data_sampler.sample_data(self.df_ext)
            logger.info("Data sampling completed successfully.")
        else:
            logger.info("No sampling configuration found. Using extracted data.")
            self.df_sample = self.df_ext  # If no sampling, use extracted data
        display(self.df_sample)


    def classify_data(self):
        """Perform classification using BigID or custom logic."""
        classification = self.metadata.get("classification")
        if classification:
            app_name = classification.get("app")
            logger.info(f"Starting classification using {app_name}...")

            if app_name == 'BigID':
                object_name = classification.get("object_name")
                bigid = BigIDManager(metadata=self.metadata, config_path=self.connection_config)
                object_data_req = bigid.get_object_details(object_name=object_name)
                self.classification_data = object_data_req.get("data", [])
                logger.info("BigID classification pulled successfully.")
            elif app_name == "custom":
                class_config = ClassifierConfig()
                data_classifier = DataClassification(regex_patterns=class_config.CUSTOM_CLASSIFIER_REGEX_MAP)
                classification_json = data_classifier.classify_data(self.df_ext)
                display(classification_json)
                self.classification_data = classification_json.get("data", [])
                logger.info("Custom classification completed successfully.")
            elif app_name == "manual":
                self.classification_data = classification.get("data", [])
                logger.info("Manual classification data read successfully.")
            display(str(self.classification_data))
        else:
            logger.warning("No classification required. Skipping classification step.")

    def generate_fake_data(self):
        """Apply fake data based on classification metadata."""
        if "transformer" in self.metadata:
            logger.info("Starting data transformation with DataGenerator...")
            generator = DataGenerator()
            self.df_sample = generator.apply_fake_data(self.df_sample, self.classification_data)
            logger.info("Data transformation completed successfully.")
            display(self.df_sample)
        else:
            raise ValueError("Metadata is missing the 'transformer' section. It is mandatory for data transformation.")

    def write_data(self):
        """Write data to the target destination."""

        logger.info("Starting data writing process...")
        data_writer = DataWriter(metadata=self.metadata, config_path=self.connection_config)
        data_writer.write_data(df=self.df_sample)
        logger.info("Data writing completed successfully.")


    def run(self):
        """Execute the test data management process."""
        logger.info("TestDataManager execution started.")
        self.extract_data()
        self.sample_data()
        self.classify_data()
        self.generate_fake_data()
        self.write_data()
        logger.info("TestDataManager execution completed successfully.")