# Databricks notebook source
# MAGIC %run /Workspace/EY/EY_TDM/TDM/common/nb_logger

# COMMAND ----------

# MAGIC %run /Workspace/EY/EY_TDM/TDM/common/nb_classifier_config

# COMMAND ----------

"""
This module provides functionality for data classification based on predefined regex patterns 
and fuzzy matching techniques. It includes methods for extracting classification rules from 
a database, applying regex-based classification, and calculating confidence scores.

Dependencies:
-------------
- PySpark (for DataFrame operations)
- re (for regex-based classification)
- fuzzywuzzy (for fuzzy matching)
- json (for structured data conversion)

Functions:
----------
create_json_from_table(table_name, columns):
    Extracts classification rules from a database table and returns them as a dictionary.

Classes:
--------
DataClassification:
    A class for performing regex-based classification and confidence score calculations.
    
    __init__(regex_patterns=None):
        Initializes the classification model with predefined regex patterns.
    
    fuzzy_match(category, categories, threshold):
        Uses fuzzy matching to find the closest category if no perfect match is found.
    
    calculate_classifications(df, new_columns=None):
        Applies regex-based classification to a given DataFrame and assigns GDPR classifications 
        based on confidence scores.
    
    classify_data(df):
        Converts classification results into a structured DataFrame with assigned labels, 
        GDPR classifications, and confidence scores.
"""
import re
from pyspark.sql.types import StringType, ArrayType, FloatType, StructType, StructField
import json
from pyspark.sql import SparkSession
from pyspark.sql import functions as F
import random
from fuzzywuzzy import process
from fuzzywuzzy import fuzz
from pyspark.sql.functions import bround
logger = Logger(__name__).get_logger()



class DataClassification:
    def __init__(self, regex_patterns=None):
        logger.info("Initializing DataClassification...")       
        self.regex_patterns = regex_patterns

        
    
    def fuzzy_match(self, category, categories, threshold):
        match, score = process.extractOne(category, categories)
        if score >= threshold:
            return match  # If match score is above the threshold, return the matched category
        else:
            return None

    def calculate_classifications(self, df, new_columns=None):
        classifications = []
        threshold = 60
        
        matched_category = None
        highest_match_score = 0

        for column in df.columns:
        # for column in new_columns:
            total_non_null = 0
            match_counts = {category: 0 for category in self.regex_patterns}
            categories = [i for i in self.regex_patterns.keys()]


            for row in df.collect():
                value = row[column]
                total_non_null += 1
                for category, pattern in self.regex_patterns.items():
                    if re.fullmatch(pattern[1], str(value)):
                        match_counts[category] += 1

            # Calculate confidence scores
            confidence_scores = {category: (count / total_non_null) if total_non_null > 0 else 0
                                 for category, count in match_counts.items()}

            max_confidence_score = __builtins__.max(list(confidence_scores.values()),default=0)


            if max_confidence_score >= 0.6:
                perfect_match_categories = [category for category, score in confidence_scores.items() if score == max_confidence_score]
            else:
                # If no category has a confidence score >= 0.6, set perfect_match_categories to an empty list
                perfect_match_categories = []


            if len(perfect_match_categories) > 1:
                # Multiple perfect match categories, fuzzy match for each to finalize the category
                highest_match_score = 0  
                matched_category = None
                
                for category in perfect_match_categories:
                    match_score = fuzz.ratio(category, perfect_match_categories)
                    if match_score >= threshold and match_score > highest_match_score:
                        matched_category = category
                        match_score = confidence_scores[matched_category]

                if not matched_category:
                    matched_category = perfect_match_categories[0]  
                    match_score = confidence_scores[matched_category]

            elif len(perfect_match_categories) == 1:
                # Only one perfect match category
                matched_category = perfect_match_categories[0]
                match_score = confidence_scores[matched_category]

            else:
                # No perfect match categories
                matched_category = None
                match_score = 0

            # Assign GDPR classification based on the matched category
            gdpr_classifications = self.regex_patterns[matched_category][0] if matched_category else None
            match_categories = matched_category if matched_category else None
            #classifier_label = [self.regex_patterns[matched_category][-1]] if matched_category else ['None']

            # Append the results to the classifications list


            if match_categories:
                classifications.append({
                "column_name": column,
                 "attribute_list": [{"attribute_original_name": match_categories,
                                "calc_confidence_level": match_score,
                                "attribute_type": "Classification",
                                "GDPR_Classifications": gdpr_classifications}]})
            

        return {"data": classifications}
    
    """Following function is used to convert the result into Dataframe and print it"""
    def classify_data(self, df):
        try:    
            logger.info("Data classification started")
            classifications = self.calculate_classifications(df)
            logger.info("Data classification completed")
            return classifications
        except Exception as e:
            logger.error(f"Error in classify_data: {e}")
            raise