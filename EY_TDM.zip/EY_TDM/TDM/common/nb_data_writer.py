# Databricks notebook source
# MAGIC %run /Workspace/EY/EY_TDM/TDM/common/nb_logger

# COMMAND ----------

from pyspark.sql import SparkSession
import yaml
from io import BytesIO, StringIO
from azure.identity import ClientSecretCredential
from azure.storage.blob import BlobServiceClient, BlobClient
from azure.keyvault.secrets import SecretClient
import pandas as pd
from pyspark.sql.functions import col
from pyspark.sql.types import DecimalType, TimestampType
from pyspark.dbutils import DBUtils
logger = Logger(__name__).get_logger()


class DataWriter:
    def __init__(self, metadata, config_path):
        try:
            logger.info("Initializing DataWriter")
            self.metadata = metadata
            self.spark = SparkSession.builder.appName("TestDataManagement").getOrCreate()
            self.config_path = config_path
            self.conn_configs = self.load_connection_configs()
        except Exception as e:
            logger.error(f"Error initializing DataWriter: {e}")
            raise RuntimeError(f"Error initializing DataWriter: {e}")

    def load_connection_configs(self):
        try:
            with open(self.config_path, "r") as file:
                return yaml.safe_load(file)["connection"]
        except FileNotFoundError:
            raise RuntimeError(f"Configuration file {self.config_path} not found.")
        except Exception as e:
            logger.error(f"Error loading database configurations: {e}")
            raise RuntimeError(f"Error loading database configurations: {e}")

    def write_data(self, df):
        try:
            self.target = self.metadata.get("target")
            self.target_type = self.target.get("type")
            self.asset = self.target.get("asset")
            self.file_system_type = self.asset.get("system")

            logger.info(f"Writing data to {self.file_system_type} storage")

            if self.file_system_type in [ "azure_blob"]:
                return self.write_to_azure_storage(df)
            else:
                raise ValueError("Unsupported target type. Supported types are 'adls' and 'azure_blob'.")
        except Exception as e:
            logger.error(f"Error in write_data: {e}")
            raise RuntimeError(f"Error in write_data: {e}")

    def convert_to_primitive_types(self, df):
        """Converts DecimalType columns to float and TimestampType columns to string."""
        try:
            schema = df.schema.fields
            decimal_cols = [f.name for f in schema if isinstance(f.dataType, DecimalType)]
            timestamp_cols = [f.name for f in schema if isinstance(f.dataType, TimestampType)]

            # Convert DecimalType -> string
            for col_name in decimal_cols:
                df = df.withColumn(col_name, col(col_name).cast("string"))

            # Convert TimestampType -> string
            for col_name in timestamp_cols:
                df = df.withColumn(col_name, col(col_name).cast("string"))

            return df

        except Exception as e:
            logger.error(f"Error converting to primitive types: {e}")
            raise RuntimeError(f"Error converting to primitive types: {e}")

    def write_to_azure_storage(self, df):
        try:
            azure_config_name = self.asset.get("connection_name")
            azure_config = self.conn_configs.get(azure_config_name, {})
            if not azure_config:
                raise ValueError("Azure Storage configuration not found in config.yaml.")

            storage_account = azure_config.get("storage_account")
            container = azure_config.get("container")
            file_name = self.asset.get("file_name")
            file_format = self.asset.get("file_format")
            write_options = self.asset.get("write_options", {})

            # SAS Token authentication for Azure Blob Storage
            storage_account_key_secret = azure_config.get("storage_account_key_secret")
            secret_scope = azure_config.get("secret_scope")

            if not all([storage_account_key_secret, secret_scope]):
                raise ValueError("Missing required secret scopr or storage account key secret parameters for Azure Blob Storage.")

            # Retrieve SAS Token from Key Vault
            #keyvault_reader = KeyVaultReader(key_vault_url=key_vault_url)
            #sas_token = keyvault_reader.get_secret(secret_name=sas_token_secret_name)
            butils = DBUtils(self.spark)
            storage_account_key = dbutils.secrets.get(
            scope=secret_scope, key=storage_account_key_secret)

    

            # Use storage account key for authentication 
            blob_service_client = BlobServiceClient(account_url=f"https://{storage_account}.blob.core.windows.net", credential=storage_account_key)

            # Define the blob file path
            blob_path = f"wasbs://{container}@{storage_account}.blob.core.windows.net/{file_name}"

            # Convert non-primitive types before writing
            df = self.convert_to_primitive_types(df)

            # Coalesce to a single partition for writing
            df = df.coalesce(1)

            # Write DataFrame to a memory buffer (byte stream)
            byte_io = None
            if file_format == "csv":
                # Convert to Pandas first to write CSV
                csv_buffer = StringIO()
                df.toPandas().to_csv(csv_buffer, index=False)
                csv_buffer.seek(0)
                byte_io = csv_buffer.getvalue().encode('utf-8')
            elif file_format == "parquet":
                # Use Parquet writer
                parquet_buffer = BytesIO()
                df.write.parquet(parquet_buffer)
                parquet_buffer.seek(0)
                byte_io = parquet_buffer.read()
            else:
                raise ValueError(f"Unsupported file format: {file_format}")

            # Upload to Azure Blob Storage
            blob_client = blob_service_client.get_blob_client(container=container, blob=file_name)
            blob_client.upload_blob(byte_io, overwrite=True)

            logger.info(f"Data successfully written to Azure Blob Storage at {blob_path}")

        except Exception as e:
            logger.error(f"Error writing to Azure Storage: {e}")
            raise RuntimeError(f"Error writing to Azure Storage: {e}")
