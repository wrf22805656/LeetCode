# Databricks notebook source
# MAGIC %run /Workspace/EY/EY_TDM/TDM/common/nb_logger

# COMMAND ----------


from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, FloatType
from azure.core.exceptions import ResourceNotFoundError, ServiceRequestError
from azure.keyvault.secrets import SecretClient
import yaml
from azure.identity import ClientSecretCredential
from pyspark.dbutils import DBUtils
logger = Logger(__name__).get_logger()



class DataExtractor:
    def __init__(self, metadata,config_path):
        try:

            logger.info(f"Initializing DataExtractor with config file {config_path}")
            self.metadata = metadata
            self.spark = SparkSession.builder.appName("TestDataManagement").getOrCreate()
            self.config_path = config_path
            self.conn_configs = self.load_connection_configs()
            logger.info(str(self.conn_configs))           
        except Exception as e:
            logger.error(f"Error initializing DataExtractor: {e}")
            raise RuntimeError(f"Error initializing DataExtractor: {e}")


    def load_connection_configs(self):
        """Load conection configurations from the YAML file."""
        try:
            with open(self.config_path, "r") as file:
                return yaml.safe_load(file)["connection"]
        except FileNotFoundError:
            raise RuntimeError(f"Configuration file {self.config_path} not found.")
        except Exception as e:
            logger.error(f"Error loading database configurations: {e}")
            raise RuntimeError(f"Error loading database configurations: {e}")



    def extract_data(self):
        try:

            self.source = self.metadata.get("source")
            self.source_type = self.source.get("type")
            self.asset = self.source.get("asset")
            logger.info(f"Extracting data from {self.source_type} {self.asset} started")
            if self.source_type == "db":         
                return self.extract_from_table()
            elif self.source_type == "file":
                return self.read_file()
            else:
                raise ValueError("Unsupported source type. Supported types are 'table' and 'file'.")
            logger.info(f"Extracting data from {self.source_type} {self.asset} completed")
        except Exception as e:
            logger.error(f"Error in extract_data: {e}")
            raise RuntimeError(f"Error in extract_data: {e}")

    def read_file(self):
        try:
            self.file_system_type = self.asset.get("system")
            if self.file_system_type == "adls":
                return self.read_file_from_adls()
            elif self.file_system_type == "azure_blob":
                return self.read_file_from_blob()
            else:
                raise ValueError(f"Unsupported file source: {self.file_system_type}")
        except Exception as e:
            logger.error(f"Error reading file: {e}")
            raise



    def read_file_from_blob(self):
        try:
            # Extract Azure Blob configuration from YAML
            blob_connection_name = self.asset.get("connection_name")
            blob_config = self.conn_configs.get(blob_connection_name, {})
            if not blob_config:
                raise ValueError("Azure Blob configuration not found in config.yaml.")

            storage_account = blob_config.get("storage_account")
            if not storage_account:
                raise ValueError("Storage Account Name is not found in config.yaml.")

            container = blob_config.get("container")
            if not container:
                raise ValueError("Container Name is not found in config.yaml.")


            secret_scope  = blob_config.get("secret_scope")
            if not secret_scope:
                raise ValueError("Secret scope is not found in config.yaml.")


            storage_account_key_secret = blob_config.get("storage_account_key_secret")
            if not storage_account_key_secret:
                raise ValueError("Storage account key secret is not found in config.yaml.")

            # Initialize KeyVaultReader 
            #keyvaultreader = KeyVaultReader(key_vault_url=key_vault_url)
            #sas_token = keyvaultreader.get_secret(secret_name=sas_token_secret)
            dbutils = DBUtils(self.spark)
            storage_account_key = dbutils.secrets.get(
            scope=secret_scope, key=storage_account_key_secret)

            file_name = self.asset.get('file_name')
            file_format = self.asset.get('file_format')
            read_options = self.asset.get('read_options')

      

            #self.spark.conf.set(f"fs.azure.sas.{container}.{storage_account}.blob.core.windows.net", sas_token)
            # Set Spark configuration to use the storage account key
            self.spark.conf.set(f"fs.azure.account.key.{storage_account}.blob.core.windows.net", storage_account_key)


            # Construct the full file path in Azure Blob Storage using SAS token
            blob_path = f"wasbs://{container}@{storage_account}.blob.core.windows.net/{file_name}"

            logger.info(f"Reading file from Azure Blob Storage: {blob_path} having format {file_format} and options {read_options}")

            # Read the file from Azure Blob Storage using SAS token
            if file_format == "csv":
                if not read_options.get("header", False):
                    schema = self.get_schema_from_metadata()
                    read_options['schema'] = schema

                df_extract = self.spark.read.csv(blob_path, **(read_options))
                return df_extract
            elif file_format == "parquet":
                df_extract = self.spark.read.parquet(blob_path)
                return df_extract
            else:
                raise ValueError(f"Unsupported file type: {file_format}")
        except Exception as e:
            logger.error(f"Error reading from Azure Blob Storage: {e}")
            raise

        

    def read_file_from_adls(self):
        try:
            adls_connection_name = self.asset.get("connection_name")
            adls_config = self.conn_configs.get(adls_connection_name, {})
            if not adls_config:
                raise ValueError("ADLS configuration not found in config.yaml.")


            storage_account = adls_config.get("storage_account")
            if not storage_account:
                raise ValueError("Storage Account Name is not found in config.yaml.")

            container = adls_config.get("container")
            if not container:
                raise ValueError("Container Name is not found in config.yaml.")

            client_id = adls_config.get("client_id")
            if not client_id:
                raise ValueError("Client Id is not found in config.yaml.")

            client_secret = adls_config.get("client_secret")
            if not client_secret:
                raise ValueError("Client Secret is not found in config.yaml.")

            secret_scope = adls_config.get("secret_scope")
            if not secret_scope:
                raise ValueError("Secret scope is not found in config.yaml.")

            tenant_id = adls_config.get("tenant_id")
            if not tenant_id:
                raise ValueError("Tenant is not found in config.yaml.")

            # Initialize KeyVaultReader 
            #keyvaultreader = KeyVaultReader(key_vault_url=client_key_vault_url)
            #client_secret = keyvaultreader.get_secret(secret_name=client_key_vault_secret)
            dbutils = DBUtils(self.spark)
            client_key = dbutils.secrets.get(
            scope=secret_scope, key=client_secret)


            file_name = self.asset.get('file_name')
            file_format = self.asset.get('file_format')
            read_options = self.asset.get('read_options')
 
            spark.conf.set(f"fs.azure.account.auth.type.{storage_account}.dfs.core.windows.net", "OAuth")
            spark.conf.set(f"fs.azure.account.oauth.provider.type.{storage_account}.dfs.core.windows.net", "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider")
            spark.conf.set(f"fs.azure.account.oauth2.client.id.{storage_account}.dfs.core.windows.net", client_id)
            spark.conf.set(f"fs.azure.account.oauth2.client.secret.{storage_account}.dfs.core.windows.net", client_key)
            spark.conf.set(f"fs.azure.account.oauth2.client.endpoint.{storage_account}.dfs.core.windows.net", f"https://login.microsoftonline.com/{tenant_id}/oauth2/token")

            
           # Construct the full file path in ADLS
            adls_path = f"abfss://{container}@{storage_account}.dfs.core.windows.net/{file_name}"

            logger.info(f"Reading file from ADLS: {adls_path} having format {file_format} and options {read_options}")
           

            if file_format == "csv":
                if not read_options.get("header",False):
                   schema = self.get_schema_from_metadata()
                   read_options['schema'] = schema
                
                df_extract = self.spark.read.csv(adls_path, **(read_options))
                return df_extract
            elif file_format == "parquet":
                df_extract = self.spark.read.parquet(adls_path)
                return df_extract
            else:
                raise ValueError(f"Unsupported file type: {file_format}")
        except Exception as e:
            logger.error(f"Error reading from ADLS: {e}")
            raise



    def extract_from_table(self):
        try:

            self.db_type = self.metadata["source"]["asset"]["system"]
            if self.db_type == "snowflake":
                return self.extract_from_snowflake()
            elif self.db_type == "databricks":
                return self.extract_from_databricks()
            else:
                raise ValueError(f"Unsupported database type: {self.db_type}")
        except Exception as e:
            logger.error(f"Error extracting from table: {e}")
            raise RuntimeError(f"Error extracting from table: {e}")


    def extract_from_databricks(self):
        try:
            # Databricks connection details
            db_connection_name = self.asset["connection_name"]
            db_config = self.conn_configs.get(db_connection_name, {})
            if not db_config:
                raise ValueError("Databricks configuration not found in config.yaml.")

            host = db_config.get("host")
            if not host:
                raise ValueError("Host is not found in config.yaml.")

            token_secret = db_config.get("token_secret")
            if not token_secret:
                raise ValueError("Token secret is not found in config.yaml.")

            

            secret_scope = db_config.get("secret_scope")
            if not secret_scope:
                raise ValueError("Secret scope is not found in config.yaml.")


            dbutils = DBUtils(self.spark)
            token = dbutils.secrets.get(
            scope=secret_scope, key=token_secret)

            catalog_name = self.asset.get("catalog_name", "")
            schema_name = self.asset.get("schema_name", "")
            table_name = self.asset["table_name"]

            logger.info(f"Reading table from Databricks: {self.fq_table_name}")

            if not schema_name:
                raise ValueError("Schema is required for Databricks tables.")

            # Build the table path
            self.fq_table_name = f"{catalog_name}.{schema_name}.{table_name}"

            # Get sampling details
            self.sampling_detail = self.metadata.get("sampling", {})
            self.sampling_operator = self.sampling_detail.get("sampling_operator", "sql")
            self.sampling_method = self.sampling_detail.get("method", "random")

            # Generate the SQL query based on sampling type
            if self.sampling_operator == "sql":
                query = self.build_sampling_query()
            else:
                query = f"SELECT * FROM {self.fq_table_name}"

            logger.info(f"Executing SQL query: {query}")

            # Set the Databricks connection options
            self.spark.conf.set("spark.databricks.service.client.enabled", "true")
            self.spark.conf.set("spark.databricks.service.client.token", token)
            self.spark.conf.set("spark.databricks.service.client.endpoint", host)

            # Execute the query and return the DataFrame
            df_extract = self.spark.sql(query)
            return df_extract
        except Exception as e:
            logger.error(f"Error extracting from Databricks: {e}")
            raise RuntimeError(f"Error extracting from Databricks: {e}")



    def extract_from_snowflake(self):
        try:
            # Snowflake connection details
            db_connection_name = self.metadata["source"]["asset"]["connection_name"]
            db_config = self.conn_configs.get(db_connection_name, {})
            if not db_config:
                raise ValueError("Snowflake configuration not found in config.yaml.")


            host = db_config.get("host")
            if not host:
                raise ValueError("Host is not found in config.yaml.")

            database_name = db_config.get("database")
            if not database_name:
                raise ValueError("Database name not found in config.yaml.")

            schema_name = db_config.get("schema")
            if not schema_name:
                raise ValueError("Schema name not found in config.yaml.")

            warehouse = db_config.get("warehouse")
            if not warehouse:
                raise ValueError("Warehouse name not found in config.yaml.")

            role = db_config.get("role")
            if not role:
                raise ValueError("Role name not found in config.yaml.")

            user = db_config.get("user")
            if not user:
                raise ValueError("User name not found in config.yaml.")


            secret_scope = db_config.get("secret_scope")
            if not secret_scope:
                raise ValueError("Secret scope is stored not found in config.yaml.")


            pwd_secret = db_config.get("pwd_secret")
            if not pwd_secret:
                raise ValueError("Secret name where DB credential is stored not found in config.yaml.")

            connector_class = db_config.get("connector_class")
            if not connector_class:
                raise ValueError("DB connector class not found in config.yaml.")


            src_asset = self.metadata["source"]["asset"]
            self.table_name = src_asset["table_name"]
            self.schema_name = src_asset["schema_name"]
            self.fq_table_name = f"{database_name}.{self.schema_name}.{self.table_name}"
            

            #keyvaultreader = KeyVaultReader(key_vault_url=key_vault_url)
            #password = keyvaultreader.get_secret(secret_name=pwd_secret)
            dbutils = DBUtils(self.spark)
            password = dbutils.secrets.get(
            scope=secret_scope, key=pwd_secret)

            conn_options = {
                "sfURL": host,
                "sfDatabase": database_name,
                "sfSchema": schema_name,
                "sfWarehouse": warehouse,
                "sfRole": role,
                "sfUser": user,
                "sfPassword": password,
            }
 
            self.sampling_detail = self.metadata.get("sampling")
            self.sampling_operator = self.sampling_detail.get("sampling_operator")
            self.sampling_method = self.sampling_detail.get("method")


            logger.info(f"Reading table from Snowflake: {self.fq_table_name}")


            if self.sampling_operator == "sql":
                # Generate dynamic SQL for sampling (stratified or random)
                query = self.build_sampling_query()
            elif self.sampling_operator == "python":
                query = f"SELECT * FROM {self.fq_table_name} "
            else:
                pass
            logger.info( query)
            df_extract = self.spark.read.format(connector_class).options(**conn_options).option("query", query).load()
            df_extract.cache()
     
            
            if self.sampling_operator == 'sql' and self.sampling_method =='stratified':
                col_list = df_extract.columns
                col_upd_list = col_list[:-1]  # Exclude the last column
                df_extract = df_extract.select(col_upd_list)
            return df_extract
        except Exception as e:
            logger.error(f"Error extracting from Snowflake: {e}")
            raise RuntimeError(f"Error extracting from Snowflake: {e}")

    def build_sampling_query(self):
        try:

            if self.sampling_method == "random":

                if self.db_type == "snowflake":
                     query = f"SELECT * FROM {self.fq_table_name} TABLESAMPLE ({self.metadata['sampling']['sampling_pct']}) "
                elif self.db_type == "databricks":
                    query = f"SELECT * FROM {self.fq_table_name} TABLESAMPLE ({self.metadata['sampling']['sampling_pct']} PERCENT) "
               
                return query

            elif self.sampling_method == "stratified":
                strat_column = self.sampling_detail["strat_column"]
                sampling_pct = self.sampling_detail["sampling_pct"]
                query = f"""
    WITH strata_counts AS (
        SELECT 
            {strat_column}, 
            COUNT(*) AS group_count
        FROM {self.fq_table_name}
        GROUP BY {strat_column}
    ),
    strata_proportions AS (
        SELECT 
            a.{strat_column},
            a.group_count,
            (a.group_count * {sampling_pct}) / 100 AS sample_size
        FROM strata_counts a
    ),
    ranked_data AS (
        SELECT 
            *,
            ROW_NUMBER() OVER (PARTITION BY {strat_column} ORDER BY RANDOM()) AS row_num
        FROM {self.fq_table_name}
    ),
    stratified_sample AS (
        SELECT 
            a.*
        FROM ranked_data a
        JOIN strata_proportions b
        ON a.{strat_column} = b.{strat_column}
        WHERE a.row_num <= CEIL(b.sample_size)
    )
    SELECT *
    FROM stratified_sample;
    """
                return query
            else:
                raise ValueError(f"Unsupported sampling method: {self.sampling_method}")
        except Exception as e:
            logger.error(f"Error building dynamic SQL: {e}")
            raise RuntimeError(f"Error building dynamic SQL: {e}")

    def get_schema_from_metadata(self):
        """Generates the schema for the file from metadata"""
        try:
            schema_fields = []

            # chema is provided in the metadata as a list of column names and types
            schema_definition = self.asset.get('schema',[])

            for column in schema_definition:
                field_name = column["column_name"]
                field_type = column["data_type"]

                if field_type == "string":
                    schema_fields.append(StructField(field_name, StringType(), True))
                elif field_type == "int":
                    schema_fields.append(StructField(field_name, IntegerType(), True))
                elif field_type == "float":
                    schema_fields.append(StructField(field_name, FloatType(), True))
           

            return StructType(schema_fields)
        except Exception as e:
            logger.error(f"Error generating schema from metadata: {e}")
            raise RuntimeError(f"Error generating schema from metadata: {e}")
