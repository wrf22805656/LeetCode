# Databricks notebook source
# MAGIC %run /Workspace/EY/EY_TDM/TDM/common/nb_logger

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import udf, col
from pyspark.sql.types import StringType
import pandas as pd
import random
from faker import Faker
import secrets
import string
from datetime import datetime, timedelta
import calendar
import uuid
import sys
logger = Logger(__name__).get_logger()






class DataTransformer:
    """
    This class handles custom functions for generating fake data.
    """
    @staticmethod
    def generate_fake_data(classification_name):
        """
        Generate fake data based on the classification name.
        :param classification_name: The classification name for which fake data is generated.
        :return: Generated fake data or None if no mapping is found.
        """

        try:
            fake = Faker()

            # Define local mapping of Faker functions to classification names
            fake_data_mapping = {
            "classifier.Email":   fake.safe_email,
                "classifier.IPv6":   fake.ipv6,
                "classifier.IPv4":   fake.ipv4,
                "classifier.Credit Card":   fake.credit_card_number,
                "classifier.Url":   fake.url,
                "classifier.US SSN":   fake.ssn,
                "classifier.IBAN":   fake.iban,
                "classifier.Tokens, Keys and Secrets":   DataTransformer.generate_token,
                "classifier.Product Keys":   DataTransformer.generate_product_key,
                "classifier.IMEI":   DataTransformer.generate_imei,
                "classifier.US MBI":   DataTransformer.generate_mbi,
                "classifier.MAC Address":   DataTransformer.generate_mac_address,
                
                "classifier.Sexual Identity and Orientation (English)":   DataTransformer.generate_sexual_orientation,
                "classifier.Gender and Sex (English)":   DataTransformer.generate_gender,
                "classifier.US Ethnicity (Wide)":   DataTransformer.generate_us_ethnicity,
                "classifier.US Ethnicity (Medium)":   DataTransformer.generate_us_ethnicity,
                "classifier.Religion (English)":   DataTransformer.generate_religion,
                "classifier.Medical Condition (English)":   DataTransformer.generate_medical_condition,
                "classifier.Medical Treatments (English)":   DataTransformer.generate_medical_treatment,
                "classifier.Medication (English)":   DataTransformer.generate_medication,
                "classifier.US Phone Number (Narrow)":   fake.phone_number,
                "classifier.Californian Phone Number (Narrow)":   fake.phone_number,
                "classifier.Public IPv4 Address":   DataTransformer.generate_public_ipv4,
                "classifier.Vehicle Identification Number (VIN)":   DataTransformer.generate_vin,
                "classifier.Vehicle Manufacturer":   DataTransformer.generate_vehicle_manufacturer,
                "classifier.Car Model":   DataTransformer.generate_car_model,
                "classifier.California License Plate":   DataTransformer.generate_california_license_plate,
                "classifier.Policy Number":   DataTransformer.generate_policy_number,
                "classifier.Username and Explicit Password":   DataTransformer.generate_username_password,
                "classifier.Sexual Identity and Orientation (English) (Narrow)":   DataTransformer.generate_sexual_orientation,
                "classifier.Gender and Sex (English) (Narrow)":   DataTransformer.generate_gender,
                "classifier.Challenge Question (English)":   DataTransformer.generate_challenge_question,
                "classifier.US Political Affiliation":   DataTransformer.generate_us_political_affiliation,
                "classifier.Card verification value (CVV) near Expiration date":   DataTransformer.generate_cvv_and_expiration,
                "classifier.Credit Card near Card verification value (CVV)":   DataTransformer.generate_credit_card_and_cvv,
                "classifier.Credit Card near Personal identification number (PIN)":   DataTransformer.generate_credit_card_and_pin,
                "classifier.Individual Taxpayer Identification Number (ITIN)":   DataTransformer.generate_itin,
                "classifier.Personal identification number (PIN)":   DataTransformer.generate_pin,
                "classifier.Card verification value (CVV)":   DataTransformer.generate_cvv,
                "classifier.Cleartext Password near Term":   DataTransformer.generate_password,
                "classifier.Email and Cleartext Password":   DataTransformer.generate_email_and_password,
                "classifier.US Bank Account Number":   DataTransformer.generate_bank_account_number,
                "classifier.US Trade Union":   DataTransformer.generate_us_trade_union_membership,
                "classifier.ZIP+4 Code":   DataTransformer.generate_zip_plus_4,
                "classifier.Partial Date of Birth (DOB)":   DataTransformer.generate_partial_dob,
                "classifier.Income":   DataTransformer.generate_income,
                "classifier.Age":   DataTransformer.generate_age,
                "classifier.Marital Status":   DataTransformer.generate_marital_status,
                "classifier.US Geodemographic Segment":   DataTransformer.generate_us_geodemographic_segment,
                "classifier.US Visa Number":   DataTransformer.generate_us_visa_number,
                "classifier.US Given Name":   fake.first_name,
                "classifier.US Family Name":   fake.last_name,
                "classifier.Geolocation near Term":   DataTransformer.generate_geolocation_near_term,
                "classifier.Street Number and Name (English)":   DataTransformer.generate_us_street_address,
                "classifier.US SSN near Term":   DataTransformer.generate_ssn_near_term,
                "classifier.US Phone Number near Term":   DataTransformer.generate_phone_number_near_term,
                "classifier.US State":   DataTransformer.generate_us_state_or_territory,
                "classifier.Date of Death":   DataTransformer.generate_date_of_death,
                "classifier.Discharge Date":   DataTransformer.generate_date_of_discharge,
                "classifier.US County":   DataTransformer.generate_us_county,
                "classifier.Admission Date":   DataTransformer.generate_admission_date,
                "classifier.Country":   fake.country,
                "classifier.US Driver License Number":   DataTransformer.generate_driver_license_number_near_term,
                "classifier.US Populated Place":   DataTransformer.generate_populated_place,
                "classifier.ITIN near Term":   DataTransformer.generate_itin_near_term,
                "classifier.US SSN (Narrow)":   fake.ssn,
                "classifier.Credit Card Number near Term":   DataTransformer.generate_credit_card_near_term,
                "classifier.US Middle Name":   DataTransformer.generate_middle_name,
                "classifier.Country of Origin":   DataTransformer.generate_country_of_origin_near_term,
                "classifier.Country of Residence":   DataTransformer.generate_country_of_residence_near_term,
                "classifier.US Full Name":   fake.name,
                "classifier.US Given Name (Wide)":   fake.first_name,
                "classifier.US Family Name (Wide)":   fake.last_name,
                "classifier.Credit Card (Narrow)":   fake.credit_card_number,
                "classifier.California Driver License Number":   DataTransformer.generate_california_driver_license_number,
                "classifier.Dark Web URL (.onion)":   DataTransformer.generate_fake_onion_url,
                "classifier.US Area Code":   DataTransformer.generate_fake_area_code,
                "classifier.Masked Credit Card Number near Term":   DataTransformer.generate_masked_credit_card_near_term,
                "classifier.Masked US SSN near Term":   DataTransformer.generate_masked_ssn_near_term,
                "classifier.Last Four Credit Card Number Digits":   DataTransformer.generate_last_4_ccn,
                "classifier.Last Four US SSN Digits":   DataTransformer.generate_last_4_ssn,
                "classifier.US Adoption Taxpayer Identification Number (ATIN)":   DataTransformer.generate_us_atin,
                "classifier.US PTIN near Term":   DataTransformer.generate_us_ptin_near_term,
                "classifier.US EIN near Term":   DataTransformer.generate_us_ein_near_term,
                
                "classifier.ZIP Code":   DataTransformer.generate_us_zip_near_term,
                "classifier.US State or territory Abbreviation":   DataTransformer.generate_us_state_abbr,
                "classifier.US Address":   fake.address,
                "classifier.Country or Territory":   fake.country,
                "classifier.Fractional ABA Routing Number":   DataTransformer.generate_aba_rtn_fraction,
                "classifier.US SWIFT Code":   DataTransformer.generate_us_swift_code,
                "classifier.Health Plan Beneficiary Number":   DataTransformer.generate_health_plan_member_id_near_term,
                "classifier.Medical Record Number (MRN)":   DataTransformer.generate_medical_record_number_near_term,
                "classifier.Patient ID Number":   DataTransformer.generate_patient_id_near_term,
                "classifier.Loan ID Number":   DataTransformer.generate_loan_id_near_term,
                "classifier.CUI Banner Marking":   DataTransformer.generate_cui_banner,
                "classifier.CUI Portion Marking":   DataTransformer.generate_cui_portion,
                "classifier.CUI Designation Indicator":   DataTransformer.generate_cui_designation_indicator,
                "classifier.Legal Entity Identifier (LEI)":   DataTransformer.generate_lei,
                "classifier.ICD-10-CM Code":   DataTransformer.generate_icd10_code,
                "classifier.ICD-10-CM Code near Term":   DataTransformer.generate_icd10_code_near_term,
                "classifier.ICD-10 Code near Term":   DataTransformer.generate_icd10_code_near_term,
                "classifier.ZIP Code (Wide)":   fake.zipcode,
            
                "classifier.US Phone Number (Wide)":   fake.phone_number,
                "classifier.US Full Name (Wide)":   fake.name,
                "classifier.Income (Wide)":   DataTransformer.generate_income,
                "classifier.Magnetic Card Track 3":   DataTransformer.generate_track3_data,
                "classifier.Magnetic Card Track 3 (Wide)":   DataTransformer.generate_track3_data,
                "classifier.Employment Status (English)":   DataTransformer.generate_employment_status,
                "classifier.Employment Status (English) (Wide)":   DataTransformer.generate_employment_status,
                "classifier.Employment Date (English)":   DataTransformer.generate_employment_date,
                

                "classifier.Tokens, Keys and Secrets (Narrow)":   DataTransformer.generate_token,
                "classifier.UnionPay Credit Card Number":   DataTransformer.generate_unionpay_ccn,
                "classifier.Credit Card - MD":   fake.credit_card_number,
                "classifier.Apple IDFA":   DataTransformer.generate_apple_idfa,
                "classifier.Android ID":   DataTransformer.generate_android_id_near_term,
                

                "classifier.Bank Account Number - MD":   DataTransformer.generate_bank_account_number,
                "classifier.Card verification value (CVV) - MD":   DataTransformer.generate_cvv,
    
                "classifier.Social Security Number - MD":   fake.ssn,
                "classifier.Driver's License Number - MD":   DataTransformer.generate_us_driver_license_number,
                "classifier.Phone Number - MD":   fake.phone_number,
                "classifier.Income - MD":   DataTransformer.generate_income,
                
                "classifier.Passport Number": DataTransformer.generate_passport_number,
                "classifier.Medical License": DataTransformer.generate_medical_license_number,
                "classifier.Name of a City": DataTransformer.generate_us_city,
                "classifier.Date of Birth": DataTransformer.generate_dob,
                "classifier.US ISIN": DataTransformer.generate_us_isin,
                "classifier.ICD9 Number": DataTransformer.generate_icd9_code,
                "classifier.Person Type": DataTransformer.generate_person_type,
                "classifier.US Health Insurance Policy Number": DataTransformer.generate_health_insurance_policy,
                "classifier.Organization Name": DataTransformer.generate_organization_name,
                "classifier.US Voter Registration Number": DataTransformer.generate_voter_registration_number,
                "classifier.Driver's License State Issuer Code": DataTransformer.generate_dl_state_issuer,
                "classifier.US Vehicle License Plate Number": DataTransformer.generate_us_license_plate,
                "classifier.US State Identification Number": DataTransformer.generate_state_id,
                "classifier.US Work Permit Number": DataTransformer.generate_work_permit_number,
                "classifier.US Permanent Resident Card Number": DataTransformer.generate_green_card_number,
                "classifier.Student Identification Number": DataTransformer.generate_student_id,
                "classifier.Insurance Claim Number": DataTransformer.generate_insurance_claim_number,
                "classifier.ABA Routing Number": DataTransformer.generate_aba_routing_number,
                "classifier.Banking PIN Number": DataTransformer.generate_banking_pin,
                "classifier.MICR Routing Number": DataTransformer.generate_micr_routing_number,					
                "classifier.CUSIP Number": DataTransformer.generate_cusip,			
                "classifier.DEA Number": DataTransformer.generate_dea_number,			
                "classifier.Employer Identification Number (EIN)": DataTransformer.generate_ein,							
                "classifier.National Provider Identifier": DataTransformer.generate_npi,
                "classifier.Preparer Taxpayer ID Number": DataTransformer.generate_ptin,			
                "classifier.OMB Control Number": DataTransformer.generate_omb_control_number,			
                "classifier.Real Estate License Number": DataTransformer.generate_real_estate_license,			
                "classifier.US Tollfree Number": DataTransformer.generate_us_tollfree_number,			
                "classifier.US Taxpayer Reference Number": DataTransformer.generate_us_taxpayer_reference_number,			
                "classifier.Military ID Number": DataTransformer.generate_military_id_number,			
                "classifier.Alien Registration Number": DataTransformer.generate_alien_registration_number,			
                "classifier.Bar License Number": DataTransformer.generate_bar_license_number,			
                "classifier.DOT Number": DataTransformer.generate_dot_number,			
                "classifier.Geographic Data": DataTransformer.generate_lat_lon,										
                "classifier.Tax Identification Number": DataTransformer.generate_tin	,
                "classifier.Amount": DataTransformer.generate_bank_amount	

            }

            faker_func = fake_data_mapping.get(classification_name)
        
            if faker_func:
                return faker_func()
            return None
        except Exception as e:
            logger.info(f"Error generating fake data for {classification_name}: {e}")
            return None

    @staticmethod
    def generate_email():
        """
        Generate an email address from a predefined list of emails.
        :return: A random email from the list.
        """
        email_list = [
            "user1@example.com",
            "user2@example.com",
            "user3@example.com",
            "user4@example.com",
            "user5@example.com"
        ]
        return random.choice(email_list)
    
    @staticmethod
    def generate_token(length=32):
        """
        Generate a secure random token.
        :param length: Length of the token (default: 32).
        :return: A hex-encoded token string.
        """
        return secrets.token_hex(length // 2)  # Each byte is 2 hex chars
    
    @staticmethod
    def generate_product_key():
        """
        Generate a random product key in the format: 
        'XXXXX-XXXXX-XXXXX-XXXXX' (5 groups of 5 uppercase letters/numbers).
        
        :return: A fake product key string.
        """
        def random_group():
            return ''.join(random.choices(string.ascii_uppercase + string.digits, k=5))

        return '-'.join([random_group() for _ in range(5)])
    

    @staticmethod
    def generate_imei():
        """
        Generate a random 15-digit IMEI number with Luhn check digit.

        :return: A valid IMEI number as a string.
        """
        def luhn_checksum(num):
            """
            Calculate the Luhn checksum for an IMEI number.
            """
            def digits_of(n):
                return [int(d) for d in str(n)]
            
            digits = digits_of(num)
            odd_sum = sum(digits[-1::-2])
            even_sum = sum(sum(digits_of(d * 2)) for d in digits[-2::-2])
            return (odd_sum + even_sum) % 10

        def generate_luhn_valid_number():
            """
            Generate the first 14 digits randomly and calculate the 15th as the Luhn check digit.
            """
            imei_base = ''.join([str(random.randint(0, 9)) for _ in range(14)])
            check_digit = (10 - luhn_checksum(imei_base + "0")) % 10
            return imei_base + str(check_digit)

        return generate_luhn_valid_number()
    
    @staticmethod
    def generate_mbi():
        """
        Generate a fake US Medicare Beneficiary Identifier (MBI).
        
        :return: A valid MBI string in the format ANAN-NANN-NNNN.
        """
        # Allowed letters (excluding S, L, O, I, B, Z)
        allowed_letters = [ch for ch in string.ascii_uppercase if ch not in "SLOIBZ"]

        def random_letter():
            return random.choice(allowed_letters)

        def random_digit():
            return str(random.randint(0, 9))

        # Construct the MBI with required positions
        mbi = (
            random_letter() + random_digit() + random.choice(allowed_letters + list(map(str, range(10)))) +
            random_letter() + "-" + random_digit() + random_letter() + random_digit() + "-" +
            random_digit() + random_letter() + random_digit() + random_digit()
        )

        return mbi
    
    @staticmethod
    def generate_mac_address():
        """
        Generate a random MAC Address in the format XX:XX:XX:XX:XX:XX.
        
        :return: A valid MAC address string.
        """
        return ":".join(f"{random.randint(0, 255):02X}" for _ in range(6))
    
    @staticmethod
    def generate_sexual_orientation():
        """
        Generate a random sexual orientation from a predefined list.
        
        :return: A random sexual orientation string.
        """
        sexual_orientation_list = [
            "Heterosexual",
            "Homosexual",
            "Bisexual",
            "Asexual",
            "Pansexual",
            "Queer",
            "Demisexual",
            "Other"
        ]
        return random.choice(sexual_orientation_list)
    
    @staticmethod
    def generate_gender():
        """
        Generate a random gender from a predefined list.
        
        :return: A random gender string.
        """
        gender_list = [
            "Male",
            "Female",
            "Non-binary",
            "Genderfluid",
            "Agender",
            "Two-Spirit",
            "Bigender",
            "Other"
        ]
        return random.choice(gender_list)
    
    @staticmethod
    def generate_us_ethnicity():
        """
        Generate a random US ethnicity from a predefined list.
        
        :return: A random US ethnicity string.
        """
        ethnicity_list = [
            "White (Caucasian)",
            "Black or African American",
            "Hispanic or Latino",
            "Asian",
            "Native American or Alaska Native",
            "Pacific Islander",
            "Middle Eastern or North African",
            "Multiracial",
            "Other"
        ]
        return random.choice(ethnicity_list)
    

    @staticmethod
    def generate_religion():
        """
        Generate a random religion specific to the United States.
        
        :return: A random religion string.
        """
        religion_list = [
            "Protestant",
            "Catholic",
            "Evangelical",
            "Baptist",
            "Methodist",
            "Lutheran",
            "Pentecostal",
            "Non-denominational",
            "Orthodox Judaism",
            "Conservative Judaism",
            "Reform Judaism",
            "Sunni Islam",
            "Shia Islam",
            "Hinduism",
            "Buddhism",
            "Sikhism",
            "Unitarian Universalism",
            "Atheism",
            "Agnosticism",
            "Mormonism (Latter-Day Saints)",
            "Jehovah's Witnesses",
            "Other Christian",
            "Spiritual but not religious",
            "Native American religions",
            "No religion (Secular, Agnostic, Humanist)"
        ]
        return random.choice(religion_list)
    
    @staticmethod
    def generate_medical_condition():
        """
        Generate a random medical condition specific to the United States.
        
        :return: A random medical condition string.
        """
        medical_conditions_list = [
            "Hypertension (High Blood Pressure)",
            "Diabetes (Type 1)",
            "Diabetes (Type 2)",
            "Asthma",
            "Osteoarthritis",
            "Chronic Obstructive Pulmonary Disease (COPD)",
            "Chronic Pain",
            "Heart Disease",
            "Epilepsy",
            "Irritable Bowel Syndrome (IBS)",
            "Chronic Kidney Disease",
            "Sleep Apnea",
            "Obesity",
            "Flu (Influenza)",
            "Common Cold",
            "Pneumonia",
            "Acute Sinusitis",
            "Strep Throat",
            "Appendicitis",
            "Acute Myocardial Infarction (Heart Attack)",
            "Concussion",
            "Food Poisoning",
            "Depression",
            "Anxiety Disorders",
            "Post-Traumatic Stress Disorder (PTSD)",
            "Bipolar Disorder",
            "Schizophrenia",
            "Obsessive-Compulsive Disorder (OCD)",
            "Eating Disorders (Anorexia, Bulimia)",
            "Autism Spectrum Disorder (ASD)",
            "Attention-Deficit/Hyperactivity Disorder (ADHD)",
            "Breast Cancer",
            "Lung Cancer",
            "Prostate Cancer",
            "Colon Cancer",
            "Leukemia",
            "Lymphoma",
            "Skin Cancer (Melanoma, Basal Cell)",
            "Cervical Cancer",
            "Ovarian Cancer",
            "HIV/AIDS",
            "Tuberculosis",
            "Hepatitis (A, B, C)",
            "Malaria",
            "Measles",
            "Chickenpox",
            "Meningitis",
            "Cystic Fibrosis",
            "Duchenne Muscular Dystrophy",
            "Huntington's Disease",
            "Amyotrophic Lateral Sclerosis (ALS)",
            "Sickle Cell Disease",
            "Tay-Sachs Disease",
            "Allergies (Food, Pollen, Dust)",
            "Migraines",
            "Acid Reflux (GERD)",
            "Rheumatoid Arthritis",
            "Gout",
            "Hyperthyroidism",
            "Hypothyroidism",
            "Anemia",
            "Polycystic Ovary Syndrome (PCOS)",
            "Endometriosis"
        ]
        return random.choice(medical_conditions_list)
    

    @staticmethod
    def generate_medical_treatment():
        """
        Generate a random medical treatment specific to the United States.
        
        :return: A random medical treatment string.
        """
        medical_treatments_list = [
            "Amoxicillin (Antibiotic)",
            "Ciprofloxacin (Antibiotic)",
            "Ibuprofen (Pain Reliever)",
            "Acetaminophen (Pain Reliever)",
            "Fluoxetine (Antidepressant)",
            "Sertraline (Antidepressant)",
            "Lisinopril (Antihypertensive)",
            "Amlodipine (Antihypertensive)",
            "Insulin Glargine (Insulin)",
            "Insulin Lispro (Insulin)",
            "Metformin (Antidiabetic)",
            "Glimepiride (Antidiabetic)",
            "Methotrexate (Chemotherapy)",
            "Doxorubicin (Chemotherapy)",
            "Warfarin (Blood Thinner)",
            "Apixaban (Blood Thinner)",
            "Acyclovir (Antiviral)",
            "Oseltamivir (Antiviral)",
            "Prednisone (Steroid)",
            "Hydrocortisone (Steroid)",
            "Loratadine (Antihistamine)",
            "Cetirizine (Antihistamine)",
            "Methotrexate (Immunosuppressant)",
            "Cyclosporine (Immunosuppressant)",
            "Phenytoin (Anticonvulsant)",
            "Valproate (Anticonvulsant)",
            "Adalimumab (Biologic Therapy)",
            "Etanercept (Biologic Therapy)",
            "Atorvastatin (Statin)",
            "Simvastatin (Statin)",
            "Appendectomy (Appendix Removal)",
            "Coronary Artery Bypass Grafting (CABG)",
            "Knee Replacement Surgery",
            "Hip Replacement Surgery",
            "Cholecystectomy (Gallbladder Removal)",
            "Cesarean Section (C-Section)",
            "Hernia Repair Surgery",
            "Cataract Surgery",
            "Tonsillectomy (Tonsil Removal)",
            "Mastectomy (Breast Removal)",
            "Hysterectomy (Uterus Removal)",
            "Kidney Transplantation",
            "Organ Transplant (Liver, Heart, etc.)",
            "Spinal Fusion Surgery",
            "Brain Tumor Surgery",
            "Physiotherapy (Physical Therapy)",
            "Occupational Therapy",
            "Speech Therapy",
            "Cardiac Rehabilitation",
            "Neurorehabilitation (Stroke Recovery)",
            "Pulmonary Rehabilitation (COPD)",
            "Pain Management Programs",
            "Hydrotherapy (Water Therapy)",
            "Cognitive Behavioral Therapy (CBT)",
            "Dialysis (Kidney Failure)",
            "Radiotherapy (Radiation Therapy)",
            "Electroconvulsive Therapy (ECT)",
            "Acupuncture",
            "Chiropractic Care",
            "Stem Cell Therapy",
            "Gene Therapy",
            "Psychotherapy (CBT, DBT)",
            "Palliative Care",
            "IV Fluids and Hydration",
            "Blood Transfusions",
            "Nutritional Support (Feeding Tubes)",
            "Laser Therapy",
            "Deep Brain Stimulation (DBS)"
        ]
        return random.choice(medical_treatments_list)
    

    @staticmethod
    def generate_medication():
        """
        Generate a random medication used in the United States.
        
        :return: A random medication name and its classification.
        """
        medication_list = [
            ("Acetaminophen (Tylenol)", "Pain Reliever"),
            ("Ibuprofen (Advil, Motrin)", "Pain Reliever"),
            ("Naproxen (Aleve)", "Pain Reliever"),
            ("Aspirin", "Pain Reliever"),
            ("Tramadol", "Pain Reliever"),
            ("Oxycodone (Percocet)", "Pain Reliever"),
            ("Hydrocodone (Vicodin)", "Pain Reliever"),
            ("Fentanyl", "Pain Reliever"),
            ("Amoxicillin", "Antibiotic"),
            ("Ciprofloxacin", "Antibiotic"),
            ("Azithromycin (Zithromax)", "Antibiotic"),
            ("Levofloxacin (Levaquin)", "Antibiotic"),
            ("Doxycycline", "Antibiotic"),
            ("Clindamycin", "Antibiotic"),
            ("Cephalexin (Keflex)", "Antibiotic"),
            ("Fluoxetine (Prozac)", "Antidepressant"),
            ("Sertraline (Zoloft)", "Antidepressant"),
            ("Citalopram (Celexa)", "Antidepressant"),
            ("Paroxetine (Paxil)", "Antidepressant"),
            ("Duloxetine (Cymbalta)", "Antidepressant"),
            ("Trazodone", "Antidepressant"),
            ("Lisinopril (Prinivil, Zestril)", "Antihypertensive"),
            ("Amlodipine (Norvasc)", "Antihypertensive"),
            ("Losartan (Cozaar)", "Antihypertensive"),
            ("Hydrochlorothiazide (HCTZ)", "Antihypertensive"),
            ("Atenolol (Tenormin)", "Antihypertensive"),
            ("Metformin", "Antidiabetic"),
            ("Insulin Glargine (Lantus)", "Antidiabetic"),
            ("Glimepiride (Amaryl)", "Antidiabetic"),
            ("Sitagliptin (Januvia)", "Antidiabetic"),
            ("Pioglitazone (Actos)", "Antidiabetic"),
            ("Prednisone (Steroid)", "Anti-inflammatory"),
            ("Methylprednisolone (Medrol)", "Anti-inflammatory"),
            ("Dexamethasone", "Anti-inflammatory"),
            ("Celecoxib (Celebrex)", "Anti-inflammatory"),
            ("Atorvastatin (Lipitor)", "Cholesterol Medication"),
            ("Simvastatin (Zocor)", "Cholesterol Medication"),
            ("Rosuvastatin (Crestor)", "Cholesterol Medication"),
            ("Pravastatin (Pravachol)", "Cholesterol Medication"),
            ("Risperidone (Risperdal)", "Antipsychotic"),
            ("Olanzapine (Zyprexa)", "Antipsychotic"),
            ("Quetiapine (Seroquel)", "Antipsychotic"),
            ("Aripiprazole (Abilify)", "Antipsychotic"),
            ("Loratadine (Claritin)", "Antihistamine"),
            ("Cetirizine (Zyrtec)", "Antihistamine"),
            ("Diphenhydramine (Benadryl)", "Antihistamine"),
            ("Fexofenadine (Allegra)", "Antihistamine"),
            ("Omeprazole (Prilosec)", "Antacid"),
            ("Esomeprazole (Nexium)", "Antacid"),
            ("Ranitidine (Zantac)", "Antacid"),
            ("Famotidine (Pepcid)", "Antacid"),
            ("Melatonin", "Sleep Aid"),
            ("Zolpidem (Ambien)", "Sleep Aid"),
            ("Eszopiclone (Lunesta)", "Sleep Aid"),
            ("Hydrocortisone Cream", "Topical Medication"),
            ("Neosporin (Triple Antibiotic Ointment)", "Topical Medication"),
            ("Lidocaine Cream (Numbing Cream)", "Topical Medication"),
            ("Influenza Vaccine (Flu Shot)", "Vaccine"),
            ("COVID-19 Vaccine (Pfizer, Moderna)", "Vaccine"),
            ("Hepatitis B Vaccine", "Vaccine"),
            ("Measles-Mumps-Rubella Vaccine (MMR)", "Vaccine"),
            ("Levothyroxine (Synthroid)", "Hormonal Medication"),
            ("Estrogen (Premarin)", "Hormonal Medication"),
            ("Testosterone", "Hormonal Medication"),
            ("Oral Contraceptives (Birth Control Pills)", "Hormonal Medication"),
            ("Benadryl (Diphenhydramine)", "OTC Medication"),
            ("Advil (Ibuprofen)", "OTC Medication"),
            ("Aleve (Naproxen)", "OTC Medication"),
            ("Pepto-Bismol (Bismuth Subsalicylate)", "OTC Medication"),
            ("Sudafed (Pseudoephedrine)", "OTC Medication")
        ]
        medication = random.choice(medication_list)
        return medication[0]
    
    @staticmethod
    def generate_public_ipv4():
        """
        Generate a random public IPv4 address (excludes private IP ranges).
        
        :return: A random public IPv4 address.
        """
        fake = Faker()

        # Define valid public IPv4 address ranges (not including private ranges)
        # Public IPv4 address ranges (not private or reserved ranges)
        public_ip_ranges = [
            (1, 126),        # Class A (1.0.0.0 to 126.0.0.0)
            (128, 191),      # Class B (128.0.0.0 to 191.255.255.255)
            (192, 223),      # Class C (192.0.0.0 to 223.255.255.255) excluding private ranges
            (224, 239)       # Multicast (224.0.0.0 to 239.255.255.255)
        ]

        # Generate the first octet that falls within a public range
        first_octet_range = random.choice(public_ip_ranges)
        first_octet = random.randint(first_octet_range[0], first_octet_range[1])

        # The next three octets can be any value between 0 and 255
        second_octet = random.randint(0, 255)
        third_octet = random.randint(0, 255)
        fourth_octet = random.randint(0, 255)

        # Ensure it's a valid public IPv4 address
        if first_octet == 10 or (first_octet == 172 and second_octet in range(16, 32)) or (first_octet == 192 and second_octet == 168):
            # Avoid private address spaces (10.x.x.x, 172.16.x.x to 172.31.x.x, 192.168.x.x)
            return DataTransformer.generate_public_ipv4()

        # Return the generated public IPv4 address
        return f"{first_octet}.{second_octet}.{third_octet}.{fourth_octet}"
    

    @staticmethod
    def generate_vin():
        """
        Generate a random Vehicle Identification Number (VIN).
        
        :return: A randomly generated VIN.
        """
        # Define possible characters and digits for VIN generation
        allowed_letters = string.ascii_uppercase.replace('I', '').replace('O', '').replace('Q', '')  # Exclude I, O, Q
        allowed_digits = string.digits
        
        # Generate the World Manufacturer Identifier (WMI) - first 3 characters
        wmi = ''.join(random.choices(allowed_letters + allowed_digits, k=3))
        
        # Generate the Vehicle Descriptor Section (VDS) - next 6 characters (4-9)
        vds = ''.join(random.choices(allowed_letters + allowed_digits, k=6))
        
        # Generate the Vehicle Identifier Section (VIS) - last 8 characters (10-17)
        # The 10th character represents the model year (A=1980, B=1981, ..., Y=2000, 1=2001, ..., 9=2009, etc.)
        model_year = random.choice(string.ascii_uppercase + string.digits)  # Random year letter or digit (basic simulation)
        plant_code = random.choice(allowed_letters)  # Random plant code (single letter)
        serial_number = ''.join(random.choices(allowed_letters + allowed_digits, k=6))  # Random serial number
        
        # Construct the full VIN
        vin = wmi + vds + model_year + plant_code + serial_number
        return vin
    
    @staticmethod
    def generate_vehicle_manufacturer():
        """
        Generate a random vehicle manufacturer name.
        
        :return: A randomly generated vehicle manufacturer.
        """
        # List of some major vehicle manufacturers (could be expanded as needed)
        manufacturers = [
            "Toyota", "Ford", "Honda", "Chevrolet", "Nissan", 
            "BMW", "Mercedes-Benz", "Volkswagen", "Hyundai", 
            "Audi", "Kia", "Tesla", "Subaru", "Mazda", 
            "Chrysler", "Lexus", "GMC", "Jeep", "Buick", 
            "Porsche", "Land Rover", "Jaguar", "Cadillac", 
            "Ram", "Acura", "Mitsubishi", "Infiniti"
        ]
        
        # Randomly choose a manufacturer from the list
        manufacturer = random.choice(manufacturers)
        return manufacturer
    
    @staticmethod
    def generate_car_model():
        """
        Generate a random car model name based on a vehicle manufacturer.
        
        :return: A randomly generated car model name.
        """
        # Dictionary of vehicle manufacturers with corresponding car models
        car_models = {
            "Toyota": ["Corolla", "Camry", "Hilux", "Land Cruiser", "RAV4"],
            "Ford": ["Focus", "Mustang", "F-150", "Explorer", "Fusion"],
            "Honda": ["Civic", "Accord", "CR-V", "Pilot", "Fit"],
            "Chevrolet": ["Malibu", "Impala", "Silverado", "Equinox", "Traverse"],
            "Nissan": ["Altima", "Maxima", "Rogue", "370Z", "Murano"],
            "BMW": ["3 Series", "5 Series", "X5", "M3", "X3"],
            "Mercedes-Benz": ["C-Class", "E-Class", "S-Class", "GLC", "A-Class"],
            "Volkswagen": ["Golf", "Passat", "Jetta", "Tiguan", "Arteon"],
            "Hyundai": ["Elantra", "Sonata", "Tucson", "Santa Fe", "Kona"],
            "Audi": ["A3", "A4", "A6", "Q5", "Q7"],
            "Kia": ["Optima", "Soul", "Sportage", "Forte", "Sorrento"],
            "Tesla": ["Model S", "Model 3", "Model X", "Model Y"],
            "Subaru": ["Impreza", "Outback", "Forester", "Legacy", "Crosstrek"],
            "Mazda": ["CX-5", "Mazda3", "Mazda6", "MX-5 Miata", "CX-9"],
            "Chrysler": ["300", "Pacifica", "Voyager", "Aspen"],
            "Lexus": ["RX", "ES", "NX", "GX", "LS"],
            "GMC": ["Sierra", "Yukon", "Acadia", "Canyon", "Terrain"],
            "Jeep": ["Wrangler", "Cherokee", "Grand Cherokee", "Renegade", "Compass"],
            "Buick": ["Enclave", "Encore", "LaCrosse", "Regal"],
            "Porsche": ["911", "Cayenne", "Macan", "Panamera", "Taycan"],
            "Land Rover": ["Range Rover", "Defender", "Discovery", "Evoque"],
            "Jaguar": ["F-Type", "XE", "XF", "I-PACE", "XJ"],
            "Cadillac": ["Escalade", "CTS", "XT5", "XT6", "CT5"],
            "Ram": ["1500", "2500", "3500", "ProMaster", "Rebel"],
            "Acura": ["MDX", "RDX", "TLX", "ILX", "NSX"],
            "Mitsubishi": ["Outlander", "Eclipse Cross", "Mirage", "Pajero"],
            "Infiniti": ["Q50", "QX60", "QX80", "QX50", "Q60"]
        }
        
        # Choose a random manufacturer
        manufacturer = random.choice(list(car_models.keys()))
        
        # Choose a random model for the selected manufacturer
        model = random.choice(car_models[manufacturer])
        
        # Return the manufacturer and model combination
        return f"{manufacturer} {model}"
    
    @staticmethod
    def generate_california_license_plate():
        """
        Generate a random California license plate in the format '1ABC234' or '7XYZ567'.
        
        :return: A randomly generated California license plate.
        """
        # Choose either '1' or '7' for the first digit
        first_digit = random.choice(['1', '7'])

        # Generate three random uppercase letters
        letters = ''.join(random.choices(string.ascii_uppercase, k=3))

        # Generate three random digits
        digits = ''.join(random.choices(string.digits, k=3))

        # Combine all parts to form the license plate
        license_plate = f"{first_digit}{letters}{digits}"

        return license_plate
    
    @staticmethod
    def generate_policy_number():
        """
        Generate a random US policy number in the format of 'ABC1234567' or 'P123-4567890'.
        
        :return: A randomly generated US policy number.
        """
        # Choose whether the policy number will have a prefix
        prefix_choices = [True, False]
        use_prefix = random.choice(prefix_choices)

        # If using a prefix, generate random letters followed by numbers
        if use_prefix:
            # Generate 3 random letters
            prefix = ''.join(random.choices(string.ascii_uppercase, k=3))
            # Generate 7 random digits
            digits = ''.join(random.choices(string.digits, k=7))
            return f"{prefix}{digits}"
        else:
            # No prefix, just generate 10 random digits
            return ''.join(random.choices(string.digits, k=10))
        

    @staticmethod
    def generate_username_password():
        """
        Generate a random username and explicit password in the format:
        'username:<username>; pw=<password>'
        
        :return: A string with the format 'username:<random_name>; pw=<random_password>'
        """
        fake = Faker()
        
        # Generate random username (first name + last name pattern)
        username = fake.first_name().lower() + random.choice(['', random.choice(string.ascii_lowercase)])
        
        # Generate random password (mix of letters, digits, and symbols)
        password_length = random.randint(8, 12)  # Random length between 8 and 12
        password = ''.join(random.choices(string.ascii_letters + string.digits + string.punctuation, k=password_length))
        
        # Create the final structure
        return f"username:{username}; pw={password}"
    
    @staticmethod
    def generate_challenge_question():
        """
        Generate a challenge question with PIA (Personally Identifiable Information) data.
        
        :return: A tuple (question, answer) where:
                question: A challenge question string
                answer: The answer to the challenge question (randomly generated)
        """
        fake = Faker()

        # List of possible challenge questions
        questions = [
            "What is your mother's maiden name?",
            "What city were you born in?",
            "What is the name of your first pet?",
            "What is your favorite color?",
            "What is your high school name?",
            "What was the name of your first school?",
            "What is your father’s middle name?",
            "In which city did you meet your spouse?"
        ]
        
        # Select a random question
        question = random.choice(questions)
        
        # Generate a plausible answer based on the question
        if question == "What is your mother's maiden name?":
            answer = fake.last_name()
        elif question == "What city were you born in?":
            answer = fake.city()
        elif question == "What is the name of your first pet?":
            answer = fake.word()  # Could be a random word, simulating a pet name
        elif question == "What is your favorite color?":
            answer = random.choice(["Red", "Blue", "Green", "Yellow", "Black", "White"])
        elif question == "What is your high school name?":
            answer = fake.company()
        elif question == "What was the name of your first school?":
            answer = fake.company()
        elif question == "What is your father’s middle name?":
            answer = fake.first_name()
        elif question == "In which city did you meet your spouse?":
            answer = fake.city()

        return question + '' + answer
    
    @staticmethod
    def generate_us_political_affiliation():
        """
        Generate a random US Political Affiliation (e.g., Democrat, Republican, Independent, etc.).
        
        :return: A string representing a political affiliation.
        """
        # List of possible US political affiliations
        political_affiliations = [
            "Democrat", 
            "Republican", 
            "Independent", 
            "Libertarian", 
            "Green Party", 
            "Constitution Party", 
            "Other"
        ]
        
        # Select a random political affiliation
        return random.choice(political_affiliations)
    
    @staticmethod
    def generate_cvv_and_expiration():
        """
        Generate a fake card verification value (CVV) near the expiration date of a credit card.
        
        :return: A tuple containing the CVV and expiration date.
        """
        # Generate CVV (3 digits for most cards, 4 digits for American Express)
        cvv = random.randint(100, 999)  # 3-digit CVV
        
        # Optionally, for American Express, you could generate a 4-digit CVV (optional, depending on your use case)
        # cvv = random.randint(1000, 9999)  # Uncomment this line to generate 4-digit CVV for Amex
        
        # Generate a fake expiration date (usually 1-5 years from now)
        current_date = datetime.now()
        expiration_year = current_date.year + random.randint(1, 5)
        expiration_month = random.randint(1, 12)
        
        # Ensure the expiration date is in the future
        expiration_date = datetime(expiration_year, expiration_month, 1) + timedelta(days=30)
        expiration_date_str = expiration_date.strftime("%m/%y")  # Format as MM/YY
 
        return f"CVV: {cvv}, Expiration Date: {expiration_date_str}"
    
    @staticmethod
    def generate_credit_card_and_cvv():
        """
        Generate a fake credit card number and its associated CVV.
        
        :return: A tuple containing the Credit Card Number and CVV.
        """
        # Generate a fake credit card number using the Luhn algorithm
        credit_card_number = DataTransformer.generate_credit_card_number()
        
        # Generate a fake CVV (3 digits for most cards, 4 digits for American Express)
        cvv = random.randint(100, 999)  # 3-digit CVV
        
        # Optionally, for American Express, you could generate a 4-digit CVV (optional, depending on your use case)
        # cvv = random.randint(1000, 9999)  # Uncomment to generate 4-digit CVV for Amex

        return f"Credit Card Number: {credit_card_number}, CVV: {cvv}"
    

    @staticmethod
    def generate_credit_card_and_pin():
        """
        Generate a fake credit card number and its associated PIN.

        :return: A tuple containing the Credit Card Number and PIN.
        """
        # Generate a fake credit card number using the Luhn algorithm
        credit_card_number = DataTransformer.generate_credit_card_number()

        # Generate a fake PIN (4 digits)
        pin = random.randint(1000, 9999)  # 4-digit PIN

        return f"Credit Card Number: {credit_card_number}, PIN: {pin}"

    @staticmethod
    def generate_credit_card_number():
        """
        Generate a fake credit card number using the Luhn algorithm (for validity).

        :return: A valid, fake credit card number.
        """
        # Generate a random 15 digits (for a valid card number, 16th digit will be the checksum)
        card_number = [random.randint(1, 9)]  # Start with a non-zero digit for the first digit
        card_number += [random.randint(0, 9) for _ in range(14)]  # Generate 14 random digits

        # Luhn algorithm to calculate the checksum (last digit)
        checksum = DataTransformer.luhn_checksum(''.join(map(str, card_number)))  # Pass as string
        card_number.append(checksum)  # Append the checksum as the last digit

        # Convert the card number to a string
        return ''.join(map(str, card_number))

    @staticmethod
    def luhn_checksum(card_number):
        """
        Implement the Luhn algorithm to calculate the checksum for the credit card number.

        :return: The last digit (checksum) to make the card number valid.
        """
        def digits_of(n):
            return [int(digit) for digit in str(n)]  # Ensure n is converted to a string

        digits = digits_of(card_number)  # Convert full card number string into a list of integers
        odd_digits = digits[-1::-2]
        even_digits = digits[-2::-2]

        checksum = sum(odd_digits)
        for d in even_digits:
            checksum += sum(digits_of(d * 2))

        return (10 - (checksum % 10)) % 10  # Return a single digit
    

    @staticmethod
    def generate_itin():
        """
        Generate a fake U.S. Individual Taxpayer Identification Number (ITIN).

        :return: A fake ITIN formatted as '9XX-XX-XXXX'.
        """
        # Generate the first digit as 9, which is characteristic of ITINs
        first_digit = 9
        
        # Generate the next 2 digits (1st group of 2 digits)
        second_group = random.randint(10, 99)

        # Generate the next 2 digits (2nd group of 2 digits)
        third_group = random.randint(10, 99)

        # Generate the last 4 digits (final group of 4 digits)
        last_group = random.randint(1000, 9999)

        # Format the ITIN as '9XX-XX-XXXX'
        itin = f"{first_digit}{second_group:02d}-{third_group:02d}-{last_group:04d}"

        return itin
    
    @staticmethod
    def generate_pin():
        """
        Generate a fake 4-digit Personal Identification Number (PIN).
        
        :return: A fake PIN formatted as 'XXXX'.
        """
        # Generate a 4-digit PIN between 0000 and 9999
        pin = random.randint(1000, 9999)

        return str(pin)
    


    @staticmethod
    def generate_cvv(card_type="mastercard"):
        """
        Generate a fake Card Verification Value (CVV).
        
        :param card_type: Type of card ('mastercard', 'visa', 'amex'). Default is 'mastercard'.
        :return: A fake CVV formatted as a string (either 3 or 4 digits).
        """
        if card_type == "amex":
            # American Express CVV is 4 digits
            cvv = random.randint(1000, 9999)
        else:
            # Visa/Mastercard CVV is 3 digits
            cvv = random.randint(100, 999)

        return str(cvv)
    

    @staticmethod
    def generate_password():
        """
        Generate a fake cleartext password.
        
        :return: A fake password string.
        """
        password_length = random.randint(8, 16)  # Length of the password between 8 and 16 characters
        password_chars = string.ascii_letters + string.digits + string.punctuation  # Available characters

        # Generate a random password using the available characters
        password = ''.join(random.choice(password_chars) for i in range(password_length))

        return password

    @staticmethod
    def generate_email_and_password():
        """
        Generate both a fake email address and a cleartext password in one method.
        
        :return: A tuple containing the fake email and cleartext password.
        """
        fake = Faker()

        # Generate a random email using Faker
        fake_email = fake.email()

        # Generate a random password between 8 and 16 characters
        password_length = random.randint(8, 16)
        password_chars = string.ascii_letters + string.digits + string.punctuation

        # Generate the password by picking random characters
        fake_password = ''.join(random.choice(password_chars) for i in range(password_length))

        return fake_email +''  + fake_password
    
    @staticmethod
    def generate_bank_account_number():
        """
        Generate a fake US bank account number.

        :return: A fake US bank account number (9 to 12 digits).
        """
        # Generate a random bank account number with 9 to 12 digits
        account_length = random.randint(9, 12)  # US account numbers are typically between 9 to 12 digits
        bank_account_number = ''.join(random.choices('0123456789', k=account_length))
        
        return bank_account_number
    

    @staticmethod
    def generate_passport_number():
        """
        Generate a fake US passport number.

        :return: A fake US passport number (9 characters, can include letters and digits).
        """
        # Passport number format: 1 or 2 letters followed by 7 or 8 digits
        letters = random.choices(string.ascii_uppercase, k=1)  # Start with a letter (A-Z)
        digits = ''.join(random.choices(string.digits, k=8))  # 8 digits following the letter

        # Combine to form a fake US passport number
        passport_number = ''.join(letters) + digits
        
        return passport_number
    

    @staticmethod
    def generate_us_trade_union_membership(union_name="SEIU"):
        """
        Generate a fake US Trade Union membership number for a specified union.

        :param union_name: Name of the trade union (default is "SEIU").
        :return: A fake US Trade Union membership number.
        """
        # Generate a random membership number (6 digits)
        membership_number = ''.join(random.choices(string.digits, k=6))

        # Combine the union name (abbreviated) and the membership number
        # For SEIU, we'll use the abbreviation "SEIU"
        trade_union_id = f"{union_name}-{membership_number}"
        
        return trade_union_id
    

    @staticmethod
    def generate_us_trade_union_membership():
        """
        Generate a fake US Trade Union membership number for a randomly selected union.

        :return: A fake US Trade Union membership number with the randomly selected union name.
        """
        # List of some common US trade unions
        union_names = [
            "SEIU",            # Service Employees International Union
            "AFL-CIO",         # American Federation of Labor and Congress of Industrial Organizations
            "IBEW",            # International Brotherhood of Electrical Workers
            "UAW",             # United Auto Workers
            "NEA",             # National Education Association
            "AFSCME",          # American Federation of State, County, and Municipal Employees
            "Teamsters",       # International Brotherhood of Teamsters
            "CWA",             # Communication Workers of America
            "NNU",             # National Nurses United
            "UPIU"             # United Paperworkers International Union
        ]
        
        # Randomly select a union name
        selected_union = random.choice(union_names)

        # Generate a random 6-digit membership number
        membership_number = ''.join(random.choices(string.digits, k=6))

        # Combine the union name and the membership number
        trade_union_id = f"{selected_union}-{membership_number}"
        
        return trade_union_id
    

    @staticmethod
    def generate_zip_plus_4():
        """
        Generate a fake US ZIP+4 code.

        :return: A fake US ZIP+4 code in the format XXXXX-XXXX.
        """
        # Generate a random 5-digit ZIP code
        zip_code = ''.join(random.choices('0123456789', k=5))

        # Generate a random 4-digit extension
        zip_extension = ''.join(random.choices('0123456789', k=4))

        # Combine them into the ZIP+4 format
        zip_plus_4 = f"{zip_code}-{zip_extension}"
        
        return zip_plus_4
    
    @staticmethod
    def generate_partial_dob():
        """
        Generate a partial Date of Birth (DOB) in the format 'DOB: June 1971'.
        
        :return: A fake partial DOB (Month Year).
        """
        # Initialize Faker instance to generate random years
        fake = Faker()

        # Generate a random month name
        month = fake.month_name()

        # Generate a random year between 1900 and the current year
        year = random.randint(1900, 2025)

        # Combine them into the desired format
        partial_dob = f"DOB: {month} {year}"

        return partial_dob
    
    @staticmethod
    def generate_income(min_income=20000, max_income=200000):
        """
        Generate a fake income value within a specified range and return it in the format 'Income: $90,000'.
        
        :param min_income: Minimum income (default is 20,000).
        :param max_income: Maximum income (default is 200,000).
        :return: A formatted income string like 'Income: $90,000'.
        """
        # Generate a random income within the specified range
        income = random.randint(min_income, max_income)

        # Format the income with a dollar sign and add the 'Income: ' prefix
        formatted_income = f"Income: ${income:,}"

        return formatted_income
    
    @staticmethod
    def generate_age(min_age=18, max_age=100):
        """
        Generate a fake age value within a specified range and return it in the format 'Age: 34'.
        
        :param min_age: Minimum age (default is 18).
        :param max_age: Maximum age (default is 100).
        :return: A formatted age string like 'Age: 34'.
        """
        # Generate a random age within the specified range
        age = random.randint(min_age, max_age)

        # Format the age with the 'Age: ' prefix
        formatted_age = f"Age: {age}"

        return formatted_age
    
    @staticmethod
    def generate_marital_status():
        """
        Generate a fake marital status value and return it in the format 'Marital Status: Married' or 'Marital Status: Single'.
        
        :return: A formatted marital status string like 'Marital Status: Married'.
        """
        marital_statuses = ["Married", "Single", "Divorced", "Widowed", "Separated", "In a relationship"]
        
        # Randomly select a marital status
        marital_status = random.choice(marital_statuses)

        # Format the marital status with the 'Marital Status: ' prefix
        formatted_status = f"Marital Status: {marital_status}"

        return formatted_status
    
    @staticmethod
    def generate_us_geodemographic_segment():
        """
        Generate a fake US geodemographic segment such as 'Career Climbers' or other demographic segments.
        
        :return: A formatted geodemographic segment string.
        """
        geodemographic_segments = [
            "Career Climbers", "Urban Achievers", "Suburban Families", "Blue Collar Workers", 
            "Tech Enthusiasts", "Empty Nesters", "Retired Professionals", "Eco-Conscious Shoppers",
            "Young Professionals", "Affluent Families", "Budget-Conscious Shoppers", "Millennial Entrepreneurs"
        ]
        
        # Randomly select a geodemographic segment
        segment = random.choice(geodemographic_segments)

        # Return the geodemographic segment
        return segment
    

    @staticmethod
    def generate_us_visa_number():
        """
        Generate a fake US visa number such as 'Visa No F0441755'.
        
        :return: A formatted visa number string.
        """
        # Generate a random letter (uppercase)
        letter = random.choice(string.ascii_uppercase)
        
        # Generate a random 7-digit number
        digits = ''.join(random.choices(string.digits, k=7))
        
        # Combine letter and digits to form the visa number
        visa_number = f"Visa No {letter}{digits}"
        
        # Return the formatted visa number
        return visa_number
    
    @staticmethod
    def generate_geolocation_near_term():
        """
        Generate a random geolocation (latitude, longitude) near a term for the U.S.
        
        :return: A string with geolocation in the format 'Position: latitude, longitude'.
        """
        # Define a range for latitude and longitude near the center of the U.S.
        lat_base = 39.8283  # Latitude of the center of the U.S.
        lon_base = -98.5795  # Longitude of the center of the U.S.

        # Randomly adjust the latitude and longitude slightly to simulate "nearby" locations
        lat_random_offset = random.uniform(-0.5, 0.5)  # A random adjustment for latitude (-0.5 to +0.5)
        lon_random_offset = random.uniform(-0.5, 0.5)  # A random adjustment for longitude (-0.5 to +0.5)

        # Generate the new location
        lat = lat_base + lat_random_offset
        lon = lon_base + lon_random_offset

        # Return the formatted string with the geolocation
        return f"Position: {lat:.6f}, {lon:.6f}"
    

    @staticmethod
    def generate_us_street_address():
        """
        Generate a random U.S. street address with street number and name.
        
        :return: A string in the format '1234 Street Name'.
        """
        # List of possible street names (you can expand this list as needed)
        street_names = [
            "Main St", "Broadway", "Elm St", "Oak St", "Pine St", 
            "Maple Ave", "Fifth Ave", "Park Ave", "Sunset Blvd", "Wacker Dr",
            "King St", "Washington St", "Jefferson Blvd", "Madison Ave", 
            "Rose St", "Union St", "Lake Shore Dr"
        ]
        
        # Randomly select a street number (between 1 and 9999)
        street_number = random.randint(1, 9999)
        
        # Randomly select a street name
        street_name = random.choice(street_names)
        
        # Format and return the address
        return f"{street_number} {street_name}"
    

    @staticmethod
    def generate_ssn_near_term():
        """
        Generate a random U.S. Social Security Number (SSN) using Faker and format it near the hardcoded term 'S.S.N'.
        
        :return: A string in the format 'S.S.N - 078-05-1120'.
        """
        # Initialize Faker instance
        fake = Faker()

        # Generate a random SSN using Faker
        ssn = fake.ssn()

        # Hardcoded term
        term = "S.S.N"
        
        # Combine the term and SSN
        return f"{term} - {ssn}"
    

    @staticmethod
    def generate_phone_number_near_term(term="TEL"):
        """
        Generate a random U.S. phone number using Faker and format it near the specified term.
        
        :param term: The term to prepend to the phone number, e.g., 'TEL', 'Fax Number', etc.
        :return: A string in the format 'TEL: +1 202-456-1111' or 'Fax Number - 212-363-3200'.
        """
        # Initialize Faker instance
        fake = Faker()

        # Generate a random phone number using Faker
        phone_number = fake.phone_number()

        # Format the phone number depending on the term
        if term == "TEL":
            return f"TEL: +1 {phone_number}"
        elif term.lower().startswith("fax"):
            return f"Fax Number - {phone_number.replace('-', '')}"
        else:
            return f"{term}: {phone_number}"
        
    @staticmethod
    def generate_us_state_or_territory():
        """
        Generate a random U.S. state or territory name using Faker.
        
        :return: A random U.S. state or territory.
        """
        fake = Faker()

        # List of US territories that are not included by Faker's state provider
        us_territories = [
            "American Samoa", "Guam", "Northern Mariana Islands", "Puerto Rico", "U.S. Virgin Islands"
        ]
        
        # Use Faker to generate a random U.S. state
        state = fake.state()

        # Randomly decide whether to return a state or a territory
        if random.choice([True, False]):  # 50% chance to return a state or territory
            return state
        else:
            return random.choice(us_territories)
        


    @staticmethod
    def generate_date_of_death():
        """
        Generate a random date of death between the years 1980 and 2029.
        
        :return: A random date of death.
        """
        fake = Faker()

        # Generate a random year between 1980 and 2029
        year = random.randint(1980, 2029)
        
        # Generate a random month and day
        month = random.randint(1, 12)
        day = random.randint(1, 28)  # Limiting to 28 to avoid invalid dates like February 30

        # Create a formatted date string
        date_of_death = f"{day} {calendar.month_name[month]} {year}"
        
        return f"Date of Death: {date_of_death}"
    

    @staticmethod
    def generate_date_of_discharge():
        """
        Generate a random discharge date between the years 1980 and 2029.
        
        :return: A random discharge date in the format 'Date of Discharge: Feb 6, 2008'.
        """
        fake = Faker()

        # Generate a random year between 1980 and 2029
        year = random.randint(1980, 2029)
        
        # Generate a random month and day
        month = random.randint(1, 12)
        day = random.randint(1, 28)  # Limiting to 28 to avoid invalid dates like February 30

        # Create a formatted date string with month name and day
        discharge_date = f"{calendar.month_name[month]} {day}, {year}"
        
        return f"Date of Discharge: {discharge_date}"
    
    @staticmethod
    def generate_us_county():
        """
        Generate a random US county or county-equivalent, such as 'Escambia' or 'Howard County'.
        
        :return: A random US county name.
        """
        fake = Faker()

        # Generate a random county name using Faker's fake method for 'city_name' 
        # combined with 'County' to create county-equivalents
        county_name = fake.city()

        # Randomly decide if the county name should be the county or just a city name
        if random.choice([True, False]):
            return f"{county_name} County"  # For example: 'Howard County'
        else:
            return county_name  # For example: 'Escambia'
        
    @staticmethod
    def generate_admission_date():
        """
        Generate a random admission date between the years 1980 and 2029, 
        formatted as 'Date of Admission: January 31, 2008'.
        
        :return: A formatted random admission date.
        """
        fake = Faker()

        # Randomly choose a year between 1980 and 2029
        year = random.randint(1980, 2029)

        # Generate a random date with the selected year
        admission_date = fake.date_of_birth(minimum_age=0, maximum_age=50)  # Restrict the age to simulate realistic admissions
        formatted_date = admission_date.replace(year=year).strftime("Date of Admission: %B %d, %Y")
        
        return formatted_date
    

    @staticmethod
    def generate_driver_license_number_near_term():
        """
        Generate a fake US driver's license number in the format: 'Driver's license 578467607'.
        
        :return: A formatted fake driver's license number.
        """
        fake = Faker()

        # Generate a random numeric sequence for the driver's license number (e.g., 9 digits)
        license_number = fake.random_number(digits=9)

        # Format the license number with the prefix
        formatted_license_number = f"Driver's license {license_number}"
        
        return formatted_license_number
    
    @staticmethod
    def generate_populated_place():
        """
        Generate a fake US populated place (city, town, village) and optionally follow it by a US county or state.
        
        :return: A formatted fake populated place.
        """
        fake = Faker()

        # List of states and counties for additional formatting
        states = [
            "California", "Texas", "Florida", "New York", "Illinois", "Pennsylvania", 
            "Ohio", "Georgia", "North Carolina", "Michigan", "New Jersey", "Virginia"
        ]
        counties = [
            "Los Angeles County", "Cook County", "Harris County", "Maricopa County", 
            "San Diego County", "Orange County", "Kings County", "Miami-Dade County"
        ]
        
        # Generate a random populated place (city/town)
        populated_place = fake.city()

        # Randomly choose whether to append a county or state
        if random.choice([True, False]):  # 50% chance to add a county
            populated_place += f", {random.choice(counties)}"
        else:  # 50% chance to add a state
            populated_place += f", {random.choice(states)}"
        
        return populated_place

    @staticmethod
    def generate_itin_near_term():
        """
        Generate a fake 9-digit US Individual Taxpayer Identification Number (ITIN).
        The format will be like 'I.T.I.N - 939738021'.
        
        :return: A formatted fake ITIN.
        """
        fake = Faker()

        # Generate a random 9-digit number for ITIN
        itin_number = fake.random_number(digits=9)

        # Ensure the number is 9 digits long (in case of smaller number generated)
        itin_number = str(itin_number).zfill(9)
        
        # Format the output as 'I.T.I.N - 939738021'
        return f"I.T.I.N - {itin_number}"
    


    @staticmethod
    def generate_credit_card_near_term():
        """
        Generate a fake credit card number (13 to 19 digits) for different valid card types.
        The format will be like 'Visa 4184532221243969' or 'MasterCard 5555555555554444'.
        
        :return: A formatted fake credit card number.
        """
        fake = Faker("en_US")  # Set locale for consistency

        # Define valid card types that Faker supports
        valid_card_types = [
            'amex', 'diners', 'discover', 'jcb', 'jcb15', 'jcb16', 
            'maestro', 'mastercard', 'visa', 'visa13', 'visa16', 'visa19'
        ]

        # Randomly select a valid card type
        card_type = random.choice(valid_card_types)

        try:
            # Generate a credit card number for the selected type
            credit_card_number = fake.credit_card_number(card_type=card_type)
        except KeyError:
            # Fallback to a default type if there’s an issue
            card_type = "visa16"
            credit_card_number = fake.credit_card_number(card_type=card_type)

        # Format the output as '<Card Type> <Credit Card Number>'
        return f"{card_type.capitalize()} {credit_card_number}"



    

    @staticmethod
    def generate_middle_name():
        """
        Generate a fake US middle name using Faker's first_name method.
        
        :return: A fake middle name.
        """
        fake = Faker()
        
        # Generate a first name, which can also serve as a plausible middle name
        middle_name = fake.first_name()
        
        return middle_name
    

    @staticmethod
    def generate_country_of_origin_near_term():
        """
        Generate a fake country of origin with a related term.
        
        :return: A formatted string such as 'Place of Birth: Switzerland'.
        """
        fake = Faker()

        # Generate a fake country
        country = fake.country()

        # Format it as a related term
        country_of_origin = f"Place of Birth: {country}"

        return country_of_origin
    
    @staticmethod
    def generate_country_of_residence_near_term():
        """
        Generate a fake country of residence with a related term.
        
        :return: A formatted string such as 'Country of Residence: Switzerland'.
        """
        fake = Faker()

        # Generate a fake country
        country = fake.country()

        # Format it as a related term
        country_of_residence = f"Country of Residence: {country}"

        return country_of_residence
    

    @staticmethod
    def generate_masked_credit_card_near_term():
        """
        Generate a masked credit card number (e.g., 'Visa xxxxxxxxxxxx3969').
        
        :return: A formatted masked credit card number.
        """
        fake = Faker("en_US")  # Set locale for consistency

        # Define valid card types that Faker supports
        valid_card_types = [
            'amex', 'diners', 'discover', 'jcb', 'jcb15', 'jcb16', 
            'maestro', 'mastercard', 'visa', 'visa13', 'visa16', 'visa19'
        ]

        # Randomly select a valid card type
        card_type = random.choice(valid_card_types)

        try:
            # Generate the credit card number for the selected type
            card_number = fake.credit_card_number(card_type=card_type)
        except KeyError:
            # Fallback to a default type if there’s an issue
            card_type = "visa16"
            card_number = fake.credit_card_number(card_type=card_type)

        # Mask the credit card number (hide all but the last 4 digits)
        masked_card_number = f"{card_type.capitalize()} xxxxxxxx{card_number[-4:]}"
        
        return masked_card_number


    @staticmethod
    def generate_last_4_ccn():
        """
        Generate a 4-digit number for the last 4 digits of a credit card number.
        
        :return: A 4-digit number string.
        """
        return f"{random.randint(1000, 9999)}"
    

    @staticmethod
    def generate_unionpay_ccn(length=16):
        """
        Generate a UnionPay credit card number with a length of 16 to 19 digits.
        UnionPay card numbers typically start with "62".
        
        :param length: The total length of the credit card number (must be between 16 and 19).
        :return: A UnionPay credit card number as a string.
        """
        if length < 16 or length > 19:
            raise ValueError("Length must be between 16 and 19.")

        # UnionPay card numbers start with "62"
        card_number = "62"
        
        # Generate random digits for the rest of the card number
        for _ in range(length - 2):  # Subtracting 2 to account for the "62" prefix
            card_number += str(random.randint(0, 9))
        
        return card_number
    

    @staticmethod
    def generate_california_driver_license_number():
        """
        Generate a California Driver License Number (DLN).
        
        Format: AANNNNNNNN where
        - AA are the first letters of the user's first and last names
        - N is digits based on year of birth and random numbers
        
        :return: A California Driver License Number as a string.
        """
        # Randomly pick the first and last letter from the alphabet
        first_letter = random.choice(string.ascii_uppercase)
        second_letter = random.choice(string.ascii_uppercase)
        
        # Generate the year of birth (e.g., '80' for 1980)
        birth_year = random.randint(1950, 2000)  # Using a range of possible years (1950-1999)
        year_of_birth = str(birth_year)[-2:]  # Get the last two digits of the year
        
        # Generate 6 random digits for the rest of the DLN
        random_digits = ''.join([str(random.randint(0, 9)) for _ in range(6)])
        
        # Combine all parts to generate the license number
        california_driver_license = f"{first_letter}{second_letter}{year_of_birth}{random_digits}"
        
        return california_driver_license
    

    @staticmethod
    def generate_fake_onion_url():
        """
        Generate a fake .onion URL.
        
        The URL is made up of a random 16-character alphanumeric string followed by '.onion'.
        
        :return: A fake .onion URL as a string.
        """
        # Generate a random 16-character alphanumeric string for the .onion address
        random_string = ''.join(random.choices(string.ascii_lowercase + string.digits, k=16))
        
        # Combine the string with the .onion TLD
        fake_onion_url = f"{random_string}.onion"
        
        return fake_onion_url
    

    @staticmethod
    def generate_fake_area_code():
        """
        Generate a fake 3-digit US area code.
        
        The area code is a random 3-digit number from 200 to 999 (avoiding reserved and invalid codes).
        
        :return: A fake 3-digit area code as a string.
        """
        # Generate a random 3-digit number in the valid range for US area codes
        area_code = random.randint(200, 999)
        
        return str(area_code)
    

    @staticmethod
    def generate_masked_ssn_near_term():
        """
        Generate a masked Social Security Number (SSN) in the format 'S.S.N - ***-**-XXXX'.
        
        The SSN is generated as a random number, and only the last four digits are visible.
        
        :return: A masked SSN as a string.
        """
        # Generate a random SSN where only the last four digits are visible
        ssn_last_four = random.randint(1000, 9999)
        
        # Format it as masked SSN
        masked_ssn = f"S.S.N - ***-**-{ssn_last_four:04}"
        
        return masked_ssn
    

    @staticmethod
    def generate_last_4_ssn():
        """
        Generate the last 4 digits of a Social Security Number (SSN).
        
        :return: The last 4 digits of a SSN as a string.
        """
        # Generate a random 4-digit number for SSN
        ssn_last_four = random.randint(1000, 9999)
        
        return f"{ssn_last_four:04}"
    
    @staticmethod
    def generate_us_atin():
        """
        Generate a 9-digit US Adoption Taxpayer Identification Number (ATIN).
        
        Format: XXX-XX-XXXX
        
        :return: A valid ATIN as a string.
        """
        # Generate three parts of the ATIN (XXX-XX-XXXX)
        part1 = random.randint(100, 999)  # First three digits
        part2 = random.randint(10, 99)    # Middle two digits
        part3 = random.randint(1000, 9999)  # Last four digits

        return f"{part1}-{part2}-{part3}"
    

    @staticmethod
    def generate_us_ptin_near_term():
        """
        Generate a 9-character US Preparer Tax Identification Number (PTIN) with the term.
        
        Format: 'PTIN - PXXXXXXXX' (P followed by 8 digits)
        
        :return: A valid PTIN string with the term.
        """
        # Generate 8 random digits
        digits = random.randint(10000000, 99999999)

        return f"PTIN - P{digits}"
    

    @staticmethod
    def generate_us_ein_near_term():
        """
        Generate a 9-digit US Employer Identification Number (EIN) with the term.
        
        Format: 'EIN: XX-XXXXXXX' (2-digit prefix, followed by a 7-digit sequence)
        
        :return: A valid EIN string with the term.
        """

        
        # EIN first two digits range (valid prefixes used by the IRS)
        ein_prefixes = [
                "01", "02", "03", "04", "05", "06", "10", "11", "12", "13", "14", "15", "16", 
                "20", "21", "22", "23", "24", "25", "30", "31", "32", "33", "34", "35", "36", 
                "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "50", 
                "51", "52", "53", "54", "55", "56", "57", "58", "59", "60", "61", "62", "63", 
                "64", "65", "66", "67", "68", "71", "72", "73", "74", "75", "76", "77", "80", 
                "81", "82", "83", "84", "85", "86", "87", "88", "90", "91", "92", "93", "98", 
                "99"
            ]

        # Pick a random EIN prefix
        prefix = random.choice(ein_prefixes)
        
        # Generate the last 7 digits
        sequence = random.randint(1000000, 9999999)

        return f"EIN: {prefix}-{sequence}"
    

    @staticmethod
    def generate_us_zip_near_term():
        """
        Generate a 5-digit US ZIP code with the related term.

        Format: 'ZIP: XXXXX' (5-digit format used in the US)

        :return: A valid ZIP string with the term.
        """
        # Generate a random 5-digit ZIP code (10000 - 99999)
        zip_code = random.randint(10000, 99999)
        
        return f"ZIP: {zip_code}"
    

    @staticmethod
    def generate_us_state_abbr():
        """
        Generate a random US state or territory abbreviation.

        :return: A valid US state/territory abbreviation string.
        """
        us_state_abbreviations = [
            "AL", "AK", "AZ", "AR", "CA", "CO", "CT", "DE", "FL", "GA", "HI", "ID", "IL", "IN", "IA", "KS", "KY",
            "LA", "ME", "MD", "MA", "MI", "MN", "MS", "MO", "MT", "NE", "NV", "NH", "NJ", "NM", "NY", "NC", "ND",
            "OH", "OK", "OR", "PA", "RI", "SC", "SD", "TN", "TX", "UT", "VT", "VA", "WA", "WV", "WI", "WY",
            "DC", "AS", "GU", "MP", "PR", "VI"
        ]
        return random.choice(us_state_abbreviations)
    
    @staticmethod
    def generate_aba_rtn_fraction():
        """
        Generate a fake ABA Routing Transit Number (ABA RTN) in fraction format using Faker.

        Format: 'XX-XXXX/YYY' 
        - XX: Prefix (01-12, 21-32, 61-72)
        - XXXX: Institution identifier (random 4 digits)
        - YYY: Federal Reserve Bank identifier (random 3 digits)

        :return: A formatted string representing the ABA RTN.
        """
        fake = Faker()
        prefix = random.choice(range(1, 13))  # Prefix from 01-12
        institution_id = fake.random_number(digits=4)  # 4-digit institution code using Faker
        fed_reserve_id = fake.random_number(digits=3)  # 3-digit Federal Reserve Bank ID using Faker

        return f"{prefix:02d}-{institution_id}/{fed_reserve_id}"
    

    @staticmethod
    def generate_us_swift_code(length=8):
        """
        Generate a fake US SWIFT code (BIC) with 8 or 11 characters.

        Format: 'BankCodeCountryCodeLocationCode[BranchCode]'
        - BankCode: 4 alphabetic characters
        - CountryCode: 2 alphabetic characters (US for USA)
        - LocationCode: 2 alphanumeric characters
        - BranchCode: Optional 3 alphanumeric characters

        :param length: The desired length of the SWIFT code, either 8 or 11 characters.
        :return: A formatted string representing the SWIFT code.
        """
        bank_code = ''.join(random.choices(string.ascii_uppercase, k=4))  # 4 random letters
        country_code = 'US'  # Country code for USA
        location_code = ''.join(random.choices(string.ascii_uppercase + string.digits, k=2))  # 2 alphanumeric characters

        # If length is 11, include a branch code
        if length == 11:
            branch_code = ''.join(random.choices(string.ascii_uppercase + string.digits, k=3))  # 3 alphanumeric characters
            return f"{bank_code}{country_code}{location_code}{branch_code}"
        
        # If length is 8, do not include the branch code
        return f"{bank_code}{country_code}{location_code}"
    
    @staticmethod
    def generate_health_plan_member_id_near_term(min_length=7, max_length=25):
        """
        Generate a random Member ID (or Customer ID) between 7 and 25 characters.

        :param min_length: Minimum length of the generated ID (default is 7)
        :param max_length: Maximum length of the generated ID (default is 25)
        :return: A string representing the Member ID.
        """
        # Randomly decide the length of the ID between the min and max length
        id_length = random.randint(min_length, max_length)
        
        # Create a random ID using uppercase letters and digits
        member_id = ''.join(random.choices(string.ascii_uppercase + string.digits, k=id_length))
        
        return f"Member ID: {member_id}"
    
    @staticmethod
    def generate_medical_record_number_near_term(min_length=7, max_length=25):
        """
        Generate a random Medical Record Number (MRN) between 7 and 25 characters.

        :param min_length: Minimum length of the generated MRN (default is 7)
        :param max_length: Maximum length of the generated MRN (default is 25)
        :return: A string representing the Medical Record Number.
        """
        # Randomly decide the length of the MRN between the min and max length
        mrn_length = random.randint(min_length, max_length)
        
        # Create a random MRN using uppercase letters and digits
        mrn = ''.join(random.choices(string.ascii_uppercase + string.digits, k=mrn_length))
        
        return f"Hospital Medical Record Number: {mrn}"
    

    @staticmethod
    def generate_patient_id_near_term(min_length=7, max_length=25):
        """
        Generate a random Patient ID Number between 7 and 25 characters.

        :param min_length: Minimum length of the generated Patient ID (default is 7)
        :param max_length: Maximum length of the generated Patient ID (default is 25)
        :return: A string representing the Patient ID Number.
        """
        # Randomly decide the length of the Patient ID Number between the min and max length
        patient_id_length = random.randint(min_length, max_length)
        
        # Create a random Patient ID using uppercase letters and digits
        patient_id = ''.join(random.choices(string.ascii_uppercase + string.digits, k=patient_id_length))
        
        return f"Patient ID Number: {patient_id}"
    

    @staticmethod
    def generate_loan_id_near_term(min_length=7, max_length=25):
        """
        Generate a random Loan ID Number between 7 and 25 characters.

        :param min_length: Minimum length of the generated Loan ID (default is 7)
        :param max_length: Maximum length of the generated Loan ID (default is 25)
        :return: A string representing the Loan ID Number.
        """
        # Randomly decide the length of the Loan ID Number between the min and max length
        loan_id_length = random.randint(min_length, max_length)
        
        # Create a random Loan ID using uppercase letters and digits
        loan_id = ''.join(random.choices(string.ascii_uppercase + string.digits, k=loan_id_length))
        
        return f"Loan ID Number: {loan_id}"
    

    def generate_cui_banner():
        """
        Generate a random CUI banner marking, such as 'CONTROLLED//SP-ARCHR'.
        
        :return: A string representing the CUI banner marking.
        """
        # CUI markings typically have a classification and a designation
        classification = "CONTROLLED"
        designations = [
            "SP-ARCHR", "SP-CISO", "SP-SEC", "SP-IT", "SP-FED", "SP-DEFENSE", "SP-COM", "SP-DATA", "SP-GOV"
        ]
        
        # Randomly pick a designation
        designation = random.choice(designations)
        
        # Format and return the CUI banner
        return f"{classification}//{designation}"
    

    @staticmethod
    def generate_cui_portion():
        """
        Generate a random CUI portion marking, such as '(CUI//SP-ARCHR)'.
        
        :return: A string representing the CUI portion marking.
        """
        # CUI markings typically have a classification and a designation
        classification = "CUI"
        designations = [
            "SP-ARCHR", "SP-CISO", "SP-SEC", "SP-IT", "SP-FED", "SP-DEFENSE", "SP-COM", "SP-DATA", "SP-GOV"
        ]
        
        # Randomly pick a designation
        designation = random.choice(designations)
        
        # Format and return the CUI portion marking
        return f"(CUI//{designation})"
    

    @staticmethod
    def generate_cui_designation_indicator():
        """
        Generate a random CUI designation indicator with phrases like 'Controlled by' and 'POC'.
        
        :return: A string representing the CUI designation indicator.
        """
        # Designation indicators often contain phrases like 'Controlled by' and 'POC'
        controlled_by = ["Controlled by: Department of Defense", "Controlled by: Intelligence Community", "Controlled by: DHS"]
        poc = ["POC: John Doe, jdoe@company.com", "POC: Jane Smith, jsmith@company.com", "POC: Michael Brown, mbrown@company.com"]

        # Randomly pick a 'Controlled by' phrase and a 'POC' phrase
        controlled_phrase = random.choice(controlled_by)
        poc_phrase = random.choice(poc)
        
        # Format and return the CUI designation indicator
        return f"{controlled_phrase}; {poc_phrase}"
    

    @staticmethod
    def generate_lei():
        """
        Generate a random 20-character Legal Entity Identifier (LEI).
        
        :return: A string representing the 20-character LEI.
        """
        # Generate a 20-character LEI with uppercase letters and digits
        lei = ''.join(random.choices(string.ascii_uppercase + string.digits, k=20))
        return lei
    

    @staticmethod
    def generate_icd10_code():
        """
        Generates a random ICD-10-CM code in the format of 'A10' or 'A10.01'.
        """
        # First character is a letter (A-Z)
        first_char = random.choice(string.ascii_uppercase)
        
        # The second and third characters are digits (0-9)
        second_char = random.choice(string.digits)
        third_char = random.choice(string.digits)
        
        # Now check if the code should have a period and additional characters
        code_length = random.choice([1, 2])  # Control whether we add extra characters after the period
        
        if code_length == 1:
            # Generate a code of the format 'A10'
            return f"{first_char}{second_char}{third_char}"
        else:
            # Generate a code of the format 'A10.01'
            fourth_char = random.choice(string.digits)
            fifth_char = random.choice(string.digits)
            return f"{first_char}{second_char}{third_char}.{fourth_char}{fifth_char}"
        

    @staticmethod
    def generate_icd10_code_near_term():
        """
        Generates a random ICD-10-CM code in the format of 'ICD10 Code - A10' or 'ICD10 Code - A10.01'.
        """
        # First character is a letter (A-Z)
        first_char = random.choice(string.ascii_uppercase)
        
        # The second and third characters are digits (0-9)
        second_char = random.choice(string.digits)
        third_char = random.choice(string.digits)
        
        # Now check if the code should have a period and additional characters
        code_length = random.choice([1, 2])  # Control whether we add extra characters after the period
        
        if code_length == 1:
            # Generate a code of the format 'A10'
            icd_code = f"{first_char}{second_char}{third_char}"
        else:
            # Generate a code of the format 'A10.01'
            fourth_char = random.choice(string.digits)
            fifth_char = random.choice(string.digits)
            icd_code = f"{first_char}{second_char}{third_char}.{fourth_char}{fifth_char}"

        # Return the related term along with the ICD10 code
        return f"ICD10 Code - {icd_code}"
    

    @staticmethod
    def generate_track3_data():
        """
        Generates a valid Track 3 magnetic card data string with common BIN and random components.
        """
        # Common BINs for valid card generation (Mastercard, Visa, etc.)
        common_bins = ['014384', '411111', '601151', '510510', '530935']

        # Select a random BIN from the list
        bin_choice = random.choice(common_bins)

        # Generate the remaining part of the PAN (14 random digits)
        pan = bin_choice + ''.join(random.choices(string.digits, k=10))

        # Generate Expiry Date (YYMM format)
        expiry_date = f"{random.randint(22, 29)}{random.randint(1, 12):02d}"

        # Generate a 3-digit Service Code
        service_code = f"{random.randint(0, 9)}{random.randint(0, 9)}{random.randint(0, 9)}"

        # Discretionary Data (random 16 digits)
        discretionary_data = ''.join(random.choices(string.digits, k=16))

        # Generate Track Data (random 30 digits)
        track_data = ''.join(random.choices(string.digits, k=30))

        # Return the formatted Track 3 data
        track3_data = f";{pan}={expiry_date}{service_code}{discretionary_data}={track_data}?"
        
        return track3_data
    

    @staticmethod
    def generate_employment_status():
        """
        Generates a random employment status in English.
        """
        employment_statuses = [
            'Full-time Employee', 
            'Part-time Employee', 
            'Contractor', 
            'Freelancer', 
            'Self-employed', 
            'Unemployed', 
            'Intern', 
            'Retired', 
            'Student', 
            'Temporary Employee'
        ]
        
        # Randomly select one employment status
        status = random.choice(employment_statuses)
        
        return status

    @staticmethod
    def generate_employment_date():
        """
        Generates a random employment date between 1970 and 2029, near a related term.
        """
        # Generate a random year between 1970 and 2029
        start_date = datetime(1970, 1, 1)
        end_date = datetime(2029, 12, 31)
        
        # Calculate the difference in days
        delta_days = (end_date - start_date).days
        
        # Generate a random date by adding a random number of days to the start date
        random_days = random.randint(0, delta_days)
        random_date = start_date + timedelta(days=random_days)

        # Format the date in a readable format
        formatted_date = random_date.strftime("%d %B %Y")  # Example: 5 May 2019
        
        # Create the final result with the related term
        result = f"Date of Hiring: {formatted_date}"
        
        return result  
    
    @staticmethod
    def generate_apple_idfa():
        """
        Generates a random 32-character Apple IDFA number.
        Format: DEDDB713-5781-459F-AF98-504EAD972F24
        """
        # Generate a random UUID
        idfa = str(uuid.uuid4()).upper()
        
        # Format as per Apple IDFA pattern (32-character with hyphen-separated segments)
        formatted_idfa = f"{idfa[:8]}-{idfa[8:12]}-{idfa[12:16]}-{idfa[16:20]}-{idfa[20:]}"
        
        return formatted_idfa
    

    @staticmethod
    def generate_android_id_near_term():
        """
        Generates a random 16-character Android ID.
        Format: Android ID: 6ccc8540e41e3c32
        """
        # Generate a 16-character string using hex characters
        android_id = ''.join(random.choices(string.hexdigits.lower(), k=16))
        
        # Format as per the Android ID pattern
        formatted_android_id = f"Android ID: {android_id}"
        
        return formatted_android_id
    
    @staticmethod
    def generate_us_driver_license_number():
        """
        Generates a random 9-digit US driver's license number.
        Format: 578467607
        """
        # Generate a random 9-digit number
        driver_license_number = ''.join(random.choices('0123456789', k=9))
        
        return driver_license_number
    
    #new
    @staticmethod
    def generate_medical_license_number():
        """
        Generates a random US medical license number.
        Format: 6-10 digits, may include a state prefix (Not state-specific).
        """
        # Randomly decide if a prefix is needed
        prefixes = ["MD", "DO", "PA", "NP", "RPH", "DDS", "RN", "DPM"]  # Common prefixes
        use_prefix = random.choice([True, False])

        # Generate a 6-10 digit number
        license_number = ''.join(random.choices('0123456789', k=random.randint(6, 10)))

        # If using a prefix, add it
        if use_prefix:
            return f"{random.choice(prefixes)}-{license_number}"
        return license_number
    @staticmethod
    def generate_us_city():
        """
        Generates a random U.S. city name from a predefined list.
        """
        us_cities = [
            "New York", "Los Angeles", "Chicago", "Houston", "Phoenix", 
            "Philadelphia", "San Antonio", "San Diego", "Dallas", "San Jose",
            "Austin", "Jacksonville", "San Francisco", "Columbus", "Indianapolis",
            "Fort Worth", "Charlotte", "Seattle", "Denver", "Washington",
            "Boston", "El Paso", "Nashville", "Detroit", "Oklahoma City",
            "Las Vegas", "Louisville", "Baltimore", "Portland", "Milwaukee",
            "Albuquerque", "Tucson", "Fresno", "Sacramento", "Kansas City",
            "Atlanta", "Miami", "Omaha", "Raleigh", "Long Beach"
        ]
        
        return random.choice(us_cities)
    
    @staticmethod
    def generate_dob(min_age=18, max_age=90):
        """
        Generates a random Date of Birth (DOB) based on a given age range.
        Default: Between 18 and 90 years old.
        """
        # Calculate the earliest and latest birthdates based on the current year
        today = datetime.today()
        start_date = today - timedelta(days=max_age * 365)  # Oldest age
        end_date = today - timedelta(days=min_age * 365)  # Youngest age

        # Generate a random date within this range
        random_days = random.randint(0, (end_date - start_date).days)
        dob = start_date + timedelta(days=random_days)

        # Return formatted DOB (YYYY-MM-DD)
        return dob.strftime("%Y-%m-%d")
    
    @staticmethod
    def generate_us_isin():
        """
        Generates a random US ISIN (International Securities Identification Number).
        Format: US + 10 alphanumeric characters (CUSIP-based).
        """
        # Generate 10 random uppercase letters and digits
        cusip_part = ''.join(random.choices(string.ascii_uppercase + string.digits, k=10))

        # Construct ISIN with "US" prefix
        isin = f"US{cusip_part}"

        return isin

    @staticmethod
    def generate_icd9_code():
        """
        Generates a random ICD-9 code.
        Format: Three-digit number (001-999) optionally followed by up to two decimal digits.
        Example: "250", "401.1", "786.50"
        """
        # Generate a three-digit main category (001-999)
        main_code = random.randint(1, 999)

        # Decide randomly whether to include a decimal part
        if random.choice([True, False]):  # 50% chance of having a decimal part
            decimal_part = random.randint(0, 99)  # Up to two decimal places
            return f"{main_code}.{decimal_part:02d}"  # Ensure two decimal places
        else:
            return f"{main_code}"
        
    @staticmethod
    def generate_person_type():
        """
        Generates a random person type.
        Possible values: "C1" or a type matching the regex pattern.
        """
        fixed_values = ["C1"]
        regex_values = [
            "Individual", "Organization", "Corporation", "Business",
            "Diplomatic", "Politician", "Nonprofit", "Government",
            "Employee", "Contractor", "Investor"
        ]

        # Randomly pick from either fixed or regex-based values
        return random.choice(fixed_values + regex_values)
    
    @staticmethod
    def generate_health_insurance_policy():
        """
        Generates a random US health insurance policy number.
        Format: Can be 9-14 digits or alphanumeric with optional dashes.
        """
        # Choose between numeric-only or alphanumeric format
        if random.choice([True, False]):  # 50% chance for alphanumeric format
            prefix = ''.join(random.choices(string.ascii_uppercase, k=2))  # 2-letter prefix
            policy_number = ''.join(random.choices(string.digits, k=random.randint(7, 12)))  # 7-12 digits
            return f"{prefix}-{policy_number}"
        else:
            return ''.join(random.choices(string.digits, k=random.randint(9, 14)))  # 9-14 digit number
        
    @staticmethod
    def generate_organization_name():
        """
        Generates a random organization name.
        Possible formats:
        - "C1" (Fixed Value)
        - "<Random Words> <Legal Suffix>"
        """
        fixed_values = ["C1"]
        words = ["Alpha", "Beta", "Gamma", "Delta", "Tech", "Solutions", "Innovations", 
                 "Global", "Enterprises", "Systems", "Industries", "Network", "Capital", "Group"]
        legal_suffixes = ["Inc.", "LLC", "AG", "Corporation", "Ltd.", "GmbH", "S.A.", "Corp.", "KGaA", "NV"]

        # Generate a random organization name
        org_name = f"{random.choice(words)} {random.choice(words)} {random.choice(legal_suffixes)}"

        # Return either fixed "C1" or generated org name
        return random.choice(fixed_values + [org_name])
    

    @staticmethod
    def generate_voter_registration_number():
        """
        Generates a random US Voter Registration Number.
        Format: Can be 8-12 digits or alphanumeric with a state prefix.
        """
        states = ["AZ", "TX", "CA", "NY", "FL", "GA", "OH", "PA", "IL", "NC"]  # Example state codes
        
        # 50% chance to generate numeric or alphanumeric format
        if random.choice([True, False]):  
            voter_id = ''.join(random.choices(string.digits, k=random.randint(8, 12)))  # 8-12 digits
        else:
            state_code = random.choice(states)  # Random state prefix
            voter_id = f"{state_code}-{''.join(random.choices(string.digits, k=8))}"  # State + 8-digit number
        
        return voter_id
    
    @staticmethod
    def generate_dl_state_issuer():
        """
        Generates a random US Driver's License State Issuer Code.
        Format: Two-letter state abbreviation.
        """
        state_codes = [
            "AL", "AK", "AZ", "AR", "CA", "CO", "CT", "DE", "FL", "GA", "HI", "ID", "IL", "IN", "IA", "KS", 
            "KY", "LA", "ME", "MD", "MA", "MI", "MN", "MS", "MO", "MT", "NE", "NV", "NH", "NJ", "NM", "NY", 
            "NC", "ND", "OH", "OK", "OR", "PA", "RI", "SC", "SD", "TN", "TX", "UT", "VT", "VA", "WA", "WV", 
            "WI", "WY", "DC", "PR", "GU", "VI", "AS", "MP"
        ]  # US states and territories

        return random.choice(state_codes)
    
    @staticmethod
    def generate_us_license_plate():
        """
        Generates a random US vehicle license plate number.
        Formats vary by state:
        - "ABC-1234" (common)
        - "123-ABC" (some states)
        - "1ABC234" (California)
        - "ABC 1234" (Florida-style)
        """
        formats = [
            lambda: f"{''.join(random.choices(string.ascii_uppercase, k=3))}-{random.randint(1000, 9999)}",  # AAA-1234
            lambda: f"{random.randint(100, 999)}-{''.join(random.choices(string.ascii_uppercase, k=3))}",  # 123-ABC
            lambda: f"{random.randint(1, 9)}{''.join(random.choices(string.ascii_uppercase, k=3))}{random.randint(100, 999)}",  # 1ABC234
            lambda: f"{''.join(random.choices(string.ascii_uppercase, k=3))} {random.randint(1000, 9999)}"  # ABC 1234
        ]
        
        return random.choice(formats)()
    
    @staticmethod
    def generate_state_id():
        """
        Generates a random US State Identification Number.
        Formats vary by state:
        - Numeric-only (8-10 digits)
        - Alphanumeric (State Code + Digits)
        - State Prefix (e.g., 'TX-12345678')
        """
        state_codes = [
            "AL", "AK", "AZ", "AR", "CA", "CO", "CT", "DE", "FL", "GA", "HI", "ID", "IL", "IN", "IA", "KS", 
            "KY", "LA", "ME", "MD", "MA", "MI", "MN", "MS", "MO", "MT", "NE", "NV", "NH", "NJ", "NM", "NY", 
            "NC", "ND", "OH", "OK", "OR", "PA", "RI", "SC", "SD", "TN", "TX", "UT", "VT", "VA", "WA", "WV", 
            "WI", "WY", "DC"
        ]  # US State Codes

        formats = [
            lambda: f"{random.randint(10000000, 999999999)}",  # Numeric-only (8-10 digits)
            lambda: f"{random.choice(state_codes)}{random.randint(1000000, 99999999)}",  # State Code + Digits
            lambda: f"{random.choice(state_codes)}-{random.randint(10000000, 99999999)}"  # State-Prefix format
        ]
        
        return random.choice(formats)()
    
    @staticmethod
    def generate_work_permit_number():
        """
        Generates a random US Work Permit (EAD) Number.
        Format: "A-XXX-XXX-XXX" (Alien Registration Number) or "EAD-XXX-XXX-XXX"
        """
        prefix = random.choice(["A", "EAD"])  # Common prefixes for work permits
        number_part = f"{random.randint(100, 999)}-{random.randint(100, 999)}-{random.randint(100, 999)}"

        return f"{prefix}-{number_part}"
    
    @staticmethod
    def generate_green_card_number():
        """
        Generates a random US Permanent Resident Card (Green Card) Number.
        Formats:
        - "XXX-XXX-XXX" (Basic Format)
        - "ABC1234567890" (Prefix + 10-digit number)
        - "SRC 23 345 67890" (Three-Letter Code + Year + Serial Number)
        """
        formats = [
            lambda: f"{random.randint(100, 999)}-{random.randint(100, 999)}-{random.randint(100, 999)}",  # XXX-XXX-XXX
            lambda: f"{random.choice(['SRC', 'LIN', 'MSC', 'EAC', 'WAC'])}{random.randint(1000000000, 9999999999)}",  # ABC1234567890
            lambda: f"{random.choice(['SRC', 'LIN', 'MSC', 'EAC', 'WAC'])} {random.randint(10, 25)} {random.randint(100, 999)} {random.randint(10000, 99999)}"  # SRC 23 345 67890
        ]
        
        return random.choice(formats)()
    
    @staticmethod
    def generate_student_id():
        """
        Generates a random US Student Identification Number.
        Formats:
        - Numeric-only (8-10 digits)
        - Alphanumeric (S12345678)
        - Year-based (202412345)
        """
        formats = [
            lambda: f"{random.randint(10000000, 9999999999)}",  # Numeric-only (8-10 digits)
            lambda: f"S{random.randint(1000000, 99999999)}",  # S + Digits
            lambda: f"{random.randint(2000, 2025)}{random.randint(10000, 99999)}"  # Year + Digits
        ]
        
        return random.choice(formats)()
    
    @staticmethod
    def generate_insurance_claim_number():
        """
        Generates a random US Insurance Claim Number.
        Formats:
        - Numeric-only (9-12 digits)
        - Alphanumeric (INS123456)
        - Year-based (YYYY-XXXXX)
        """
        formats = [
            lambda: f"{random.randint(100000000, 999999999999)}",  # Numeric-only (9-12 digits)
            lambda: f"INS{random.randint(100000, 999999)}",  # INS + 6-digit number
            lambda: f"{random.randint(2000, 2025)}-{random.randint(10000, 99999)}"  # Year + Digits
        ]
        
        return random.choice(formats)()
    
    @staticmethod
    def generate_aba_routing_number():
        """
        Generates a random valid US ABA Routing Number.
        - 9-digit format
        - Valid prefix (01-12, 21-32, 61-72, 80)
        - Checksum validation
        """
        valid_prefixes = [str(i).zfill(2) for i in list(range(1, 13)) + list(range(21, 33)) + list(range(61, 73)) + [80]]
        prefix = random.choice(valid_prefixes)  # Select a valid prefix
        middle = f"{random.randint(1000, 9999)}{random.randint(10, 99)}"  # Generate middle 6 digits
        
        # Compute checksum (ABA checksum formula)
        first_8_digits = prefix + middle
        weights = [3, 7, 1] * 3  # Weights for checksum calculation
        checksum = (10 - sum(int(digit) * weight for digit, weight in zip(first_8_digits, weights)) % 10) % 10
        
        return first_8_digits + str(checksum)
    
    @staticmethod
    def generate_bank_transaction_id():
        """
        Generates a random Bank Transaction ID.
        Formats:
        - Alphanumeric (16-20 characters) e.g., TXN12345678901234
        - UUID-Based (Hexadecimal 32 characters)
        - Date-Based + Random Digits (YYYYMMDD-XXXXXXXXXX)
        """
        formats = [
            lambda: f"TXN{random.randint(1000000000000000, 9999999999999999)}",  # TXN + 16-digit number
            lambda: str(uuid.uuid4()).replace("-", ""),  # UUID 32-character hex
            lambda: f"{datetime.now().strftime('%Y%m%d')}-{random.randint(1000000000, 9999999999)}"  # YYYYMMDD + 10-digit number
        ]
        
        return random.choice(formats)()
    
    @staticmethod
    def generate_micr_routing_number():
        """
        Generates a random valid US MICR Routing Number.
        - 9-digit format
        - Valid prefix (01-12, 21-32, 61-72, 80)
        - Checksum validation using ABA checksum formula
        """
        valid_prefixes = [str(i).zfill(2) for i in list(range(1, 13)) + list(range(21, 33)) + list(range(61, 73)) + [80]]
        prefix = random.choice(valid_prefixes)  # Select a valid prefix
        middle = f"{random.randint(1000, 9999)}{random.randint(10, 99)}"  # Generate middle 6 digits
        
        # Compute checksum (ABA checksum formula)
        first_8_digits = prefix + middle
        weights = [3, 7, 1] * 3  # Weights for checksum calculation
        checksum = (10 - sum(int(digit) * weight for digit, weight in zip(first_8_digits, weights)) % 10) % 10
        
        return first_8_digits + str(checksum)
    
    @staticmethod
    def generate_banking_pin(pin_length=4):
        """
        Generates a random Banking PIN Number.
        - Default: 4-digit PIN (ATM standard)
        - Can generate a 6-digit PIN for secure banking
        """
        if pin_length not in [4, 6]:
            raise ValueError("PIN length must be either 4 or 6 digits")
        
        return ''.join(random.choices('0123456789', k=pin_length))


    @staticmethod
    def generate_cusip():
        """
        Generates a random valid CUSIP number.
        - 9-character alphanumeric code
        - First 6: Issuer Code (A-Z, 0-9)
        - Next 2: Issue Identifier (A-Z, 0-9)
        - Last 1: Checksum digit (Luhn Modulus 10)
        """
        def cusip_checksum(cusip):
            """Calculate the CUSIP Modulus 10 checksum digit."""
            def cusip_value(char):
                if char.isdigit():
                    return int(char)
                return ord(char) - 55  # Convert A-Z to 10-35
            
            values = [cusip_value(char) * (2 if i % 2 else 1) for i, char in enumerate(cusip)]
            values = [sum(divmod(v, 10)) for v in values]  # Sum digits of doubled values
            checksum = (10 - sum(values) % 10) % 10
            return str(checksum)
        
        # Generate first 8 characters (A-Z, 0-9)
        first_8 = ''.join(random.choices(string.ascii_uppercase + string.digits, k=8))
        
        # Calculate checksum
        checksum_digit = cusip_checksum(first_8)
        
        return first_8 + checksum_digit
    
    @staticmethod
    def generate_dea_number(last_name="Smith"):
        """
        Generates a random valid DEA Number.
        Format: [First Letter][Last Name Initial][6 Digits][Checksum]
        - First Letter: Registrant Type (A, B, C, M, etc.)
        - Second Letter: First letter of last name
        - Next 6 Digits: Random number
        - Last Digit: Checksum (Modulus 10)
        """
        # DEA registrant types (A/B/F/G for physicians, M for mid-level practitioners)
        registrant_types = "ABFM"
        first_letter = random.choice(registrant_types)
        second_letter = last_name[0].upper() if last_name else random.choice(string.ascii_uppercase)
        
        # Generate 6-digit unique identifier
        digits = ''.join(random.choices(string.digits, k=6))

        # Calculate checksum:
        odd_sum = int(digits[0]) + int(digits[2]) + int(digits[4])
        even_sum = (int(digits[1]) + int(digits[3]) + int(digits[5])) * 2
        checksum = (odd_sum + even_sum) % 10
        
        return f"{first_letter}{second_letter}{digits}{checksum}"
    
    @staticmethod
    def generate_ein():
        """
        Generates a random valid US Employer Identification Number (EIN).
        - Format: XX-XXXXXXX
        - First two digits (IRS Prefix) are valid assignment numbers
        - Last 7 digits are random
        """
        valid_prefixes = [str(i).zfill(2) for i in list(range(1, 11)) + list(range(12, 80)) + list(range(80, 100))]
        prefix = random.choice(valid_prefixes)  # Select a valid EIN prefix
        suffix = ''.join(random.choices('0123456789', k=7))  # Generate last 7 digits
        
        return f"{prefix}-{suffix}"
    
    @staticmethod
    def generate_fcc_registration_number():
        """
        Generates a random 10-digit FCC Registration Number (FRN).
        - Format: 10-digit numeric string
        - Example: "0012345678"
        """
        return ''.join(random.choices('0123456789', k=10))
    
    @staticmethod
    def generate_fda_registration_number():
        """
        Generates a random FDA Registration Number.
        - Format: 7 to 12-digit numeric string
        - Example: "1234567" or "987654321012"
        """
        length = random.randint(7, 12)  # FDA numbers range from 7 to 12 digits
        return ''.join(random.choices('0123456789', k=length))
    


    @staticmethod
    def generate_npi():
        """
        Generates a valid 10-digit National Provider Identifier (NPI).
        - Format: 10-digit number, where:
            - First digit is 1 or 2
            - Last digit is a valid Luhn checksum
        """
        def luhn_checksum(num):
            """Calculates the Luhn checksum for a given number."""
            digits = [int(d) for d in str(num)]
            for i in range(len(digits) - 2, -1, -2):
                digits[i] *= 2
                if digits[i] > 9:
                    digits[i] -= 9
            checksum = sum(digits) % 10
            return (10 - checksum) % 10

        first_eight_digits = str(random.choice([1, 2])) + ''.join(random.choices('0123456789', k=8))
        checksum_digit = luhn_checksum(first_eight_digits + "0")  # Placeholder for last digit
        return f"{first_eight_digits}{checksum_digit}"
    
    @staticmethod
    def generate_ptin():
        """
        Generates a valid Preparer Taxpayer Identification Number (PTIN).
        - Format: P + 8-digit number
        - Example: "P12345678"
        """
        numeric_part = ''.join(random.choices('0123456789', k=8))
        return f"P{numeric_part}"
    

    @staticmethod
    def generate_omb_control_number():
        """
        Generates a random OMB Control Number.
        - Format: XX-XXXX
        - Example: "10-1234"
        """
        prefix = str(random.randint(10, 99))  # Two-digit agency code
        identifier = str(random.randint(1000, 9999))  # Four-digit unique ID
        return f"{prefix}-{identifier}"
    

    @staticmethod
    def generate_real_estate_license(state_code="CA"):
        """
        Generates a random U.S. Real Estate License Number.
        Format varies by state:
        - CA: 8 digits (e.g., "12345678")
        - NY: 11 digits (e.g., "12345678999")
        - TX: 6 digits (e.g., "123456")
        - FL: "SL" + 7 digits (e.g., "SL1234567")

        Default state: CA (California)
        """
        state_formats = {
            "CA": lambda: ''.join(random.choices('0123456789', k=8)),
            "NY": lambda: ''.join(random.choices('0123456789', k=11)),
            "TX": lambda: ''.join(random.choices('0123456789', k=6)),
            "FL": lambda: "SL" + ''.join(random.choices('0123456789', k=7))
        }
        
        return state_formats.get(state_code, state_formats["CA"])()  # Default to CA if state not found
    
    @staticmethod
    def generate_us_tollfree_number():
        """
        Generates a random U.S. Toll-Free Number.
        - Valid prefixes: 800, 833, 844, 855, 866, 877, 888
        - Format: XXX-XXX-XXXX
        """
        tollfree_prefixes = ["800", "833", "844", "855", "866", "877", "888"]
        prefix = random.choice(tollfree_prefixes)
        first_part = ''.join(random.choices('0123456789', k=3))
        second_part = ''.join(random.choices('0123456789', k=4))
        return f"{prefix}-{first_part}-{second_part}"

    @staticmethod
    def generate_us_taxpayer_reference_number():
        """
        Generates a random U.S. Taxpayer Reference Number.
        - Randomly selects between SSN, EIN, and ITIN.
        - SSN: XXX-XX-XXXX (e.g., "123-45-6789")
        - EIN: XX-XXXXXXX (e.g., "12-3456789")
        - ITIN: 9XX-XX-XXXX (e.g., "912-34-5678")
        """
        number_type = random.choice(["SSN", "EIN", "ITIN"])

        if number_type == "SSN":
            return f"{random.randint(100, 899)}-{random.randint(10, 99)}-{random.randint(1000, 9999)}"
        elif number_type == "EIN":
            return f"{random.randint(10, 99)}-{random.randint(1000000, 9999999)}"
        elif number_type == "ITIN":
            return f"9{random.randint(10, 99)}-{random.randint(10, 99)}-{random.randint(1000, 9999)}"

    @staticmethod
    def generate_military_id_number():
        """
        Generates a random U.S. Military ID Number.
        - Format: 10-digit numeric identifier (e.g., "1234567890")
        """
        return ''.join(random.choices('0123456789', k=10))
    
    @staticmethod
    def generate_alien_registration_number():
        """
        Generates a random U.S. Alien Registration Number (A-Number).
        - Format: 'A' followed by 8 or 9 digits (e.g., "A123456789")
        """
        num_length = random.choice([8, 9])  # Choose between 8 or 9 digits
        a_number = ''.join(random.choices('0123456789', k=num_length))
        return f"A{a_number}"
    

    @staticmethod
    def generate_hazardous_materials_id():
        """
        Generates a random U.S. Hazardous Materials Identification Number (UN/NA Number).
        - Format: 4-digit numeric identifier (e.g., "1203", "1993")
        """
        return f"{random.randint(1000, 9999)}"
    
    @staticmethod
    def generate_duns_number():
        """
        Generates a random D-U-N-S Number.
        - Format: 9-digit numeric identifier (e.g., "123456789")
        """
        return ''.join(random.choices('0123456789', k=9))
    

    @staticmethod
    def generate_erg_number():
        """
        Generates a random U.S. Emergency Response Guidebook (ERG) Number.
        - Format: 3-digit numeric identifier (e.g., "120", "199")
        """
        return f"{random.randint(100, 999)}"
    

    @staticmethod
    def generate_fmc_number():
        """
        Generates a random U.S. Federal Maritime Commission (FMC) Number.
        - Format: 6-digit numeric identifier (e.g., "123456")
        - Sometimes prefixed with "FMC-"
        """
        fmc_number = f"{random.randint(100000, 999999)}"
        return random.choice([fmc_number, f"FMC-{fmc_number}"])
    

    @staticmethod
    def generate_securities_account_number():
        """
        Generates a random U.S. Securities Account Number.
        - Format: 8 to 12 alphanumeric characters (e.g., "A12345678", "98765XYZ123")
        """
        length = random.randint(8, 12)  # Random length between 8 and 12
        account_number = ''.join(random.choices(string.ascii_uppercase + string.digits, k=length))
        return account_number
    

    @staticmethod
    def generate_bar_license_number():
        """
        Generates a random U.S. Bar License Number.
        - Format: 6 to 8-digit numeric identifier (e.g., "123456", "87654321")
        - Some states use a letter prefix (e.g., "NY123456", "CA987654")
        """
        number = ''.join(random.choices(string.digits, k=random.randint(6, 8)))
        prefix = random.choice(["NY", "CA", "TX", "FL", "IL", "PA", "WA", "GA", "OH", "NC", ""])  # Some states use prefixes
        return f"{prefix}{number}" if prefix else number
    

    @staticmethod
    def generate_dot_number():
        """
        Generates a random U.S. Department of Transportation (DOT) Number.
        - Format: 7 to 10-digit numeric identifier (e.g., "1234567", "9876543210")
        """
        dot_number = ''.join(random.choices('0123456789', k=random.randint(7, 10)))
        return dot_number
    
    @staticmethod
    def generate_lat_lon():
        """Generates a random latitude and longitude within the U.S."""
        latitude = round(random.uniform(24.396308, 49.384358), 6)  # U.S. latitude range
        longitude = round(random.uniform(-125.000000, -66.934570), 6)  # U.S. longitude range
        return f"{latitude}, {longitude}"
    

    @staticmethod
    def generate_fcc_call_sign():
        """
        Generates a random FCC Call Sign.
        - Broadcast stations: 3-4 letter format (e.g., "KABC", "WNYC")
        - Amateur radio: Letter-digit-letter (e.g., "K1ABC", "N9XYZ")
        - Commercial/marine: Letter-number format (e.g., "WXY1234", "KAB4567")
        """
        call_type = random.choice(["broadcast", "amateur", "commercial"])

        if call_type == "broadcast":
            prefix = random.choice(["K", "W"])
            suffix = ''.join(random.choices(string.ascii_uppercase, k=random.randint(3, 4)))
            return f"{prefix}{suffix}"

        elif call_type == "amateur":
            prefix = random.choice(["K", "N", "W"])
            number = random.randint(1, 9)
            suffix = ''.join(random.choices(string.ascii_uppercase, k=3))
            return f"{prefix}{number}{suffix}"

        else:  # Commercial/marine
            prefix = random.choice(["K", "W"])
            letters = ''.join(random.choices(string.ascii_uppercase, k=3))
            numbers = ''.join(random.choices(string.digits, k=4))
            return f"{prefix}{letters}{numbers}"
        

    @staticmethod
    def generate_federal_grant_number():
        """
        Generates a random U.S. Federal Grant Number.
        - Format 1: 'XX123456' (Agency Code + 6 Digits) → e.g., 'NS123456'
        - Format 2: 'XX-XX-123456' (Agency Code - Program Code - 6 Digits) → e.g., 'ED-21-654321'
        - Format 3: 'XX.X123456' (OMB Format: Agency Code . Fiscal Year + 6 Digits) → e.g., '93.A654321'
        """
        agency_codes = ["NS", "HR", "ED", "DO", "US", "NI", "AG", "TR", "FD", "CF"]  # Common federal agency codes
        program_codes = [str(random.randint(10, 99))]  # Random 2-digit program code
        fiscal_year = str(random.randint(10, 99))  # Last 2 digits of fiscal year

        grant_number_format = random.choice(["standard", "expanded", "omb"])
        
        if grant_number_format == "standard":
            return f"{random.choice(agency_codes)}{random.randint(100000, 999999)}"

        elif grant_number_format == "expanded":
            return f"{random.choice(agency_codes)}-{random.choice(program_codes)}-{random.randint(100000, 999999)}"

        else:  # OMB Format
            return f"{random.choice(agency_codes[:2])}.{random.choice(string.ascii_uppercase)}{random.randint(100000, 999999)}"
        

    @staticmethod
    def generate_naics_code():
        """
        Generates a random 6-digit NAICS code.
        - The first two digits correspond to a major industry sector.
        - The rest follow NAICS structure.
        """
        naics_sectors = [
            (11, 21),  # Agriculture, Forestry, Fishing, and Hunting
            (21, 22),  # Mining, Quarrying, Oil & Gas Extraction
            (23, 24),  # Construction
            (31, 34),  # Manufacturing
            (42, 43),  # Wholesale Trade
            (44, 46),  # Retail Trade
            (48, 50),  # Transportation & Warehousing
            (51, 52),  # Information
            (52, 54),  # Finance & Insurance
            (54, 56),  # Professional, Scientific, & Technical Services
            (61, 62),  # Education & Health Services
            (71, 73),  # Arts, Entertainment, & Recreation
            (81, 83),  # Other Services (except Public Admin)
            (92, 93)   # Public Administration
        ]

        sector_range = random.choice(naics_sectors)
        first_two_digits = random.randint(sector_range[0], sector_range[1] - 1)
        naics_code = f"{first_two_digits}{random.randint(0, 9)}{random.randint(0, 9)}{random.randint(0, 9)}{random.randint(0, 9)}"
        
        return naics_code
    
    @staticmethod
    def generate_sic_code():
        """
        Generates a random 4-digit SIC code.
        - First two digits represent the major industry sector.
        - The last two digits are random to represent a specific industry.
        """
        sic_sectors = [
            (1, 9),   # Agriculture, Forestry, and Fishing
            (10, 14), # Mining
            (15, 17), # Construction
            (20, 39), # Manufacturing
            (40, 49), # Transportation, Communications, Electric, Gas, and Sanitary Services
            (50, 51), # Wholesale Trade
            (52, 59), # Retail Trade
            (60, 67), # Finance, Insurance, and Real Estate
            (70, 89), # Services
            (91, 99)  # Public Administration
        ]

        sector_range = random.choice(sic_sectors)
        first_two_digits = random.randint(sector_range[0], sector_range[1])
        sic_code = f"{first_two_digits}{random.randint(0, 9)}{random.randint(0, 9)}"
        
        return sic_code
    
    @staticmethod
    def generate_ffl_number():
        """
        Generates a random FFL (Federal Firearms License) number.
        Format: X-XX-XXX-XX-XX-XXXXX
        """
        ffl_type = random.randint(1, 9)  # 1-digit license type
        issuing_district = random.randint(10, 99)  # 2-digit issuing district
        zip_prefix = random.randint(100, 999)  # First 3 digits of ZIP code
        issue_year = random.randint(10, 99)  # Last 2 digits of the year issued
        sequence_number = random.randint(10, 99)  # 2-digit FFL sequence number
        unique_id = random.randint(10000, 99999)  # 5-digit unique identifier

        ffl_number = f"{ffl_type}-{issuing_district}-{zip_prefix}-{issue_year}-{sequence_number}-{unique_id}"
        return ffl_number
    
    @staticmethod
    def generate_tin():
        """
        Generates a random Tax Identification Number (TIN).
        Can return SSN, EIN, ITIN, PTIN, or ATIN.
        """
        tin_types = ["SSN", "EIN", "ITIN", "PTIN", "ATIN"]
        selected_tin = random.choice(tin_types)

        if selected_tin == "SSN":
            tin_number = f"{random.randint(100, 899)}-{random.randint(10, 99)}-{random.randint(1000, 9999)}"
        elif selected_tin == "EIN":
            tin_number = f"{random.randint(10, 99)}-{random.randint(1000000, 9999999)}"
        elif selected_tin == "ITIN" or selected_tin == "ATIN":
            tin_number = f"9{random.randint(00, 99)}-{random.randint(10, 99)}-{random.randint(1000, 9999)}"
        elif selected_tin == "PTIN":
            tin_number = f"P{random.randint(1000000, 9999999)}"
        else:
            tin_number = "Unknown"

        return {"TIN Type": selected_tin, "TIN Number": tin_number}
    
    @staticmethod
    def generate_bank_amount(min_amount=100.00, max_amount=10000.00):
        """
        Generates a random bank amount.
        The amount will be a floating-point number rounded to two decimal places.
        
        Parameters:
        min_amount (float): Minimum amount value. Default is 100.00.
        max_amount (float): Maximum amount value. Default is 10000.00.
        
        Returns:
        float: Generated bank amount.
        """
        amount = round(random.uniform(min_amount, max_amount), 2)
        return amount

    





    

    
