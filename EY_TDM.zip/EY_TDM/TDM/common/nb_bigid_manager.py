# Databricks notebook source
# MAGIC %run /Workspace/EY/EY_TDM/TDM/common/nb_logger

# COMMAND ----------

import requests
from pyspark.sql import SparkSession
from pyspark.dbutils import DBUtils
logger = Logger(__name__).get_logger()

class BigIDManager:
    def __init__(self, metadata, config_path):
        try:
            logger.info("Initializing BigIDManager")
            self.config_path = config_path
            self.metadata = metadata
            self.classification = self.metadata.get("classification")
            self.bigid_connection_name = self.classification.get("app_connection_name")

            self.conn_configs = self.load_connection_configs()
            self.bigid_conn_config = self.conn_configs.get(self.bigid_connection_name, {})

            self.host = self.bigid_conn_config.get("host")
            self.user = self.bigid_conn_config.get("user")
            self.secret_scope = self.bigid_conn_config.get("secret_scope")
            self.pwd_secret = self.bigid_conn_config.get("pwd_secret")

            
            # Initialize KeyVaultReader 
            #keyvaultreader = KeyVaultReader(key_vault_url=self.pwd_key_vault_url)
            #password = keyvaultreader.get_secret(secret_name=self.pwd_key_vault_secret)
            self.spark = SparkSession.builder.appName("TestDataManagement").getOrCreate()
            dbutils = DBUtils(self.spark)
            password = dbutils.secrets.get(
            scope=self.secret_scope, key=self.pwd_secret)


            if not self.host or not self.user or not self.secret_scope or \
                not self.pwd_secret:
                raise ValueError("BigID connection details are missing in the configuration file.")
            else:
                session_request = requests.post(self.host+'api/v1/sessions', data = {'username': self.user, 'password': password})
                if session_request.status_code == 200:
                    session_data = session_request.json()
                    self.session_token = session_data.get('auth_token')
                else:
                    logger.error(f"Error initializing BigID session")
                    raise RuntimeError(f"Error initializing BigIDManager: {str(session_request)}")

                
        except Exception as e:
            logger.error(f"Error initializing BigIDManager: {e}")
            raise RuntimeError(f"Error initializing BigIDManager: {e}")

    def load_connection_configs(self):
        """Load connection configurations from the YAML file."""
        try:
            with open(self.config_path, "r") as file:
                return yaml.safe_load(file)["connection"]
        except FileNotFoundError:
            raise RuntimeError(f"Configuration file {self.config_path} not found.")
        except Exception as e:
            logger.error(f"Error loading connection configurations: {e}")
            raise RuntimeError(f"Error loading connection configurations: {e}")

    def get_object_details(self, object_name):
        try:

            logger.info(f"Fetching classfication details for {object_name} from BigID")
                  
            object_detail_request= requests.get(self.host+f"api/v1/data-catalog/object-details/columns?object_name={object_name}", headers = {'Authorization':self.session_token})
            
            if object_detail_request.status_code != 200:
               logger.error(f"Failed to fetch details for {object_name}. HTTP {object_detail_request.status_code}: {object_detail_request.text}")
               raise RuntimeError(f"Failed to fetch details for {object_name}. HTTP {object_detail_request.status_code}: {object_detail_request.text}")
           
            logger.info(f"Fetched classfication details for {object_name} from BigID")

            return object_detail_request.json()

        except Exception as e:
            logger.error(f"Unexpected error when fetching classifications for {object_name}: {e}")
            raise RuntimeError(f"Unexpected error when fetching classifications for {object_name}: {e}")