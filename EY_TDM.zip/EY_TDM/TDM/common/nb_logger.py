# Databricks notebook source
import logging
import sys
import os

class Logger:
    def __init__(self, module_name):
        self.logger = logging.getLogger(module_name)
        self.setup_logging()

    def setup_logging(self):
        logging.basicConfig(
            format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
            stream=sys.stdout,
            level='INFO',
            force=True,
        )

    def get_logger(self):
        return self.logger
