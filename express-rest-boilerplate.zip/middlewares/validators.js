import { body } from 'express-validator';

export const uploadFileValidator = [
  body('product_type').notEmpty().withMessage('product_type is required'),
  body('user_email').isEmail().withMessage('Valid user_email is required'),
  body('login_time').notEmpty().withMessage('login_time is required'),
];

export const processFileValidator = [
  body('product_type').notEmpty().withMessage('product_type is required'),
  body('file_name').notEmpty().withMessage('file_name is required'),
  body('run_id').notEmpty().withMessage('run_id is required'),
];

export const saveFeedbackValidator = [
  body('results_id').notEmpty().withMessage('results_id is required'),
  body('user_response').notEmpty().withMessage('user_response is required'),
  body('feedback_text').notEmpty().withMessage('feedback_text is required'),
];