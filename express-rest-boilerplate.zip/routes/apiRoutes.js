import { Router } from "express";
import { uploadFile } from "../controllers/uploadController.js";
import { processFile } from "../controllers/processController.js";
import { saveFeedback } from "../controllers/feedbackController.js";
import multer from "multer";
import { uploadFileValidator, processFileValidator, saveFeedbackValidator } from "../middlewares/validators.js";
import { validate } from "../middlewares/validate.js";

const router = Router();
const upload = multer();

// Routes
router.post("/upload", upload.single('file'), uploadFileValidator, validate, uploadFile);
router.post("/process", upload.none(), processFileValidator, validate, processFile);
router.post("/feedback", upload.none(), saveFeedbackValidator, validate, saveFeedback);

export default router;