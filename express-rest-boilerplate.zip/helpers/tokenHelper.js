import axios from "axios";

export const fetchToken = async () => {
  const endpoint = process.env.REACT_APP_APIM_End_Point;
  const headers = { 'Content-Type': 'application/x-www-form-urlencoded' };
  const requestBody = new URLSearchParams({
    grant_type: process.env.REACT_APP_APIM_Grant_Type,
    client_id: process.env.REACT_APP_APIM_Client_ID,
    client_secret: process.env.REACT_APP_APIM_Client_Secret,
    scope: process.env.REACT_APP_APIM_Scope,
  });

  try {
    const response = await axios.post(endpoint, requestBody.toString(), { headers });
    return response.data.access_token;
  } catch (error) {
    console.error('Error fetching token:', error.message);
    throw new Error('Something went wrong while fetching the token');
  }
};