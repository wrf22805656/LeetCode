import axios from "axios";

export const postToApi = async (apiUrl, accessToken, body = {}) => {
  try {
    const response = await axios.post(apiUrl.toString(), body, {
      headers: {
        Accept: "application/json",
        'Ocp-Apim-Subscription-key': process.env.REACT_APP_Ocp_Apim_Subscription_key,
        Authorization: `Bearer ${accessToken}`,
      },
    });
    return response.data;
  } catch (error) {
    console.error(error);
    const statusCode = error.response ? error.response.status : 500;
    const statusText = error.response ? error.response.statusText : 'Error making API request';
    throw { statusCode, statusText };
  }
};