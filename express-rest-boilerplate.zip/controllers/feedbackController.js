import { fetchToken } from "../helpers/tokenHelper.js";
import { postToApi } from "../helpers/apiHelper.js";
import dotenv from "dotenv";
dotenv.config();

const baseURL = process.env.REACT_APP_Apim_Url;

export const saveFeedback = async (req, res, next) => {
  const { results_id, user_response, feedback_text } = req.body;

  if (!results_id || !user_response || !feedback_text) {
    return res.status(400).json({ error: 'Parameters (results_id, user_response, feedback_text) are required' });
  }

  try {
    const accessToken = await fetchToken();
    const appendUrl = "SaveUserFeedback?";
    const apiUrl = new URL(`${baseURL}/${appendUrl}`);

    const data = await postToApi(apiUrl, accessToken, req.body);
    res.json(data);
  } catch (error) {
    res.status(error.statusCode).json({ error: error.statusText });
  }
};