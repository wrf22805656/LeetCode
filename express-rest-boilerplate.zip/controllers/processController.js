import { fetchToken } from "../helpers/tokenHelper.js";
import { postToApi } from "../helpers/apiHelper.js";
import dotenv from "dotenv";
dotenv.config();

const baseURL = process.env.REACT_APP_Apim_Url;

export const processFile = async (req, res, next) => {
  const appendUrl2 = "ProcessClauseValidationAndGetResult?";
  const { product_type, file_name, run_id } = req.body;

  if (!product_type || !file_name || !run_id) {
    return res.status(400).json({ error: 'Parameters (product_type, file_name, run_id) are required' });
  }

  try {
    const accessToken = await fetchToken();
    const apiUrl = new URL(`${baseURL}/${appendUrl2}`);
    apiUrl.search = new URLSearchParams({ product_type, file_name, run_id }).toString();

    const data = await postToApi(apiUrl, accessToken);
    res.json(data);
  } catch (error) {
    res.status(error.statusCode).json({ error: error.statusText });
  }
};