import axios from "axios";
import httpErrors from "http-errors";
import { validationResult } from "express-validator";
import { fetchToken } from "../helpers/tokenHelper.js";
import FormData from "form-data";
import dotenv from "dotenv";
dotenv.config();

const baseURL = process.env.REACT_APP_Apim_Url;

export const uploadFile = async (req, res, next) => {
  const appendUrl = "UpdateWaiverReviewFile?";
  const file = req.file;
  const { product_type, user_email, login_time } = req.body;

  if (!file) {
    return res.status(400).json({ error: 'File is required' });
  }

  try {
    const accessToken = await fetchToken();
    console.log(accessToken);
    const apiUrl = new URL(`${baseURL}/${appendUrl}`);
    apiUrl.search = new URLSearchParams({ product_type, user_email, login_time }).toString();

    const formData = new FormData();
    formData.append('file', file.buffer, { filename: file.originalname, contentType: file.mimetype });

    const response = await axios.post(apiUrl.toString(), formData, {
      headers: {
        Accept: "application/json",
        'Ocp-Apim-Subscription-key': process.env.REACT_APP_Ocp_Apim_Subscription_key,
        Authorization: `Bearer ${accessToken}`,
      },
    });

    res.json(response.data);
  } catch (error) {
    console.error(error);
    const statusCode = error.response ? error.response.status : 500;
    const statusText = error.response ? error.response.statusText : 'Error making API request';
    res.status(statusCode).json({ error: statusText });
}
};

export const processFile = async (req, res, next) => {
  const appendUrl2 = "ProcessClauseValidationAndGetResult?";
  const { product_type, file_name, run_id } = req.body;

  if (!product_type || !file_name || !run_id) {
    return res.status(400).json({ error: 'Parameters (product_type, file_name, run_id) are required' });
  }

  try {
    const accessToken = await fetchToken();
    const apiUrl = new URL(`${baseURL}/${appendUrl2}`);
    apiUrl.search = new URLSearchParams({ product_type, file_name, run_id }).toString();

    const response = await axios.post(apiUrl.toString(), {}, {
      headers: {
        Accept: "application/json",
        'Ocp-Apim-Subscription-key': process.env.REACT_APP_Ocp_Apim_Subscription_key,
        Authorization: `Bearer ${accessToken}`,
      },
    });

    res.json(response.data);
  }  catch (error) {
    console.error(error);
    const statusCode = error.response ? error.response.status : 500;
    const statusText = error.response ? error.response.statusText : 'Error making API request';
    res.status(statusCode).json({ error: statusText });
}
};

export const saveFeedback = async (req, res, next) => {
  const { results_id, user_response, feedback_text } = req.body;

  if (!results_id || !user_response || !feedback_text) {
    return res.status(400).json({ error: 'Parameters (results_id, user_response, feedback_text) are required' });
  }

  try {
    const accessToken = await fetchToken();
    const appendUrl = "SaveUserFeedback?";
    const apiUrl = new URL(`${baseURL}/${appendUrl}`);

    const response = await axios.post(apiUrl.toString(), req.body, {
      headers: {
        Accept: "application/json",
        'Ocp-Apim-Subscription-key': process.env.REACT_APP_Ocp_Apim_Subscription_key,
        Authorization: `Bearer ${accessToken}`,
      },
    });

    res.json(response.data);
  }  catch (error) {
    console.error(error);
    const statusCode = error.response ? error.response.status : 500;
    const statusText = error.response ? error.response.statusText : 'Error making API request';
    res.status(statusCode).json({ error: statusText });
}
};