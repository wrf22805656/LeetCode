import { fetchToken } from "../helpers/tokenHelper.js";
import { postToApi } from "../helpers/apiHelper.js";
import FormData from "form-data";
import dotenv from "dotenv";
dotenv.config();

const baseURL = process.env.REACT_APP_Apim_Url;

export const uploadFile = async (req, res, next) => {
  const appendUrl = "UpdateWaiverReviewFile?";
  const file = req.file;
  const { product_type, user_email, login_time } = req.body;

  if (!file) {
    return res.status(400).json({ error: 'File is required' });
  }

  try {
    const accessToken = await fetchToken();
    const apiUrl = new URL(`${baseURL}/${appendUrl}`);
    apiUrl.search = new URLSearchParams({ product_type, user_email, login_time }).toString();

    const formData = new FormData();
    formData.append('file', file.buffer, { filename: file.originalname, contentType: file.mimetype });

    const data = await postToApi(apiUrl, accessToken, formData);
    res.json(data);
  } catch (error) {
    res.status(error.statusCode).json({ error: error.statusText });
  }
};