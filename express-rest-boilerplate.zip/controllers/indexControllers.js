export const index = (req,res)=>{
    res.sendFile("./build/index.html",{root:"."})
}