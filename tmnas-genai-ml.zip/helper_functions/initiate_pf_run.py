import argparse
from azure.identity import DefaultAzureCredential
from promptflow.azure import PFClient

def funcPromptFlowRunAML(strFlowPath, strDataPath):
    """This function will be used run the Promptflow in Azure Machine Learning Studio
    
    Args - 
        strFlowPath (Type -> String) - Holds the Path of the Flow
        strDataPath (Type -> String) - Holds the path of the Data used for Testing Purpose
    
    Returns -
        None
    """

    # creating an object of the DefaultAzureCredential class.
    objCredential = DefaultAzureCredential()

    # Setting up the promptflow client by using the Default Azure Subscription
    pf = PFClient.from_config(credential=objCredential)

    # Defining the instance type and storing in a Dictionary
    dictResources = {"instance_type": 'serverless'}

    base_run = pf.run(
        flow=strFlowPath,
        data=strDataPath,
        resources = dictResources,
        column_mapping={
            "strWaiverFileName": "${data.strWaiverFileName}",
            "strProductType": "${data.strProductType}",
            "intRunID": "${data.intRunID}",
            "strProductTypeClassName": "${data.strProductTypeClassName}"
        }
    )

    pf.stream(base_run.name)

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--flow_path', type=str, required=True, help='Path of the flow')
    parser.add_argument('--data_path', type=str, required=True, help='Path of the test data')
    args = parser.parse_args()

    funcPromptFlowRunAML(args.flow_path, args.data_path)