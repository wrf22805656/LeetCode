######################################### MODULE INFORMATION ######################################### 
'''
This module acts as the node entry point for the promptflow's Data Vectorization stage.

'''
################################################# END #################################################

# Import required packages
from promptflow.core import tool
from modules.DataVectorizationAISearch import *

@tool
def nodeDataVectorization(listExtractedPageData : list, strWaiverFileName: str, strProductType: str, intRunID: int)-> str:
    '''
    Function to call subsequent module which helps in creating AI Search Vector Index from the extracted content generated in the Data Extraction and Chunking stage.

    Parameters: 
    - strWaiverFileName (str): file name of the document
    - strProductType (str): product type of the document
    - intRunID (int): Run Id of the current run

    return:
    - strVectorIndexName (str): the AI Search vector index name
    '''
    try:
        objVectorCreation = dataVectorization()
        strVectorIndexName = objVectorCreation.vectorization(listExtractedPageData, strProductType, intRunID)
        if 'ERROR' not in strVectorIndexName:
            return strVectorIndexName
        else:
            strErrorMessage = strVectorIndexName
            raise Exception(strErrorMessage)
    except Exception as e:
        if 'AML Endpoint - ERROR -' in str(e):
            raise Exception(str(e))
        else:
            strErrorMessage = f"RunID_{str(intRunID)} - AML Endpoint - ERROR - Data vectorization process has failed due to following error - "+str(e)
            print(strErrorMessage)
            raise Exception(strErrorMessage)
