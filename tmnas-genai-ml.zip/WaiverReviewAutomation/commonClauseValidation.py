######################################### MODULE INFORMATION ######################################### 
'''
This module defines all the clauses.
The steps followed in each clause are 
- data retrieval, 
- actual quote extraction
- detailed summary generation
- brief summary generation
- final output dictionary creation

'''
################################################# END #################################################

# Import required packages
import numpy as np
import time
import re
from modules.VectorRetrieval import dataRetrieval
from modules.utils import getGPTResponse, getBlobServiceClientTokenCredential, actualQuoteFormatting, getValidationOutputAndBriefSummary, generateBriefSummaryWithRequirement
from modules.FloridaUtils import clause4gDetailedOutputGeneration, extractTextBetweenSubstrings
from openai import AzureOpenAI
from azure.search.documents import SearchClient

class commonClause(object):
    def __init__(self,strVectorIndexName, strWaiverFileName, strProductType, intRunID):
        self.objRetrieve = dataRetrieval() #Initialize the dataRetrieval object
        self.strVectorIndexName=strVectorIndexName
        self.strWaiverFileName=strWaiverFileName
        self.strProductType=strProductType
        self.intRunID=intRunID
        self.intNumberOfRetries=3 #Number of retries if token generation fails for AI Search resource

    def validateClause3(self, dictClauseInfo:dict, intkValue:int, objSearchClient:SearchClient, objOpenAIClient:AzureOpenAI, dictConfig:dict):
        """
            This function is defined to validate the clause 3 for Camp Operator

            Parameters:
            - dictClauseInfo (dict): Holds details of the clauses like category, description, requirement number
            - intkValue (int): Number of chunks to retrieve
            - objSearchClient: Azure AI search client object
            - objOpenAIClient: Azure OpenAI client
            - dictConfig (dict): configuration details

            return:
            a tuple which contains the following variables
            - dictResponseClause3 (dict): dictionary of clause name, actual quote, detailed summary, brief summary for clause 3
            - strErrorMessage (str): error message if any occurs
        """
        # Get the metadata information of clause 3
        dictInfoClause3=dictClauseInfo["clause_3"]
        # Initialize the error message for clause. If at any step the processing fails this variable will hold the error information.
        # Done as in multithreaded fashion we can't log error on fly during execution. This variable holds the error and returns after thread run completes.
        strErrorMessage = ''
        
        intRetries=self.intNumberOfRetries
        for attempt in range(intRetries):
            try:
                # Retrieve the relevant chunks from the file corresponding to the clause 3
                strRetrievalQueryClause3="Extract those statements that mention the list of activities present in the waiver and check for Ineligible Exposures."
                strRetrievedDataClause3 = self.objRetrieve.getAISearchRetrievedChunk(self.intRunID, strRetrievalQueryClause3, intkValue, objSearchClient, objOpenAIClient, dictConfig)
            except Exception as e:
                # Check if any error occurs during retrieval process
                if 'DefaultAzureCredential failed to retrieve a token from the included credentials' in str(e) and attempt < (intRetries-1):
                    time.sleep(3)
                else:
                    strErrorMessage = f"RunID_{str(self.intRunID)} - AML Endpoint - ERROR - Data retrieval query for Requirement 1 has failed due to following error - "+str(e)
                    dictResponseClause3 = {**dictInfoClause3, "strValidationOutput":"Needs Review",
                    "strBriefSummary":"No response generated due to error at data retrieval",
                    "strDetailedSummary":"No response generated due to error at data retrieval",
                    "strActualQuote":"No response generated due to error at Data Retrieval"}
                    return (dictResponseClause3, strErrorMessage)

        try:
            # Actual Quote generation for clause 3
            strActualQuotePromptClause3 = f"""Please follow the below instruction step by step.
            Extract the names of all activities in which one can participate in the camp if mentioned in the waiver form. The waiver form of the camp is given below
            {strRetrievedDataClause3}
            1. Provide sentences between quotation mark from the {strRetrievedDataClause3} only where the activity name can be found. Extract that whole relevant sentence only along with activity. 
            Only if the sentence ends with something like mentioned below or extracted below or indicated below, extract the next sentence along with it. 
            Do not provide any extra information on your own.
            2. Consider movie related activities as an activity if present.
            3. If no relevant text can be found, simply return "No relevant language found.".
            """
            strActualQuoteOutputClause3 = getGPTResponse(strActualQuotePromptClause3, objOpenAIClient, dictConfig)
            if strActualQuoteOutputClause3 != 'No relevant language found.':
                # Formatting actual quote for clause 3
                strActualQuoteFormattingPrompt = f"""Your task is to reformat the text {strActualQuoteOutputClause3} exactly as it appears. 
                First enclose the sentence in quotation marks and return them with numeric pointers if there are multiple sentence. 
                If there is only one sentence, it will not be numbered.
                Sample output:
                1. "This is sample text1."
                2. "This is sample text2."
                3. "This is sample text3."
                """
                strActualQuoteFormattedOutputClause3 = getGPTResponse(strActualQuoteFormattingPrompt, objOpenAIClient, dictConfig)
            else:
                strActualQuoteFormattedOutputClause3 = strActualQuoteOutputClause3
        except Exception as e:
            # Check if any error occurs during actual quote generation
            strErrorMessage = f"RunID_{str(self.intRunID)} - AML Endpoint - ERROR - Actual quote generation for Requirement 1 has failed due to following error - "+str(e)
            dictResponseClause3 = {**dictInfoClause3, 
            "strValidationOutput":"Needs Review",
            "strBriefSummary":"No response generated due to error at actual quote generation",
            "strDetailedSummary":"No response generated due to error at actual quote generation",
            "strActualQuote":"Error at response generation for actual quote "}
            return (dictResponseClause3, strErrorMessage)
        try:
            listActualQuoteCheck =["No relevant language found."]
            # Detailed summary generation for clause 3
            if np.any([strActualQuoteFormattedOutputClause3 in i for i in listActualQuoteCheck]):
                strDetailedSummaryOutputClause3 = "No specific activity is mentioned in the waiver file. Hence, no activity qualifies as an ineligible exposure."
            else:
                strIneligibleActivity='''Wilderness Boot Camp, 
                Behavioral Correction, 
                Ocean/ Lake SCUBA, 
                Portable climbing walls, 
                Unguided Equine, 
                Competitive or Rodeo Equine Activities, 
                Travel Camps,  
                Zorbs or any other inflatable where individual is inside the apparatus, 
                Youth operated ATVs or Jet Skis'''
            
                strDetailedSummaryPromptPart1Clause3 = f"""Please follow the below instruction step by step.\n        
                1. Find out the names of all activities using {strActualQuoteFormattedOutputClause3} in which one can participate in the camp if mentioned in the waiver form. 
                2. Consider movie related activities as an activity only if it is present in {strActualQuoteFormattedOutputClause3}.
                3. Provide the activities name only in form of a list.\n
                4. Start the response with 'The waiver file mentions the following activities:'.
                5. Do not mention anything or any activity other than specified activities\n       
                6. Be specific with your answer, do not provide any extra details.\n"""
                strDetailedSummaryOutputPart1Clause3 = getGPTResponse(strDetailedSummaryPromptPart1Clause3, objOpenAIClient, dictConfig)
        
                # prompt to check if any activity of the waiver can qualify as extreme activity or uncontrolled/ unsupervised activity.
                strDetailedSummaryPromptPart2Clause3 = f"""Based on the context provided by {strActualQuoteFormattedOutputClause3}, only return which activity from {strDetailedSummaryOutputPart1Clause3} is clearly described as uncontrolled or
                unsupervised. 
                Return a square bracket list with the activities found above as uncontrolled or unsupervised from {strDetailedSummaryOutputPart1Clause3} .
                If no uncontrolled or unsupervised activity, return an empty list."""
                strDetailedSummaryOutputPart2Clause3 = getGPTResponse(strDetailedSummaryPromptPart2Clause3, objOpenAIClient, dictConfig)
                
                # prompt to check if any activity of the waiver can be part of ineligible activity list
                strDetailedSummaryPromptPart3Clause3=f"""Find out the extremely common or similar activity between the given ineligible activity list and camp activity list.
                ineligible activity list: {strIneligibleActivity}
                camp activity list: {strDetailedSummaryOutputPart1Clause3}
                If there are any extremely similar activity present between both lists, return a dictionary with:
                - key: the activity found only from camp activity list.
                - value: the matching activities only from ineligible activity list.
                If no extremely similar activities, return an empty dictionary without keys.
                """
                strDetailedSummaryOutputPart3Clause3 = getGPTResponse(strDetailedSummaryPromptPart3Clause3, objOpenAIClient, dictConfig)

                # prompt to check if any activity of the waiver can qualify as extreme activity.
                strDetailedSummaryPromptPart4Clause3 = f"""Based on the context provided by {strActualQuoteFormattedOutputClause3}, find out which activity from {strDetailedSummaryOutputPart1Clause3} is clearly an extreme activity. 
                Consider an activity as extreme if said activity has a severely high potential for injury or fatality, or involves firearms, rifles. 
                An activity is not extreme if it's commonly found at youth summer camp in the USA, such as paintball. Do not extrapolate in your reasoning. 
                If there is any extreme activity, return a python list with the activities found as extreme from {strDetailedSummaryOutputPart1Clause3}
                If no extreme activity is found, return an empty python list.
                """
                strDetailedSummaryOutputPart4Clause3 = getGPTResponse(strDetailedSummaryPromptPart4Clause3, objOpenAIClient, dictConfig)

                # Get list of all ineligible activities
                strDetailedSummaryPromptPart5Clause3 = f"""Merge into a single square bracket list:
                - the elements from {strDetailedSummaryOutputPart2Clause3} and {strDetailedSummaryOutputPart4Clause3}
                - the keys from {strDetailedSummaryOutputPart3Clause3} 
                Remove any duplicates. Return an empty list if there is no activity."""

                strDetailedSummaryOutputPart5Clause3 = getGPTResponse(strDetailedSummaryPromptPart5Clause3, objOpenAIClient, dictConfig)
                
                # Provide sentence with the list of activities that maybe ineligible
                strDetailedSummaryPromptPart6Clause3=f"""Follow below instructions for all the activities in {strDetailedSummaryOutputPart5Clause3}:
                1. If {strDetailedSummaryOutputPart5Clause3} does not contain any activity, return 'None of the mentioned activities qualify as an ineligible exposure.'
                2. If {strDetailedSummaryOutputPart5Clause3} is not empty, start your sentence with 'Some mentioned activities may qualify as ineligible:' and follow below instructions for each activity (called 'activity_in_question' afterwards) present in {strDetailedSummaryOutputPart5Clause3}:
                    1. Go to the line and start your sentence with a bullet point and mention that activity_in_question (replace with the activity name) 'may qualify as'. 
                    Points 2, 3 and 4 below are additional elements to append to the sentence, do not skip any instruction, multiple of those points can apply simultaneously:
                    2. If actvity_in_question is present in keys of dictionary {strDetailedSummaryOutputPart3Clause3}, append the matching values from {strDetailedSummaryOutputPart3Clause3} to the sentence.
                    3. If activity_in_question is present in {strDetailedSummaryOutputPart2Clause3}, append 'Uncontrolled/Unsupervised Activity' to the sentence.
                    4. If activity_in_question is present in {strDetailedSummaryOutputPart4Clause3}, append 'Extreme Activity' to the sentence.
                """
            
                strDetailedSummaryOutputPart6Clause3 = getGPTResponse(strDetailedSummaryPromptPart6Clause3, objOpenAIClient, dictConfig)
                
                # combining the output of and create final response (detailed view)
                strDetailedSummaryPromptClause3=f"""Simply print:
                1. {strDetailedSummaryOutputPart1Clause3}
                2. {strDetailedSummaryOutputPart6Clause3}
                """
                strDetailedSummaryOutputClause3 = getGPTResponse(strDetailedSummaryPromptClause3, objOpenAIClient, dictConfig)

        except Exception as e:
            # Check for any error during detailed summary generation process
            strErrorMessage = f"RunID_{str(self.intRunID)} - AML Endpoint - ERROR - Detailed summary generation for Requirement 1 has failed due to following error - "+str(e)
            dictResponseClause3 = {**dictInfoClause3, 
                                    "strValidationOutput":"Needs Review",
                                    "strBriefSummary":"No response generated due to error at detailed summary generation",
                                    "strDetailedSummary":"Error at response generation for detailed summary ",
                                    "strActualQuote":strActualQuoteFormattedOutputClause3}
            return (dictResponseClause3, strErrorMessage)


        try:
            # Brief Summary generation for clause 3
            if strDetailedSummaryOutputClause3=='No specific activity is mentioned in the waiver file. Hence, no activity qualifies as an ineligible exposure.':
                strBriefSummaryOutputClause3 = "Passed Validation - No specific activity is mentioned in the waiver file. Hence, no activity qualifies as an ineligible exposure."
            else:
                strBriefSummaryPromptClause3 = f"""If {strDetailedSummaryOutputClause3} concludes that none of the mentioned activities qualify as an ineligible exposure, simply return:
                'Passed Validation - The activities mentioned in the waiver file do not qualify as ineligible'
                else return 'Needs Review - Some of the activities present in the waiver file may qualify as ineligible, such as' along with the list of activities mentioned in {strDetailedSummaryOutputPart5Clause3} in lowercase.
                """
                strBriefSummaryOutputClause3 = getGPTResponse(strBriefSummaryPromptClause3, objOpenAIClient, dictConfig)
            
            strValidationOutputClause3, strBriefSummaryOutputClause3Split= getValidationOutputAndBriefSummary(strBriefSummaryOutputClause3)
            dictResponseClause3 ={**dictInfoClause3, "strValidationOutput":strValidationOutputClause3, 
                                "strBriefSummary":strBriefSummaryOutputClause3Split, 
                                "strDetailedSummary":strDetailedSummaryOutputClause3,
                                "strActualQuote":strActualQuoteFormattedOutputClause3
                                }
            return (dictResponseClause3, strErrorMessage)
        except Exception as e:
            # Check for any error during the brief summary generation process
            strErrorMessage = f"RunID_{str(self.intRunID)} - AML Endpoint - ERROR - Brief summary generation for Requirement 1 has failed due to following error - "+str(e)
            dictResponseClause3 = {**dictInfoClause3, 
                                "strValidationOutput":"Needs Review",
                                "strBriefSummary":"Error at response generation for brief summary ",
                                "strDetailedSummary":strDetailedSummaryOutputClause3,
                                "strActualQuote":strActualQuoteFormattedOutputClause3
                                }
            return (dictResponseClause3, strErrorMessage)

    def validateClause4a(self, dictClauseInfo:dict, intkValue:int, objSearchClient:SearchClient, objOpenAIClient:AzureOpenAI, dictConfig:dict):
        """
            This function is defined to validate the clause 4a (i) and(ii) for Camp Operator

            Parameters:
            - dictClauseInfo (dict): Holds details of the clauses like category, description, requirement number
            - intkValue (int): Number of chunks to retrieve
            - objSearchClient: Azure AI search client object
            - objOpenAIClient: Azure OpenAI client
            - dictConfig (dict): configuration details

            return:
            a tuple which contains the following two lists
            - first list
                - dictResponseClause4ai (dict): dictionary of clause name, actual quote, detailed summary, brief summary for clause 4ai
                - dictResponseClause4aii (dict): dictionary of clause name, actual quote, detailed summary, brief summary for clause 4aii
            - second list
                - strErrorMessage4ai (str): error message if any occurs
                - strErrorMessage4aii (str): error message if any occurs
        """
        # Get the metadata information of clause 4a
        dictInfoClause4ai=dictClauseInfo["clause_4a1"]
        dictInfoClause4aii=dictClauseInfo["clause_4a2"]

        # Error flag for sub clauses
        # Created so that if at any step one of the subclause fails it should not hamper the other subclause.
        boolErrorClause4ai = False
        boolErrorClause4aii = False

        # Initialize the error message for sub clauses. If at any step the processing fails this variable will hold the error information.
        # Done as in multithreaded fashion we can't log error on fly during execution. This variable holds the error and returns after thread run completes.
        strErrorMessage4ai = ''
        strErrorMessage4aii = ''

        intRetries=self.intNumberOfRetries
        for attempt in range(intRetries):
            try:
                # Retrieve the relevant chunks from the file corresponding to the clause 4a 
                strRetrievalQueryClause4a="Extract the text that releases the candidate from claims and liabilities and confirm that the waiver covers claims for liabilities for injury, property damage, wrongful death and other losses resulting from mistakes, errors, or faults of the provider or its owners, affiliates, employees, or agents."
                strRetrievedDataClause4a = self.objRetrieve.getAISearchRetrievedChunk(self.intRunID, strRetrievalQueryClause4a, intkValue, objSearchClient, objOpenAIClient, dictConfig)
            except Exception as e:
                # Check if any error occurs during retrieval process
                if 'DefaultAzureCredential failed to retrieve a token from the included credentials' in str(e) and attempt < (intRetries-1):
                    time.sleep(3)
                else:
                    strErrorMessage4ai = f"RunID_{str(self.intRunID)} - AML Endpoint - ERROR - Data retrieval query for Requirement 2 has failed due to following error - "+str(e)
                    strErrorMessage4aii = f"RunID_{str(self.intRunID)} - AML Endpoint - ERROR - Data retrieval query for Requirement 3 has failed due to following error - "+str(e)
                    dictResponseClause4ai = {**dictInfoClause4ai, "strValidationOutput":"Needs Review",
                    "strBriefSummary":"No response generated due to error at data retrieval",
                    "strDetailedSummary":"No response generated due to error at data retrieval",
                    "strActualQuote":"No response generated due to error at data retrieval "}
                    dictResponseClause4aii = {**dictInfoClause4aii, "strValidationOutput":"Needs Review",
                    "strBriefSummary":"No response generated due to error at data retrieval",
                    "strDetailedSummary":"No response generated due to error at data retrieval",
                    "strActualQuote":"No response generated due to error at data retrieval "}
                    return ([dictResponseClause4ai, dictResponseClause4aii], [strErrorMessage4ai, strErrorMessage4aii])

        try:
            # Actual Quote generation for clause 4a
            strActualQuotePromptClause4a = f"""Use the waiver text enclosed in triple back ticks to identify sentences that 
            -release the service provider and its staff from claims and liabilities
            -confirm the waiver covers claims for liabilities for injury, property damage, wrongful death, and other losses resulting from mistakes, errors, or faults of the provider or its owners, affiliates, employees, or agents.
            
            - If present, then extract complete sentences as it is without generating text on your own.
            The extracted sentences must be as pointers.
        
            - If not present, then respond saying that
            "No relevant language found."
            
            waiver text: '''{strRetrievedDataClause4a}'''
            """

            strActualQuoteOutputClause4a = getGPTResponse(strActualQuotePromptClause4a, objOpenAIClient, dictConfig)
            # Formatting actual quote for clause 4a
            if strActualQuoteOutputClause4a != 'No relevant language found.':
                strActualQuoteFormattedOutputClause4a = actualQuoteFormatting(strActualQuoteOutputClause4a, objOpenAIClient, dictConfig)
            else:
                strActualQuoteFormattedOutputClause4a = strActualQuoteOutputClause4a
        except Exception as e:
            # Check if any error occurs during actual quote generation
            boolErrorClause4ai = True
            boolErrorClause4aii = True
            strErrorMessage4ai = f"RunID_{str(self.intRunID)} - AML Endpoint - ERROR - Actual quote generation for Requirement 2 has failed due to following error - "+str(e)
            strErrorMessage4aii = f"RunID_{str(self.intRunID)} - AML Endpoint - ERROR - Actual quote generation for Requirement 3 has failed due to following error - "+str(e)
            dictResponseClause4ai = {**dictInfoClause4ai, 
            "strValidationOutput":"Needs Review",
            "strBriefSummary":"No response generated due to error at actual quote generation",
            "strDetailedSummary":"No response generated due to error at actual quote generation",
            "strActualQuote":"Error at response generation for actual quote "}
            dictResponseClause4aii = {**dictInfoClause4aii, 
            "strValidationOutput":"Needs Review",
            "strBriefSummary":"No response generated due to error at actual quote generation",
            "strDetailedSummary":"No response generated due to error at actual quote generation",
            "strActualQuote":"Error at response generation for actual quote "}

        # If error occurs for both sub clauses return the results with error messages
        if boolErrorClause4ai and boolErrorClause4aii:
            return ([dictResponseClause4ai, dictResponseClause4aii], [strErrorMessage4ai, strErrorMessage4aii])

        listActualQuoteCheck =['"No relevant language found."']
        # Detailed summary generation for clause 4a
        if np.any([strActualQuoteFormattedOutputClause4a in i for i in listActualQuoteCheck]):
            strDetailedSummaryOutputClause4ai = "The waiver file does not contain liability waiver language covering the service provider's name or covering their staff."
            strDetailedSummaryOutputClause4aii = "The waiver form does not contain liability waiver language covering claims for liabilities for injury, property damage, wrongful death. Other losses are not mentioned"
        else:
            if not boolErrorClause4ai:
                try:
                    # Detailed Summary generation for 4a (i)
                    strDetailedSummaryPromptClause4ai = f"""
                    Use the waiver text enclosed in triple backticks to check if it contains liability waiver language covering
                    the service provider and its staff.
                    
                    Output should be only in one line summary of conclusion about who is covered in waiver text and who is not.
                    If the staff (example: employees or volunteers) are not explicitly mentioned, do not consider them as covered.

                    # Only one clause in the waiver text needs to contain the liability waiver language covering
                    # the service provider and its employees.
                    
                    The output generated must be grammatically correct and use the phrase "waiver file" while
                    referring to the text. Begin the response with the statement "The waiver file contains/doesn't contain liability waiver language " .

                    waiver text: '''{strActualQuoteFormattedOutputClause4a}'''

                    """
                    strDetailedSummaryOutputClause4ai = getGPTResponse(strDetailedSummaryPromptClause4ai, objOpenAIClient, dictConfig)
                except Exception as e:
                    # Check if any error occurs during detailed summary generation
                    boolErrorClause4ai = True
                    strErrorMessage4ai = f"RunID_{str(self.intRunID)} - AML Endpoint - ERROR - Detailed summary generation for Requirement 2 has failed due to following error - "+str(e)
                    dictResponseClause4ai = {**dictInfoClause4ai, 
                    "strValidationOutput":"Needs Review",
                    "strBriefSummary":"No response generated due to error at detailed summary generation",
                    "strDetailedSummary":"Error at response generation for detailed summary ",
                    "strActualQuote":strActualQuoteFormattedOutputClause4a}
            
            if not boolErrorClause4aii:    
                try:
                    #Detailed Summary generation for 4a (ii)
                    strDetailedSummaryPromptClause4aii = f"""
                    Use the waiver text enclosed in triple backticks to check if it contains liability waiver language covering claims for liabilities for 
                    -injury, 
                    -property damage
                    -wrongful death

                    Provide answer only after going through the whole statement.
                    1.Output should be only in two lines of conclusion, where first line should be about what is covered in waiver text and what is not among injury, property damage and wrongful death.
                    2.For another line, follow below instruction:
                    Check if any other losses are mentioned as being covered (example: permanent injury, illness, disability).
                    If no other loss is mentioned, simply return 'Other losses are not mentioned.' without any additional language.
                    
                    The output generated must be crisp, grammatically correct and use the phrase "waiver file" while
                    referring to the text. Begin the response with the statement "The waiver file contains liability waiver language covering "

                    waiver text: '''{strActualQuoteFormattedOutputClause4a}'''  
                    
                    """
                    strDetailedSummaryOutputClause4aii = getGPTResponse(strDetailedSummaryPromptClause4aii, objOpenAIClient, dictConfig)
                except Exception as e:
                    # Check if any error occurs during detailed summary generation
                    boolErrorClause4aii = True
                    strErrorMessage4aii = f"RunID_{str(self.intRunID)} - AML Endpoint - ERROR - Detailed summary generation for Requirement 3 has failed due to following error - "+str(e)
                    dictResponseClause4aii = {**dictInfoClause4aii, 
                    "strValidationOutput":"Needs Review",
                    "strBriefSummary":"No response generated due to error at detailed summary generation",
                    "strDetailedSummary":"Error at response generation for detailed summary ",
                    "strActualQuote":strActualQuoteFormattedOutputClause4a}

        if not boolErrorClause4ai:   
            try:
                #Brief Summary generation for 4a (i)
                strBriefSummaryPromptClause4ai = f"""
                Your task is to evaluate the waiver text enclosed in triple backticks,
                based on the following conditions and respond if further attention from the underwriter is 
                required or not.


                Use the below conditions carefully to determine if further attention of underwriter is required:
                - If there is any language in waiver text mentioning the waiver file contains liability waiver language covering both the service provider and its staff or employees, then no further validation from underwriter is required and 
                the text can be considered for "Passed validation", else "Needs review".
                - If Passed validation add reasoning "The waiver file contains liability waiver language covering both the service provider and its employees."
                - If Needs review add the reasoning in only single statement beginning with the phrase "The waiver file" and it should mention if waiver text contains liability waiver language covering service provider or employees, or both service provider and employees or doesn't contain any of them.
                
                Output format:
                Needs Review - along with your reasoning
                or
                Passed Validation - along with your reasoning 

                Ensure the reasoning is grammatically correct.

                waiver text: '''{strDetailedSummaryOutputClause4ai}'''

                """
                strBriefSummaryOutputClause4ai = getGPTResponse(strBriefSummaryPromptClause4ai, objOpenAIClient, dictConfig)
                strValidationOutputClause4ai, strBriefSummaryOutputClause4aiSplit= getValidationOutputAndBriefSummary(strBriefSummaryOutputClause4ai)

                strRequirementDescriptionClause4ai = dictInfoClause4ai['strReqDescription']
                strNewRequirementDescriptionClause4ai = generateBriefSummaryWithRequirement(strRequirementDescriptionClause4ai, objOpenAIClient, dictConfig)
                strBriefSummaryOutputClause4aiSplit = strNewRequirementDescriptionClause4ai +' '+ strBriefSummaryOutputClause4aiSplit
                
                dictResponseClause4ai ={**dictInfoClause4ai, "strValidationOutput":strValidationOutputClause4ai, 
                "strBriefSummary":strBriefSummaryOutputClause4aiSplit, 
                "strDetailedSummary":strDetailedSummaryOutputClause4ai,
                "strActualQuote":strActualQuoteFormattedOutputClause4a
                }

            except Exception as e:
                # Check if any error occurs during brief summary generation
                boolErrorClause4ai = True
                strErrorMessage4ai = f"RunID_{str(self.intRunID)} - AML Endpoint - ERROR - Brief summary generation for Requirement 2 has failed due to following error - "+str(e)
                dictResponseClause4ai = {**dictInfoClause4ai, 
                "strValidationOutput":"Needs Review",
                "strBriefSummary":"Error at response generation for brief summary ",
                "strDetailedSummary":strDetailedSummaryOutputClause4ai,
                "strActualQuote":strActualQuoteFormattedOutputClause4a
                }


        if not boolErrorClause4aii:
            try:
                #Brief Summary generation for 4a (ii)
                strBriefSummaryPromptClause4aii = f"""
                Your task is to evaluate the waiver text enclosed in triple backticks,
                based on the following conditions and respond if further attention from the underwriter is 
                required or not.

                Be careful and understand the below conditions to determine if further attention of underwriter is required:
                If the text covers claims for liabilities for all of these: injury, property damage and wrongful death,
                then it means no further validation of underwriter is required and therefore the text can be considered "Passed validation",
                
                else,text can be considered for "Needs review".
                
                Also, add a sentence to check about mention of other losses, if no losses are mentioned, just return 'Other losses are not mentioned.'
                
                Output format:
                Needs review - along with your reasoning
                or
                Passed validation - along with your reasoning

                Provide the reasoning in a single statement beginning with the phrase "The waiver file" and it should mention if waiver text contains or doesn't contain  liability waiver language covering.
                Ensure the reasoning is grammatically correct.

                waiver text: '''{strDetailedSummaryOutputClause4aii}'''
                """
                strBriefSummaryOutputClause4aii = getGPTResponse(strBriefSummaryPromptClause4aii, objOpenAIClient, dictConfig)
                strValidationOutputClause4aii, strBriefSummaryOutputClause4aiiSplit= getValidationOutputAndBriefSummary(strBriefSummaryOutputClause4aii)
                
                strRequirementDescriptionClause4aii = dictInfoClause4aii['strReqDescription']
                strNewRequirementDescriptionClause4aii = generateBriefSummaryWithRequirement(strRequirementDescriptionClause4aii, objOpenAIClient, dictConfig)
                strBriefSummaryOutputClause4aiiSplit = strNewRequirementDescriptionClause4aii +' '+ strBriefSummaryOutputClause4aiiSplit

                dictResponseClause4aii ={**dictInfoClause4aii, "strValidationOutput":strValidationOutputClause4aii, 
                "strBriefSummary":strBriefSummaryOutputClause4aiiSplit, 
                "strDetailedSummary":strDetailedSummaryOutputClause4aii,
                "strActualQuote":strActualQuoteFormattedOutputClause4a
                }

            except Exception as e:
                # Check if any error occurs during brief summary generation
                boolErrorClause4aii = True
                strErrorMessage4aii = f"RunID_{str(self.intRunID)} - AML Endpoint - ERROR - Brief summary generation for Requirement 3 has failed due to following error - "+str(e)
                dictResponseClause4aii = {**dictInfoClause4aii, 
                "strValidationOutput":"Needs Review",
                "strBriefSummary":"Error at response generation for brief summary ",
                "strDetailedSummary":strDetailedSummaryOutputClause4aii,
                "strActualQuote":strActualQuoteFormattedOutputClause4a
                }

        return ([dictResponseClause4ai, dictResponseClause4aii], [strErrorMessage4ai, strErrorMessage4aii])

    def validateClause4b(self, dictClauseInfo:dict, intkValue:int, objSearchClient:SearchClient, objOpenAIClient:AzureOpenAI, dictConfig:dict):
        """
            This function is defined to validate the clause 4b for Camp Operator

            Parameters:
            - dictClauseInfo (dict): Holds details of the clauses like category, description, requirement number
            - intkValue (int): Number of chunks to retrieve
            - objSearchClient: Azure AI search client object
            - objOpenAIClient: Azure OpenAI client
            - dictConfig (dict): configuration details

            return:
            a tuple which contains the following two lists
            - first list
                - dictResponseClause4bi (dict): dictionary of clause name, actual quote, detailed summary, brief summary for clause 4bi
                - dictResponseClause4bii (dict): dictionary of clause name, actual quote, detailed summary, brief summary for clause 4bii
                - dictResponseClause4biii (dict): dictionary of clause name, actual quote, detailed summary, brief summary for clause 4biii
            - second list
                - strErrorMessage4bi (str): error message if any occurs
                - strErrorMessage4bii (str): error message if any occurs
                - strErrorMessage4biii (str): error message if any occurs
        """
        # Actual quote formatting function for clause 4b
        def actualQuoteFormattingClause4b(strText:str, objOpenAIClient:AzureOpenAI, dictConfig:dict):
            '''
            Function to format the quote according to the specified format

            Parameters:
            - strText (str): Actual quote generated from GPT response
            - objOpenAIClient (AzureOpenAI object): The Azure OpenAI client
            - dictConfig (dict): configuration details

            return:
            - strFormattedAcutalQuote (str): Formatted Actual quote
            '''
            strActualQuoteFormattingPrompt = f"""

        Your task is to reformat the text {strText} which contains sentences, first enclose all the sentences
        in quotation marks and then number all of them.
        If there is only one sentence, then do not number it.   
        Sample output:
        1. "This is sample text1."
        2. "This is sample text2."
        3. "This is sample text3."
        
        """
            strFormattedAcutalQuote =  getGPTResponse(strActualQuoteFormattingPrompt, objOpenAIClient, dictConfig)

            return strFormattedAcutalQuote
        
        # Get the metadata information of all the sub clauses of clause 4b
        dictInfoClause4bi=dictClauseInfo["clause_4b1"]
        dictInfoClause4bii=dictClauseInfo["clause_4b2"]
        dictInfoClause4biii=dictClauseInfo["clause_4b3"]
        # Error flags for sub clauses of clause 4b
        # Created so that if at any step one of the subclause fails it should not hamper the other subclause.
        boolExceptionClause4bi = boolExceptionClause4bii = boolExceptionClause4biii = False
        # Initialize the error message for sub clauses. If at any step the processing fails this variable will hold the error information.
        # Done as in multithreaded fashion we can't log error on fly during execution. This variable holds the error and returns after thread run completes.
        strErrorMessage4bi = ''
        strErrorMessage4bii = ''
        strErrorMessage4biii = ''

        intRetries=self.intNumberOfRetries
        for attempt in range(intRetries):
            try:
               # Retrieve the relevant chunks from the file corresponding to the clause 4b
                strRetrievalQueryClause4b="Find text in the waiver form that discusses inherent risks associated with the participation of activities"
                strRetrievedDataClause4b = self.objRetrieve.getAISearchRetrievedChunk(self.intRunID, strRetrievalQueryClause4b, intkValue, objSearchClient, objOpenAIClient, dictConfig)
            except Exception as e:
                # Check if any error occurs during retrieval process
                if 'DefaultAzureCredential failed to retrieve a token from the included credentials' in str(e) and attempt < (intRetries-1):
                    time.sleep(3)
                else:
                    strErrorMessage4bi = f"RunID_{str(self.intRunID)} - AML Endpoint - ERROR - Data retrieval query for Requirement 4 has failed due to following error - "+str(e)
                    strErrorMessage4bii = f"RunID_{str(self.intRunID)} - AML Endpoint - ERROR - Data retrieval query for Requirement 5 has failed due to following error - "+str(e)
                    strErrorMessage4biii = f"RunID_{str(self.intRunID)} - AML Endpoint - ERROR - Data retrieval query for Requirement 6 has failed due to following error - "+str(e)
                    dictResponseClause4bi = {**dictInfoClause4bi, "strValidationOutput":"Needs Review",
                    "strBriefSummary":"No response generated due to error at data retrieval",
                    "strDetailedSummary":"No response generated due to error at data retrieval",
                    "strActualQuote":"No response generated due to error at data retrieval "}
                    
                    dictResponseClause4bii = {**dictInfoClause4bii, "strValidationOutput":"Needs Review",
                    "strBriefSummary":"No response generated due to error at data retrieval",
                    "strDetailedSummary":"No response generated due to error at data retrieval",
                    "strActualQuote":"No response generated due to error at data retrieval "}

                    dictResponseClause4biii = {**dictInfoClause4biii, "strValidationOutput":"Needs Review",
                    "strBriefSummary":"No response generated due to error at data retrieval",
                    "strDetailedSummary":"No response generated due to error at data retrieval",
                    "strActualQuote":"No response generated due to error at data retrieval "}

                    return ([dictResponseClause4bi,dictResponseClause4bii,dictResponseClause4biii], [strErrorMessage4bi, strErrorMessage4bii, strErrorMessage4biii])

        try:
            #Actual Quote generation for clause 4bi
            strActualQuotePromptClause4bi = f"""
            Use the waiver text enclosed in triple back ticks to identify sentences that mention about the specific
            risks involved in the participation of activities which could lead to injury or death.
            - If there is mention of risks, then extract complete sentences as it is without generating text 
            on your own.The extracted sentences must be as pointers.
            - If risks are not mentioned , then respond saying that
            "No relevant language found."

            waiver text:  '''{strRetrievedDataClause4b}'''
            """

            strActualQuoteOutputClause4bi = getGPTResponse(strActualQuotePromptClause4bi, objOpenAIClient, dictConfig)
            # Formatting of generated actual quote
            if strActualQuoteOutputClause4bi != 'No relevant language found.':
                strActualQuoteFormattedOutputClause4bi = actualQuoteFormattingClause4b(strActualQuoteOutputClause4bi, objOpenAIClient, dictConfig)
            else:
                strActualQuoteFormattedOutputClause4bi = strActualQuoteOutputClause4bi
        except Exception as e:
            # Check if any error occurs during actual quote generation
            boolExceptionClause4bi = True
            strErrorMessage4bi = f"RunID_{str(self.intRunID)} - AML Endpoint - ERROR - Actual quote generation for Requirement 4 has failed due to following error - "+str(e)
            dictResponseClause4bi = {**dictInfoClause4bi, 
            "strValidationOutput":"Needs Review",
            "strBriefSummary":"No response generated due to error at actual quote generation",
            "strDetailedSummary":"No response generated due to error at actual quote generation",
            "strActualQuote":"Error at response generation for actual quote "}

            
        try:
            # Actual Quote generation for clause 4bii
            
            strActualQuotePromptClause4bii = f"""
            Use the waiver text enclosed in triple back ticks to identify sentences where participants acknowledge
            understanding the risks involved with participating in the activity could result in injury.
            Exclude sentences that does not contain the word 'injury' or 'injuries'.    
            - If there is mention, then extract complete sentences as it is without generating text 
            on your own.The extracted sentences must be as pointers.
            - If risks are not mentioned , then respond saying that
            "No relevant language found."

            waiver text:  '''{strRetrievedDataClause4b}'''
            """

            strActualQuoteOutputClause4bii = getGPTResponse(strActualQuotePromptClause4bii, objOpenAIClient, dictConfig)
            # Formatting of generated actual quote
            if strActualQuoteOutputClause4bii != 'No relevant language found.':
                strActualQuoteFormattedOutputClause4bii = actualQuoteFormattingClause4b(strActualQuoteOutputClause4bii, objOpenAIClient, dictConfig)
            else:
                strActualQuoteFormattedOutputClause4bii = strActualQuoteOutputClause4bii
        except Exception as e:
            # Check if any error occurs during actual quote generation
            boolExceptionClause4bii = True
            strErrorMessage4bii = f"RunID_{str(self.intRunID)} - AML Endpoint - ERROR - Actual quote generation for Requirement 5 has failed due to following error - "+str(e)
            dictResponseClause4bii = {**dictInfoClause4bii, 
            "strValidationOutput":"Needs Review",
            "strBriefSummary":"No response generated due to error at actual quote generation",
            "strDetailedSummary":"No response generated due to error at actual quote generation",
            "strActualQuote":"Error at response generation for actual quote "}

        try:
            # Actual quote generation for clause 4biii
            strActualQuotePromptClause4biii = f"""
            Use the waiver text enclosed in triple back ticks to identify sentences that mention about the participant
            assuming the risks with participating in the activity that could result in injury or death, willfully and
            voluntarily.
            - If there is mention, then extract complete sentences as it is without generating text 
            on your own.The extracted sentences must be as pointers.
            - If risks are not mentioned , then respond saying that
            "No relevant language found."
            waiver text: '''{strRetrievedDataClause4b}'''
            """

            strActualQuoteOutputClause4biii = getGPTResponse(strActualQuotePromptClause4biii, objOpenAIClient, dictConfig)
            # Formatting of generated actual quote
            if strActualQuoteOutputClause4biii != 'No relevant language found.':
                strActualQuoteFormattedOutputClause4biii = actualQuoteFormattingClause4b(strActualQuoteOutputClause4biii, objOpenAIClient, dictConfig)
            else:
                strActualQuoteFormattedOutputClause4biii = strActualQuoteOutputClause4biii
            
        except Exception as e:
            # Check if any error occurs during actual quote generation
            boolExceptionClause4biii = True
            strErrorMessage4biii = f"RunID_{str(self.intRunID)} - AML Endpoint - ERROR - Actual quote generation for Requirement 6 has failed due to following error - "+str(e)
            dictResponseClause4biii = {**dictInfoClause4biii, 
            "strValidationOutput":"Needs Review",
            "strBriefSummary":"No response generated due to error at actual quote generation",
            "strDetailedSummary":"No response generated due to error at actual quote generation",
            "strActualQuote":"Error at response generation for actual quote "}
        
        # If error occurs for all the sub clauses return the results and the error messages
        if boolExceptionClause4bi and boolExceptionClause4bii and boolExceptionClause4biii:
            return ([dictResponseClause4bi, dictResponseClause4bii,dictResponseClause4biii], [strErrorMessage4bi, strErrorMessage4bii, strErrorMessage4biii])
        
        # Initialize the detailed summary of all sub clauses of clause 4b
        strDetailedSummaryOutputClause4bi = ""
        strDetailedSummaryOutputClause4bii = ""
        strDetailedSummaryOutputClause4biii = ""

        # Detailed summary generation
        listActualQuoteCheck =['"No relevant language found."','No relevant language found.']
        if not boolExceptionClause4bi:
            if np.any([strActualQuoteOutputClause4bi in i for i in listActualQuoteCheck]):
                strDetailedSummaryOutputClause4bi = "The waiver file does not list any specific risks inherent in the activities."
        if not boolExceptionClause4bii:
            if np.any([strActualQuoteOutputClause4bii in i for i in listActualQuoteCheck]):
                strDetailedSummaryOutputClause4bii = "The waiver file does not contain language to check that the participant acknowledges understanding the risks associated with the activities may result in injury."
        if not boolExceptionClause4biii:    
            if np.any([strActualQuoteOutputClause4biii in i for i in listActualQuoteCheck]):
                strDetailedSummaryOutputClause4biii = "The waiver file does not contain language to validate that the participant is assuming all risks willfully and voluntarily"
        
        if not strDetailedSummaryOutputClause4bi and not boolExceptionClause4bi:
                try:
                    #Detailed Summary generation for clause 4bi
                    strDetailedSummaryPromptClause4bi = f"""
                    Use the waiver text enclosed in triple backticks to extract the risks involved with participation
                    of activities which could be dangerous physically.
                    Identify, extract and list out the risks only from the text provided, do not come up with the risks on your
                    own. 
                    The output generated must begin with the below statement followed by the risks extracted from the 
                    waiver text. The risks must be specific without much explanation.
                    "The waiver file lists the risks for the Camp Operator inherent in the activities mentioned. The risks listed are:"
                    Refer to the text as "waiver file" wherever applicable while generating the text.
                    Ensure that the response is grammatically correct.
                    waiver text: '''{strActualQuoteFormattedOutputClause4bi}'''
                    Example of risks : injury, death, accident,etc
                    sample output:
                    The waiver file lists the risks for the Camp Operator inherent in the activities mentioned. The risks listed are:
                    - Injury
                    - Death
                    """
                    strDetailedSummaryOutputClause4bi = getGPTResponse(strDetailedSummaryPromptClause4bi, objOpenAIClient, dictConfig)
                except Exception as e:
                    # Check if any error occurs during detailed summary generation
                    boolExceptionClause4bi = True
                    strErrorMessage4bi = f"RunID_{str(self.intRunID)} - AML Endpoint - ERROR - Detailed summary generation for Requirement 4 has failed due to following error - "+str(e)
                    dictResponseClause4bi = {**dictInfoClause4bi, 
                    "strValidationOutput":"Needs Review",
                    "strBriefSummary":"No response generated due to error at detailed summary generation",
                    "strDetailedSummary":"Error at response generation for detailed summary ",
                    "strActualQuote":strActualQuoteFormattedOutputClause4bi}

        if not strDetailedSummaryOutputClause4bii and not boolExceptionClause4bii:
                try:
                    #Detailed summary generation for clause 4bii
                    strDetailedSummaryPromptClause4bii = f"""
                    Use the waiver text enclosed in triple backticks to check the acknowledgement of the participant
                    about his understanding on the risks involved in the participation of the activities could lead to injury .
                    The output generated must be grammatically correct and use the phrase "waiver file" while
                    referring to the text. Begin the response with the statement "The waiver file contains language to check that the participant acknowledges"
                    waiver text:'''{strActualQuoteFormattedOutputClause4bii}'''

                    """
                    strDetailedSummaryOutputClause4bii = getGPTResponse(strDetailedSummaryPromptClause4bii, objOpenAIClient, dictConfig)

                except Exception as e:
                    # Check if any error occurs during deatiled summary generation
                    boolExceptionClause4bii = True
                    strErrorMessage4bii = f"RunID_{str(self.intRunID)} - AML Endpoint - ERROR - Detailed summary generation for Requirement 5 has failed due to following error - "+str(e)
                    dictResponseClause4bii = {**dictInfoClause4bii, 
                    "strValidationOutput":"Needs Review",
                    "strBriefSummary":"No response generated due to error at detailed summary generation",
                    "strDetailedSummary":"Error at response generation for detailed summary ",
                    "strActualQuote":strActualQuoteFormattedOutputClause4bii}
 
        if not strDetailedSummaryOutputClause4biii and not boolExceptionClause4biii:
                try:
                    #Detailed Summary generation - 4biii
                    strDetailedSummaryPromptClause4biii = f"""
                    Use the waiver text enclosed in triple backticks to check the acknowledgement of the participant
                    where they are agreeing to take the risks willfully and voluntarily while participating
                    in the activities.
                    The output generated must be grammatically correct and use the phrase "waiver file" while
                    referring to the text. Begin the response with the statement "The waiver file contains the language validating that the participant is assuming all risks "
                    waiver text: '''{strActualQuoteFormattedOutputClause4biii}'''
                    """
                    strDetailedSummaryOutputClause4biii = getGPTResponse(strDetailedSummaryPromptClause4biii, objOpenAIClient, dictConfig)
                except Exception as e:
                    # Check if any error occurs during deatiled summary generation
                    boolExceptionClause4biii = True
                    strErrorMessage4biii = f"RunID_{str(self.intRunID)} - AML Endpoint - ERROR - Detailed summary generation for Requirement 6 has failed due to following error - "+str(e)
                    dictResponseClause4biii = {**dictInfoClause4biii, 
                    "strValidationOutput":"Needs Review",
                    "strBriefSummary":"No response generated due to error at detailed summary generation",
                    "strDetailedSummary":"Error at response generation for detailed summary ",
                    "strActualQuote":strActualQuoteFormattedOutputClause4biii}

        if not boolExceptionClause4bi:
            try:
                #Brief Summary generation for clause 4bi
                strBriefSummaryPromptClause4bi =  f'''Proceed based on the findings: Check whether the statement {strDetailedSummaryOutputClause4bi} list 
                of risks associated with the activities for camp operator, then the requirement needs no 
                further attention from the underwriter and it is 'Passed Validation',
                else if the statement does not list down any risks,
                then requirement needs further validation from the underwriter and it is 'Needs Review'. 
                Provide answer only after going through the whole statement.
                The response should be of the below format and only for requirement 4:
                Needs review - along with your conclusion
                or
                Passed validation - along with your conclusion
                Provide the conclusion in a single statement and should be grammatically correct.
                Use the phrase "waiver file" while referring to the text in your conclusion.
                '''
                strBriefSummaryOutputClause4bi = getGPTResponse(strBriefSummaryPromptClause4bi, objOpenAIClient, dictConfig)
                strValidationOutputClause4bi, strBriefSummaryOutputClause4biSplit= getValidationOutputAndBriefSummary(strBriefSummaryOutputClause4bi)
                
                strRequirementDescriptionClause4bi = dictInfoClause4bi['strReqDescription']
                strNewRequirementDescriptionClause4bi = generateBriefSummaryWithRequirement(strRequirementDescriptionClause4bi, objOpenAIClient, dictConfig)
                strBriefSummaryOutputClause4biSplit = strNewRequirementDescriptionClause4bi +' '+ strBriefSummaryOutputClause4biSplit
                
                dictResponseClause4bi ={**dictInfoClause4bi, "strValidationOutput":strValidationOutputClause4bi, 
                                        "strBriefSummary":strBriefSummaryOutputClause4biSplit, 
                                        "strDetailedSummary":strDetailedSummaryOutputClause4bi,
                                        "strActualQuote":strActualQuoteFormattedOutputClause4bi
                                        }
            except Exception as e:
                # Check if any error occurs during brief summary generation
                boolExceptionClause4bi = True
                strErrorMessage4bi = f"RunID_{str(self.intRunID)} - AML Endpoint - ERROR - Brief summary generation for Requirement 4 has failed due to following error - "+str(e)
                dictResponseClause4bi = {**dictInfoClause4bi, 
                "strValidationOutput":"Needs Review",
                "strBriefSummary":"Error at response generation for brief summary ",
                "strDetailedSummary":strDetailedSummaryOutputClause4bi,
                "strActualQuote":strActualQuoteFormattedOutputClause4bi
                }

        if not boolExceptionClause4bii:
            try:
                #Brief Summary generation - 4bii
                strBriefSummaryPromptClause4bii =f"""
                Your task is to evaluate the waiver text enclosed on triple backticks based on the following conditions,
                - If the waiver text mentions about acknowledgement of the participants understanding of risks 
                involved in the activities could lead to injury then the text can be considered "Passed validation".
                - If the waiver text does not mention about participants acknowledgement about the risk, then
                text should be considered "Needs review".
                Output format:
                Needs review - along with your conclusion
                or
                Passed validation - along with your conclusion
                Provide the conclusion in a single statement and it should be grammatically correct.
                Use the phrase "waiver file" while referring to the text in your conclusion.
                waiver text: '''{strDetailedSummaryOutputClause4bii}'''

                """
                strBriefSummaryOutputClause4bii = getGPTResponse(strBriefSummaryPromptClause4bii, objOpenAIClient, dictConfig)
                strValidationOutputClause4bii, strBriefSummaryOutputClause4biiSplit= getValidationOutputAndBriefSummary(strBriefSummaryOutputClause4bii)
                
                strRequirementDescriptionClause4bii = dictInfoClause4bii['strReqDescription']
                strNewRequirementDescriptionClause4bii = generateBriefSummaryWithRequirement(strRequirementDescriptionClause4bii, objOpenAIClient, dictConfig)
                strBriefSummaryOutputClause4biiSplit = strNewRequirementDescriptionClause4bii +' '+ strBriefSummaryOutputClause4biiSplit

                dictResponseClause4bii ={**dictInfoClause4bii, "strValidationOutput":strValidationOutputClause4bii, 
                                    "strBriefSummary":strBriefSummaryOutputClause4biiSplit, 
                                    "strDetailedSummary":strDetailedSummaryOutputClause4bii,
                                    "strActualQuote":strActualQuoteFormattedOutputClause4bii
                                    }
            except Exception as e:
                # Check if any error occurs during brief summary generation
                boolExceptionClause4bii = True
                strErrorMessage4bii = f"RunID_{str(self.intRunID)} - AML Endpoint - ERROR - Brief summary generation for Requirement 5 has failed due to following error - "+str(e)
                dictResponseClause4bii = {**dictInfoClause4bii, 
                "strValidationOutput":"Needs Review",
                "strBriefSummary":"Error at response generation for brief summary ",
                "strDetailedSummary":strDetailedSummaryOutputClause4bii,
                "strActualQuote":strActualQuoteFormattedOutputClause4bii
                }

        if not boolExceptionClause4biii:      
            try:
                #Brief Summary generation - 4biii
                strBriefSummaryPromptClause4biii =f"""
                Your task is to evaluate the waiver text enclosed on triple backticks to check if the text contains language
                validating that the participant is assuming all risks willfully and voluntarily
                - If the language is present then it means "Passed validation".
                - If the language is not present then it means "Needs review".
                Output format:
                Needs review - along with your conclusion
                or
                Passed validation - along with your conclusion

                Provide the conclusion in a single statement and it should be grammatically correct.
                Use the phrase "waiver file" while referring to the text in your conclusion.

                waiver text: '''{strDetailedSummaryOutputClause4biii}'''
                """
                strBriefSummaryOutputClause4biii = getGPTResponse(strBriefSummaryPromptClause4biii, objOpenAIClient, dictConfig)
                strValidationOutputClause4biii, strBriefSummaryOutputClause4biiiSplit= getValidationOutputAndBriefSummary(strBriefSummaryOutputClause4biii)
                
                strRequirementDescriptionClause4biii = dictInfoClause4biii['strReqDescription']
                strNewRequirementDescriptionClause4biii = generateBriefSummaryWithRequirement(strRequirementDescriptionClause4biii, objOpenAIClient, dictConfig)
                strBriefSummaryOutputClause4biiiSplit = strNewRequirementDescriptionClause4biii +' '+ strBriefSummaryOutputClause4biiiSplit
                
                dictResponseClause4biii ={**dictInfoClause4biii, "strValidationOutput":strValidationOutputClause4biii, 
                            "strBriefSummary":strBriefSummaryOutputClause4biiiSplit, 
                            "strDetailedSummary":strDetailedSummaryOutputClause4biii,
                            "strActualQuote":strActualQuoteFormattedOutputClause4biii
                            }

            except Exception as e:
                # Check if any error occurs during brief summary generation
                boolExceptionClause4biii = True
                strErrorMessage4biii = f"RunID_{str(self.intRunID)} - AML Endpoint - ERROR - Brief summary generation for Requirement 6 has failed due to following error - "+str(e)
                dictResponseClause4biii = {**dictInfoClause4biii, 
                "strValidationOutput":"Needs Review",
                "strBriefSummary":"Error at response generation for brief summary ",
                "strDetailedSummary":strDetailedSummaryOutputClause4biii,
                "strActualQuote":strActualQuoteFormattedOutputClause4biii
                }

        return ([dictResponseClause4bi,dictResponseClause4bii,dictResponseClause4biii], [strErrorMessage4bi, strErrorMessage4bii, strErrorMessage4biii])

    def validateClause4c(self, dictClauseInfo:dict, intkValue:int, objSearchClient:SearchClient, objOpenAIClient:AzureOpenAI, dictConfig:dict):
        """
            This function is defined to validate the clause 4c (i) and(ii) for Camp Operator

            Parameters:
            - dictClauseInfo (dict): Holds details of the clauses like category, description, requirement number
            - intkValue (int): Number of chunks to retrieve
            - objSearchClient: Azure AI search client object
            - objOpenAIClient: Azure OpenAI client
            - dictConfig (dict): configuration details

            return:
            a tuple which contains the following two lists
            - first list
                - dictResponseClause4ci (dict): dictionary of clause name, actual quote, detailed summary, brief summary for clause 4ci
                - dictResponseClause4cii (dict): dictionary of clause name, actual quote, detailed summary, brief summary for clause 4cii
            - second list
                - strErrorMessage4ci (str): error message if any occurs
                - strErrorMessage4cii (str): error message if any occurs
        """
        # Get the metadata information of sub clauses of clause 4c
        dictInfoClause4ci=dictClauseInfo["clause_4c1"]
        dictInfoClause4cii=dictClauseInfo["clause_4c2"]

        # Error flag for sub clauses of clause 4c
        # Created so that if at any step one of the subclause fails it should not hamper the other subclause.
        boolErrorClause4ci = False
        boolErrorClause4cii = False

        # Initialize the error message for sub clauses. If at any step the processing fails this variable will hold the error information.
        # Done as in multithreaded fashion we can't log error on fly during execution. This variable holds the error and returns after thread run completes.
        strErrorMessage4ci = ''
        strErrorMessage4cii = ''

        intRetries=self.intNumberOfRetries
        for attempt in range(intRetries):
            try:
                # Retrieve the relevant chunks from the file corresponding to the clause 4c 
                strRetrievalQueryClause4c="Identify text in the waiver form that clearly waives liability for future claims arising from the activity and confirm that the participant knowingly agreed to the release."
                strRetrievedDataClause4c = self.objRetrieve.getAISearchRetrievedChunk(self.intRunID, strRetrievalQueryClause4c, intkValue, objSearchClient, objOpenAIClient, dictConfig)
            except Exception as e:
                # Check if any error occurs during retrieval process
                if 'DefaultAzureCredential failed to retrieve a token from the included credentials' in str(e) and attempt < (intRetries-1):
                    time.sleep(3)
                else:
                    strErrorMessage4ci = f"RunID_{str(self.intRunID)} - AML Endpoint - ERROR - Data retrival query for Requirement 7 has failed due to following error - "+str(e)
                    strErrorMessage4cii = f"RunID_{str(self.intRunID)} - AML Endpoint - ERROR - Data retrival query for Requirement 8 has failed due to following error - "+str(e)
                    dictResponseClause4ci = {**dictInfoClause4ci, "strValidationOutput":"Needs Review",
                    "strBriefSummary":"No response generated due to error at data retrieval",
                    "strDetailedSummary":"No response generated due to error at data retrieval",
                    "strActualQuote":"No response generated due to error at data retrieval "}
                    dictResponseClause4cii = {**dictInfoClause4cii, "strValidationOutput":"Needs Review",
                    "strBriefSummary":"No response generated due to error at data retrieval",
                    "strDetailedSummary":"No response generated due to error at data retrieval",
                    "strActualQuote":"No response generated due to error at data retrieval "}
                    return ([dictResponseClause4ci, dictResponseClause4cii], [strErrorMessage4ci, strErrorMessage4cii])

        try:
            #Actual Quote generation for clause 4c (i)
            strActualQuotePromptClause4ci = f""" 

            Use the waiver text enclosed in triple back ticks to identify sentences that waives liability for
            future claims or liabilities ,claims, injury, loss, damages, lawsuit arising from the agreement.
            - If present , then extract complete sentences as it is without generating text on your own.
            The extracted sentences must be as pointers.
            - If not present , then respond saying that
            "No relevant language found."
            waiver text:'''{strRetrievedDataClause4c}'''
            """

            strActualQuoteOutputClause4ci = getGPTResponse(strActualQuotePromptClause4ci, objOpenAIClient, dictConfig)
            # Formatting of the generated actual quote
            if strActualQuoteOutputClause4ci != 'No relevant language found.':
                strActualQuoteFormattedOutputClause4ci = actualQuoteFormatting(strActualQuoteOutputClause4ci, objOpenAIClient, dictConfig)
            else:
                strActualQuoteFormattedOutputClause4ci = strActualQuoteOutputClause4ci
        except Exception as e:
            # Check if any error occurs during actual quote generation
            boolErrorClause4ci = True
            strErrorMessage4ci = f"RunID_{str(self.intRunID)} - AML Endpoint - ERROR - Actual quote generation for Requirement 7 has failed due to following error - "+str(e)
            dictResponseClause4ci = {**dictInfoClause4ci, 
            "strValidationOutput":"Needs Review",
            "strBriefSummary":"No response generated due to error at actual quote generation",
            "strDetailedSummary":"No response generated due to error at actual quote generation",
            "strActualQuote":"Error at response generation for actual quote "}
        
        try:
            #Actual Quote generation for clause 4c (ii)
            strActualQuotePromptClause4cii = f"""    
            Use the waiver text enclosed in triple back ticks to identify sentences that mention about
            participant knowingly agree to release the service provider from any liabilities for future claims or
            injury, loss, damages, lawsuit arising from the agreement.
            - If present , then extract complete sentences as it is without generating text on your own.
            The extracted sentences must be as pointers.
            - If not present , then respond saying that
            "No relevant language found."
            waiver text: '''{strRetrievedDataClause4c}'''
            """

            strActualQuoteOutputClause4cii = getGPTResponse(strActualQuotePromptClause4cii, objOpenAIClient, dictConfig)
            # Formatting the generated actual quote
            if strActualQuoteOutputClause4cii != 'No relevant language found.':
                strActualQuoteFormattedOutputClause4cii = actualQuoteFormatting(strActualQuoteOutputClause4cii, objOpenAIClient, dictConfig)
            else:
                strActualQuoteFormattedOutputClause4cii = strActualQuoteOutputClause4cii
        except Exception as e:
            # Check if any error occurs during actual quote generation
            boolErrorClause4cii = True
            strErrorMessage4cii = f"RunID_{str(self.intRunID)} - AML Endpoint - ERROR - Actual quote generation for Requirement 8 has failed due to following error - "+str(e)
            dictResponseClause4cii = {**dictInfoClause4cii, 
            "strValidationOutput":"Needs Review",
            "strBriefSummary":"No response generated due to error at actual quote generation",
            "strDetailedSummary":"No response generated due to error at actual quote generation",
            "strActualQuote":"Error at response generation for actual quote "}

        # If all the sub clauses generate error return the results and error
        if boolErrorClause4ci and boolErrorClause4cii:
            return ([dictResponseClause4ci, dictResponseClause4cii], [strErrorMessage4ci, strErrorMessage4cii])

        # Initialize detailed summary for sub clauses of 4c 
        strDetailedSummaryOutputClause4ci = ""
        strDetailedSummaryOutputClause4cii = ""

        # Datailed summary generation
        listActualQuoteCheck =['"No relevant language found."','No relevant language found.']
        if not boolErrorClause4ci:
            if np.any([strActualQuoteOutputClause4ci in i for i in listActualQuoteCheck]):
                strDetailedSummaryOutputClause4ci = "The waiver file does not contain any pre-injury language to check that the release inconspicuously and unambiguously waives liabilities for future claims arising from the activities "
        if not boolErrorClause4cii:    
            if np.any([strActualQuoteOutputClause4cii in i for i in listActualQuoteCheck]):    
                strDetailedSummaryOutputClause4cii = "The waiver file does not contain language to validate the participant knowingly agreed to the release."
        
        if not strDetailedSummaryOutputClause4ci and not boolErrorClause4ci:
                try:
                    #Detailed Summary generation for clause 4c (i)
                    strDetailedSummaryPromptClause4ci = f"""Your task is to find out the answer from the waiver text given in triple backticks ```{strActualQuoteFormattedOutputClause4ci}```.

                    Proceed based on the findings:
                    If the extracted sentence does not cointains sentences related to refunds, withdrawals, financial transactions, lost personal belongings or similar terms. Then move on to questions below to answer, else notify only that 'The waiver file does not contain pre-injury language that waives liability for any future claims made against the service provider.'.

                    Questions to Answer (If Waiver Clause is Found):
                    Check if the sentences releases the service provider against any and all liabilities for future claims arising from the agreement or activities performed in the camp.
                    The output generated must be grammatically correct and use the phrase "waiver file" while referring to the text. Ensure that the output is crip without any repetition.
                    - If there is mention of all liabilities then,
                    Begin the response with the statement "The waiver file contains pre-injury language that waives service provider from all liabilities".
                    - If there is mention of specific liabilities, 
                    then begin the sentence with the below phrase and then include the specific liabilities in the sentence.
                    """
                    strDetailedSummaryOutputClause4ci = getGPTResponse(strDetailedSummaryPromptClause4ci, objOpenAIClient, dictConfig)
                except Exception as e:
                    # Check if any error occurs during detailed summary generation
                    boolErrorClause4ci = True
                    strErrorMessage4ci = f"RunID_{str(self.intRunID)} - AML Endpoint - ERROR - Detailed summary generation for Requirement 7 has failed due to following error - "+str(e)
                    dictResponseClause4ci = {**dictInfoClause4ci, 
                    "strValidationOutput":"Needs Review",
                    "strBriefSummary":"No response generated due to error at detailed summary generation",
                    "strDetailedSummary":"Error at response generation for detailed summary ",
                    "strActualQuote":strActualQuoteFormattedOutputClause4ci}

        if not strDetailedSummaryOutputClause4cii and not boolErrorClause4cii:  
                try:
                    #Detailed Summary generation for clause 4c (ii)
                    strDetailedSummaryPromptClause4cii = f"""

                    Use the waiver text enclosed in triple backticks to check for acknowledgement where the participant has
                    knowingly agreed to all the clauses in the waiver text.
                    The output generated must be grammatically correct and use the phrase "waiver file" while
                    referring to the text. Begin the response with the statement 
                    "The waiver file mentions that the participant knowingly agreed to the release" 
                    Ensure that the output is crip without any repetition.

                    waiver text:'''{strActualQuoteFormattedOutputClause4cii}'''
                    """
                    strDetailedSummaryOutputClause4cii = getGPTResponse(strDetailedSummaryPromptClause4cii, objOpenAIClient, dictConfig)
                except Exception as e:
                    # Check if any error occurs during detailed summary generation
                    boolErrorClause4cii = True
                    strErrorMessage4cii = f"RunID_{str(self.intRunID)} - AML Endpoint - ERROR - Detailed summary generation for Requirement 8 has failed due to following error - "+str(e)
                    dictResponseClause4cii = {**dictInfoClause4cii, 
                    "strValidationOutput":"Needs Review",
                    "strBriefSummary":"No response generated due to error at detailed summary generation",
                    "strDetailedSummary":"Error at response generation for detailed summary ",
                    "strActualQuote":strActualQuoteFormattedOutputClause4cii}

        if not boolErrorClause4ci:   
            try:
                #Brief Summary generation for clause 4c (i)
                strBriefSummaryPromptClause4ci = f"""
                Your task is to evaluate the waiver text enclosed in triple backticks,
                based on the following conditions and respond if the waiver file contains pre-injury language that waives
                liability for any future claims made against the service provider.
                Use the below conditions to determine:
                - If the waiver text contains the pre-injury language then it is "Passed validation".
                - If the waiver text does not contain pre-injury language then it is "Needs review".
                Output format:
                Needs review - along with your reasoning
                or
                Passed validation - along with your reasoning

                Provide the reasoning in a single statement beginning with the phrase "The waiver file".
                Ensure the reasoning is grammatically correct

                waiver text: '''{strDetailedSummaryOutputClause4ci}'''
                """
                strBriefSummaryOutputClause4ci = getGPTResponse(strBriefSummaryPromptClause4ci, objOpenAIClient, dictConfig)
                strValidationOutputClause4ci, strBriefSummaryOutputClause4ciSplit= getValidationOutputAndBriefSummary(strBriefSummaryOutputClause4ci)
                
                strRequirementDescriptionClause4ci = dictInfoClause4ci['strReqDescription']
                strNewRequirementDescriptionClause4ci = generateBriefSummaryWithRequirement(strRequirementDescriptionClause4ci, objOpenAIClient, dictConfig)
                strBriefSummaryOutputClause4ciSplit = strNewRequirementDescriptionClause4ci +' '+ strBriefSummaryOutputClause4ciSplit

                dictResponseClause4ci ={**dictInfoClause4ci, "strValidationOutput":strValidationOutputClause4ci, 
                "strBriefSummary":strBriefSummaryOutputClause4ciSplit, 
                "strDetailedSummary":strDetailedSummaryOutputClause4ci,
                "strActualQuote":strActualQuoteFormattedOutputClause4ci
                }

            except Exception as e:
                # Check if any error occurs during brief summary generation
                boolErrorClause4ci = True
                strErrorMessage4ci = f"RunID_{str(self.intRunID)} - AML Endpoint - ERROR - Brief summary generation for Requirement 7 has failed due to following error - "+str(e)
                dictResponseClause4ci = {**dictInfoClause4ci, 
                "strValidationOutput":"Needs Review",
                "strBriefSummary":"Error at response generation for brief summary ",
                "strDetailedSummary":strDetailedSummaryOutputClause4ci,
                "strActualQuote":strActualQuoteFormattedOutputClause4ci
                }


        if not boolErrorClause4cii:
            try:
                #Brief Summary generation for clause 4c (ii)
                strBriefSummaryPromptClause4cii = f"""
                Your task is to evaluate the waiver text enclosed in triple backticks to check if the waiver file contains
                language validating the participant knowingly agreed to the release.
                - If the waiver text contains the language then it is  "Passed validation".
                - If the waiver text does not contain the language then it is "Needs review".
                Output format:
                Needs review - along with your reasoning
                or
                Passed validation - along with your reasoning
                Provide the reasoning in a single statement beginning with the phrase "The waiver file".
                Ensure the reasoning is grammatically correct

                waiver text:'''{strDetailedSummaryOutputClause4cii}'''
                """
                strBriefSummaryOutputClause4cii = getGPTResponse(strBriefSummaryPromptClause4cii, objOpenAIClient, dictConfig)
                strValidationOutputClause4cii, strBriefSummaryOutputClause4ciiSplit= getValidationOutputAndBriefSummary(strBriefSummaryOutputClause4cii)

                strRequirementDescriptionClause4cii = dictInfoClause4cii['strReqDescription']
                strNewRequirementDescriptionClause4cii = generateBriefSummaryWithRequirement(strRequirementDescriptionClause4cii, objOpenAIClient, dictConfig)
                strBriefSummaryOutputClause4ciiSplit = strNewRequirementDescriptionClause4cii +' '+ strBriefSummaryOutputClause4ciiSplit

                dictResponseClause4cii ={**dictInfoClause4cii, "strValidationOutput":strValidationOutputClause4cii, 
                "strBriefSummary":strBriefSummaryOutputClause4ciiSplit, 
                "strDetailedSummary":strDetailedSummaryOutputClause4cii,
                "strActualQuote":strActualQuoteFormattedOutputClause4cii
                }
            except Exception as e:
                # Check if any error occurs during brief summary generation
                boolErrorClause4cii = True
                strErrorMessage4cii = f"RunID_{str(self.intRunID)} - AML Endpoint - ERROR - Brief summary generation for Requirement 8 has failed due to following error - "+str(e)
                dictResponseClause4cii = {**dictInfoClause4cii, 
                "strValidationOutput":"Needs Review",
                "strBriefSummary":"Error at response generation for brief summary ",
                "strDetailedSummary":strDetailedSummaryOutputClause4cii,
                "strActualQuote":strActualQuoteFormattedOutputClause4cii
                }

        return ([dictResponseClause4ci, dictResponseClause4cii], [strErrorMessage4ci, strErrorMessage4cii])
        
    def validateClause4d(self, dictClauseInfo:dict, intkValue:int, objSearchClient:SearchClient, objOpenAIClient:AzureOpenAI, dictConfig:dict):
        """
            This function is defined to validate the clause 4d for Camp Operator

            Parameters:
            - dictClauseInfo (dict): Holds details of the clauses like category, description, requirement number
            - intkValue (int): Number of chunks to retrieve
            - objSearchClient: Azure AI search client object
            - objOpenAIClient: Azure OpenAI client
            - dictConfig (dict): configuration details

            return:
            a tuple which contains the following variables
            - dictResponseClause4d (dict): dictionary of clause name, actual quote, detailed summary, brief summary for clause 4d
            - strErrorMessage (str): error message if any occurs
        """
        # Get the metadata information of clause 4d
        dictInfoClause4d=dictClauseInfo["clause_4d"]
        # Initialize the error message for clause. If at any step the processing fails this variable will hold the error information.
        # Done as in multithreaded fashion we can't log error on fly during execution. This variable holds the error and returns after thread run completes.
        strErrorMessage = ''
        intRetries=self.intNumberOfRetries
        for attempt in range(intRetries):
            try:
                # Retrieve the relevant chunks from the file corresponding to the clause 4d
                strRetrievalQueryClause4d="Find text in the waiver form that clearly states the provider's protection against any losses, liabilities, and claims arising out."
                strRetrievedDataClause4d = self.objRetrieve.getAISearchRetrievedChunk(self.intRunID, strRetrievalQueryClause4d, intkValue, objSearchClient, objOpenAIClient, dictConfig)
            except Exception as e:
                # Check if any error occurs during retrieval process
                if 'DefaultAzureCredential failed to retrieve a token from the included credentials' in str(e) and attempt < (intRetries-1):
                    time.sleep(3)
                else:
                    strErrorMessage = f"RunID_{str(self.intRunID)} - AML Endpoint - ERROR - Data retrieval query for Requirement 9 has failed due to following error - "+str(e)
                    dictResponseClause4d = {**dictInfoClause4d, "strValidationOutput":"Needs Review",
                    "strBriefSummary":"No response generated due to error at data retrieval",
                    "strDetailedSummary":"No response generated due to error at data retrieval",
                    "strActualQuote":"No response generated due to error at data retrieval "}
                    return (dictResponseClause4d, strErrorMessage)

        try:
            #Actual Quote generation for clause 4d
            strActualQuotePromptClause4d = f"""
Use the waiver text enclosed in triple back ticks to identify sentences which have keywords like "indemnify", "indemnity", "indemnification", "harmless" present.
- If present , then extract complete sentences as it is without generating text on your own.
The extracted sentences must be as pointers.
- If not present , then respond saying that
No relevant language found.
waiver text: '''{strRetrievedDataClause4d}'''
"""

            strActualQuoteOutputClause4d = getGPTResponse(strActualQuotePromptClause4d, objOpenAIClient, dictConfig)
            #Formatting of the generated actual quote
            if strActualQuoteOutputClause4d != "No relevant language found.":
                strActualQuoteFormattedOutputClause4d = actualQuoteFormatting(strActualQuoteOutputClause4d, objOpenAIClient, dictConfig)
            else:
                strActualQuoteFormattedOutputClause4d = strActualQuoteOutputClause4d
        except Exception as e:
            # Check if any error occurs actual quote generation
            strErrorMessage = f"RunID_{str(self.intRunID)} - AML Endpoint - ERROR - Actual quote generation for Requirement 9 has failed due to following error - "+str(e)
            dictResponseClause4d = {**dictInfoClause4d, 
            "strValidationOutput":"Needs Review",
            "strBriefSummary":"No response generated due to error at actual quote generation",
            "strDetailedSummary":"No response generated due to error at actual quote generation",
            "strActualQuote":"Error at response generation for actual quote "}
            return (dictResponseClause4d, strErrorMessage)

        try:
            if strActualQuoteFormattedOutputClause4d != "No relevant language found.":
                #Detailed Summary generation for clause 4d
                strDetailedSummaryPromptClause4d = f"""Use the waiver text enclosed in triple backticks to generate summary for each sentence focusing on keywords like "indemnify", "indemnity", "indemnification", "harmless".
Begin the summary with the statement "The waiver file contains language".

The whole summary generated must be between 50 to 100 words,grammatically correct and use the phrase "waiver file" while
referring to the text. No need to mark the sentence, the output should be one text with same number of sentence.

waiver text: '''{strActualQuoteFormattedOutputClause4d}'''

"""
                strDetailedSummaryOutputClause4d = getGPTResponse(strDetailedSummaryPromptClause4d, objOpenAIClient, dictConfig)
            else:
                strDetailedSummaryOutputClause4d = """The waiver file does not contain language clearly stating that the participant agrees to indemnify and hold harmless the provider, against any losses, liabilities and claims arising out of this transaction."""
        except Exception as e:
            # Check if any error occurs detailed summary generation
            strErrorMessage = f"RunID_{str(self.intRunID)} - AML Endpoint - ERROR - Detailed summary generation for Requirement 9 has failed due to following error - "+str(e)
            dictResponseClause4d = {**dictInfoClause4d, 
            "strValidationOutput":"Needs Review",
            "strBriefSummary":"No response generated due to error at detailed summary generation",
            "strDetailedSummary":"Error at response generation for detailed summary ",
            "strActualQuote":strActualQuoteFormattedOutputClause4d}
            return (dictResponseClause4d, strErrorMessage)


        try:
            if strActualQuoteFormattedOutputClause4d != "No relevant language found.":
                #Brief Summary generation for clause 4d
                # Split the actual quote into sentences
                listSentencesActualQuote = re.split(r'(?<!\w\.\w.)(?<![A-Z][a-z]\.)(?<=\.|\?)\s', strActualQuoteFormattedOutputClause4d)

                # Define the terms
                listIndemnityTerms = {'indemnity', 'indemnify', 'indemnification'}
                listHarmlessTerm = 'harmless'
                listClaimSuitTerms = {'claim', 'suit'}

                # Function to check if a sentence contains all terms
                def contains_all_terms(sentence):
                    terms_present = any(term in sentence for term in listIndemnityTerms) and \
                                    listHarmlessTerm in sentence and \
                                    any(term in sentence for term in listClaimSuitTerms)
                    return terms_present

                listPassedValidationSentences=[]
                # Check each sentence
                for sentence in listSentencesActualQuote:
                    if contains_all_terms(sentence):
                        listPassedValidationSentences.append(sentence)
                if len(listPassedValidationSentences)>0:
                    strBriefSummaryOutputClause4d='Passed Validation - The waiver file contains language clearly stating that the participant agreed to indemnify and hold harmless the provider against all claims or suits.'
                else:
                    strBriefSummaryOutputClause4d='Needs Review - The waiver file contains some indemnify and hold harmless language but it is not clearly stated that the participant agreed to indemnify and hold harmless the provider against all claims or suits with terms “indemnify”, “hold harmless” and “claims” or “suits” clearly present in the same sentence.'
                    
            else:
                strBriefSummaryOutputClause4d = """Needs Review - The waiver file does not contain any indemnify or hold harmless language."""
            
            strValidationOutputClause4d, strBriefSummaryOutputClause4dSplit= getValidationOutputAndBriefSummary(strBriefSummaryOutputClause4d)
            
            dictResponseClause4d ={**dictInfoClause4d, "strValidationOutput":strValidationOutputClause4d, 
            "strBriefSummary":strBriefSummaryOutputClause4dSplit, 
            "strDetailedSummary":strDetailedSummaryOutputClause4d,
            "strActualQuote":strActualQuoteFormattedOutputClause4d
            }
            return (dictResponseClause4d, strErrorMessage)
        except Exception as e:
            # Check if any error occurs brief summary generation
            strErrorMessage = f"RunID_{str(self.intRunID)} - AML Endpoint - ERROR - Brief summary generation for Requirement 9 has failed due to following error - "+str(e)
            dictResponseClause4d = {**dictInfoClause4d, 
            "strValidationOutput":"Needs Review",
            "strBriefSummary":"Error at response generation for brief summary ",
            "strDetailedSummary":strDetailedSummaryOutputClause4d,
            "strActualQuote":strActualQuoteFormattedOutputClause4d
            }
            return (dictResponseClause4d, strErrorMessage)

    def validateClause4g(self, dictClauseInfo:dict,  dictConfig:dict):
        '''
        This function is defined to validate the clause 4g for Camp Operator

        Parameters:
        - dictClauseInfo (dict): Holds details of the clauses like category, description, requirement number
        - dictConfig (dict): configuration details

        return:
        a tuple which contains the following variables
        - dictResponseClause4g(dict) : dictionary of clause name, actual quote, detailed summary, brief summary for clause 4g
        - strErrorMessage (str): error message if any occurs
        '''
        # Initialize the error message for clause. If at any step the processing fails this variable will hold the error information.
        # Done as in multithreaded fashion we can't log error on fly during execution. This variable holds the error and returns after thread run completes.
        strErrorMessage = ''
        strWaiverFile= self.strWaiverFileName
        strTextWaiverFile=strWaiverFile.rsplit('.',1)[-2]
        #download the txt file from blob storage
        try:
            strTextSourceContainerName=dictConfig['EXTRACT_FILE_CONTAINER']
            objGetBlobClient = getBlobServiceClientTokenCredential(dictConfig)
            if isinstance(objGetBlobClient, Exception):
                # Check for any error during comnnecting with blob resource
                strErrorMessage = f"RunID_{str(self.intRunID)} - AML Endpoint - ERROR - Requirement 10 Failed to establish connection with blob service client due to following error - "+str(objGetBlobClient)
                raise Exception(strErrorMessage) 
            else:
                try:
                    # Download the blob to a stream
                    objBlobClient = objGetBlobClient.get_blob_client(strTextSourceContainerName, strTextWaiverFile+'.txt')
                    strWaiverTextData = objBlobClient.download_blob().readall().decode('UTF-8')
                except Exception as e:
                    strErrorMessage = f"RunID_{str(self.intRunID)} - AML Endpoint - ERROR - Requirement 10 Failed to read the input file from blob due to following error - "+str(e)
                    raise Exception(strErrorMessage)
        except Exception as e:
            # Check for any error
            strErrorMessage = str(e)
            dictResponseClause4g ={**dictInfoClause4g, "strValidationOutput":"Needs Review", 
            "strBriefSummary":"No response generated due to error at data retrieval",
            "strDetailedSummary":"No response generated due to error at data retrieval",
            "strActualQuote":"No response generated due to error at data retrieval "}
            return (dictResponseClause4g, strErrorMessage)
        # Get the metadata information of clause 4g
        dictInfoClause4g=dictClauseInfo["clause_4g"]
        # Detailed Summary Generation
        strDetailedSummaryOutputClause4g=clause4gDetailedOutputGeneration(strWaiverFile, strWaiverTextData, dictConfig)
        # Actual quote and Brief summary generation
        strstrWaiverDataUpper =strWaiverTextData.upper()
        strStartingSubstring = "READ THIS FORM COMPLETELY AND CAREFULLY".upper()
        strEndingSubstring = "THE RIGHT TO REFUSE TO LET YOUR CHILD PARTICIPATE IF YOU DO NOT SIGN THIS FORM.".upper()
        if strDetailedSummaryOutputClause4g=="This waiver file is part of the State of Florida, and contains the required statement specific to minor child as per the law of the State of Florida. The statement is in uppercase and is 5 points larger than the rest of the text in the document.":
            result=extractTextBetweenSubstrings(strstrWaiverDataUpper, strStartingSubstring, strEndingSubstring)
            strActualQuoteOutputClause4g='"'+strStartingSubstring+result[0]+strEndingSubstring+'"'
        elif strDetailedSummaryOutputClause4g=="This waiver file is not part of the state of Florida. Hence, this requirements is not applicable.":
            strActualQuoteOutputClause4g="Not Applicable."
        else:
            result=extractTextBetweenSubstrings(strstrWaiverDataUpper, strStartingSubstring, strEndingSubstring)
            if result:
                strActualQuoteOutputClause4g='"'+strStartingSubstring+result[0]+strEndingSubstring+'"'
            else:
                strActualQuoteOutputClause4g="Not Applicable."


        if strDetailedSummaryOutputClause4g=="This waiver file is part of the State of Florida, and contains the required statement specific to minor child as per the law of the State of Florida. The statement is in uppercase and is 5 points larger than the rest of the text in the document.":
            strBriefSummaryOutputClause4g='The waiver file is part of the State of Florida and contains the required statement specific to minor child in the correct format.'
            strValidationOutput4g='Passed Validation'
        elif  strDetailedSummaryOutputClause4g=="This waiver file is not part of the state of Florida. Hence, this requirements is not applicable.":
            strBriefSummaryOutputClause4g='The requirement is not applicable since the waiver file is not part of the state of Florida.'
            strValidationOutput4g='Passed Validation'
        else:
            strBriefSummaryOutputClause4g='The waiver file is part of the State of Florida and the statement specific to minor child is not satisfied. Therefore, the requirement needs further attention from the underwriter.'
            strValidationOutput4g='Needs Review'

        dictResponseClause4g ={**dictInfoClause4g, "strValidationOutput":strValidationOutput4g, 
            "strBriefSummary":strBriefSummaryOutputClause4g, 
            "strDetailedSummary":strDetailedSummaryOutputClause4g,
            "strActualQuote":strActualQuoteOutputClause4g
            }

        return (dictResponseClause4g, strErrorMessage)

    def validateClause4h(self, dictClauseInfo:dict, intkValue:int, objSearchClient:SearchClient, objOpenAIClient:AzureOpenAI, dictConfig:dict):
        """
            This function is defined to validate the clause 4h for Camp Operator

            Parameters:
            - dictClauseInfo (dict): Holds details of the clauses like category, description, requirement number
            - intkValue (int): Number of chunks to retrieve
            - objSearchClient: Azure AI search client object
            - objOpenAIClient: Azure OpenAI client
            - dictConfig (dict): configuration details

            return:
            a tuple which contains the following variables
            - dictResponseClause4h (dict): dictionary of clause name, actual quote, detailed summary, brief summary for clause 4h
            - strErrorMessage (str): error message if any occurs
        """
         # Get the metadata information of clause 4h
        dictInfoClause4h=dictClauseInfo["clause_4h"]
        # Initialize the error message for clause. If at any step the processing fails this variable will hold the error information.
        # Done as in multithreaded fashion we can't log error on fly during execution. This variable holds the error and returns after thread run completes.
        strErrorMessage = ''
        intRetries=self.intNumberOfRetries
        for attempt in range(intRetries):
            try:
                # Retrieve the relevant chunks from the file corresponding to the clause 4h 
                strRetrievalQueryClause4h="Extract those statements where signature section is present in the waiver and the date on which the form was signed."

                strRetrievedDataClause4h = self.objRetrieve.getAISearchRetrievedChunk(self.intRunID, strRetrievalQueryClause4h, intkValue, objSearchClient, objOpenAIClient, dictConfig)
            except Exception as e:
                # Check if any error occurs during retrieval process
                if 'DefaultAzureCredential failed to retrieve a token from the included credentials' in str(e) and attempt < (intRetries-1):
                    time.sleep(3)
                else:
                    strErrorMessage = f"RunID_{str(self.intRunID)} - AML Endpoint - ERROR - Data retrieval query for Requirement 11 has failed due to following error - "+str(e)
                    dictResponseClause4h = {**dictInfoClause4h, "strValidationOutput":"Needs Review",
                    "strBriefSummary":"No response generated due to error at data retrieval",
                    "strDetailedSummary":"No response generated due to error at data retrieval",
                    "strActualQuote":"No response generated due to error at data retrieval "}
                    return (dictResponseClause4h, strErrorMessage)

        try:
            #Actual Quote generation for clause 4h
            strActualQuotePromptClause4h = f"""You are a waiver form reviewer expert. Your task is to find out the answer from the waiver text given in triple backticks ```{strRetrievedDataClause4h}```.

            Proceed based on the findings:
            If the extracted phrase containing only Signature and Date, move on to answer the questions below else notify only that 'No relevant language found'.

            Questions to Answer (If Waiver Clause is Found):
            Identify the phrases where their is a mention of exact word signatures and the signatures dates.

            Instructions:
            - Extract only the phrase not entire sentences. All the extracted phrases must be in python list format.
            - Do not generate any text or add any date information on your own. If date is not present simply keep it blank. Do not create any blank point.
            - No explanation, headers and system prompt required.
            """
            strActualQuoteOutputClause4h = getGPTResponse(strActualQuotePromptClause4h, objOpenAIClient, dictConfig)
            # Formatting of the generated actual quote
            strActualQuotePromptFormatting4h = f"""Your task is to reformat the text {strActualQuoteOutputClause4h}. First enclose the phrases in quotation marks 
            and return them with numeric pointers if there are multiple phrases. If there is only one phrase, it will not be numbered.

            Sample output:
            1. "This is sample text1."
            2. "This is sample text2."
            3. "This is sample text3."     
            """

            if strActualQuoteOutputClause4h != 'No relevant language found.':
                strActualQuoteFormattedOutputClause4h = getGPTResponse(strActualQuotePromptFormatting4h, objOpenAIClient, dictConfig)
            else:
                strActualQuoteFormattedOutputClause4h = strActualQuoteOutputClause4h
        except Exception as e:
            # Check if any error occurs during actual quote generation
            strErrorMessage = f"RunID_{str(self.intRunID)} - AML Endpoint - ERROR - Actual quote generation for Requirement 11 has failed due to following error - "+str(e)
            dictResponseClause4h = {**dictInfoClause4h, 
            "strValidationOutput":"Needs Review",
            "strBriefSummary":"No response generated due to error at actual quote generation",
            "strDetailedSummary":"No response generated due to error at actual quote generation",
            "strActualQuote":"Error at response generation for actual quote "}
            return (dictResponseClause4h, strErrorMessage)
        try:
            listActualQuoteCheck =["No relevant language found."]
            if np.any([strActualQuoteFormattedOutputClause4h in i for i in listActualQuoteCheck]):
                strDetailedSummaryOutputClause4h = "The waiver file is not requesting any signatures and Date."
            else:
                #Detailed Summary generation for clause 4h
                strDetailedSummaryPromptClause4h = f"""Use the waiver text enclosed in triple backticks to check the waiver text is requesting the signature and date of signature.
                
                Output should be in one line of conclusion mentioning if it contains signature and date.
                
                The output generated must be grammatically correct and use the phrase "waiver file" while
                referring to the text. Begin the response with the statement "The waiver file requests the signature of the" 
                
            

                waiver text: '''{strActualQuoteFormattedOutputClause4h}'''
                """
            
                strDetailedSummaryOutputClause4h = getGPTResponse(strDetailedSummaryPromptClause4h, objOpenAIClient, dictConfig)
        except Exception as e:
            # Check if any error occurs during detailed summary generation
            strErrorMessage = f"RunID_{str(self.intRunID)} - AML Endpoint - ERROR - Detailed summary generation for Requirement 11 has failed due to following error - "+str(e)
            dictResponseClause4h = {**dictInfoClause4h, 
            "strValidationOutput":"Needs Review",
            "strBriefSummary":"No response generated due to error at detailed summary generation",
            "strDetailedSummary":"Error at response generation for detailed summary ",
            "strActualQuote":strActualQuoteFormattedOutputClause4h}
            return (dictResponseClause4h, strErrorMessage)


        try:
            #Brief Summary generation for clause 4h
            strBriefSummaryPromptClause4h = f"""
            Your task is to evaluate the waiver text enclosed in triple backticks,
            based on the following conditions and respond.

            Use the below conditions carefully to determine:
            - If the waiver text confirms that it requires Signature and Date
            then it means that the text can be considered "Passed validation".

            -In case of multiple Signatures and Dates in the waiver text, if there is Signature and date even once, 
            then it means that the text can be considered "Passed validation".
 
            - If the waiver text does not mention,
            then the text can be considered for "Needs review".


            Output format:
            Needs review - along with your reasoning
            or
            Passed validation - along with your reasoning

            Provide the reasoning in only single statement beginning with the phrase "The waiver file requires the..".
            Ensure the reasoning is grammatically correct

            waiver text: '''{strDetailedSummaryOutputClause4h}'''
            """
            strBriefSummaryOutputClause4h = getGPTResponse(strBriefSummaryPromptClause4h, objOpenAIClient, dictConfig)
            strValidationOutput, strBriefSummaryOutputClause4hSplit= getValidationOutputAndBriefSummary(strBriefSummaryOutputClause4h)
            
            strRequirementDescriptionClause4h = dictInfoClause4h['strReqDescription']
            strNewRequirementDescriptionClause4h = generateBriefSummaryWithRequirement(strRequirementDescriptionClause4h, objOpenAIClient, dictConfig)
            strBriefSummaryOutputClause4hSplit = strNewRequirementDescriptionClause4h +' '+ strBriefSummaryOutputClause4hSplit
            
            dictResponseClause4h ={**dictInfoClause4h, "strValidationOutput":strValidationOutput, 
                                "strBriefSummary":strBriefSummaryOutputClause4hSplit, 
                                "strDetailedSummary":strDetailedSummaryOutputClause4h,
                                "strActualQuote":strActualQuoteFormattedOutputClause4h
                                }
            return (dictResponseClause4h, strErrorMessage)
        except Exception as e:
            # Check if any error occurs during brief summary generation
            strErrorMessage = f"RunID_{str(self.intRunID)} - AML Endpoint - ERROR - Brief summary generation for Requirement 11 has failed due to following error - "+str(e)
            dictResponseClause4h = {**dictInfoClause4h, 
                                "strValidationOutput":"Needs Review",
                                "strBriefSummary":"Error at response generation for brief summary ",
                                "strDetailedSummary":strDetailedSummaryOutputClause4h,
                                "strActualQuote":strActualQuoteFormattedOutputClause4h
                                }
            return (dictResponseClause4h, strErrorMessage)

    def validateClause4i(self,dictClauseInfo:dict, intkValue:int, objSearchClient:SearchClient, objOpenAIClient:AzureOpenAI, dictConfig:dict):
        """
            This function is defined to validate the clause 4i for Camp Operator

            Parameters:
            - dictClauseInfo (dict): Holds details of the clauses like category, description, requirement number
            - intkValue (int): Number of chunks to retrieve
            - objSearchClient: Azure AI search client object
            - objOpenAIClient: Azure OpenAI client
            - dictConfig (dict): configuration details

            return:
            a tuple which contains the following variables
            - dictResponseClause4i (dict): dictionary of clause name, actual quote, detailed summary, brief summary for clause 4i
            - strErrorMessage (str): error message if any occurs
        """
        # Get the metadata information of clause 4i
        dictInfoClause4i=dictClauseInfo["clause_4i"]
        # Initialize the error message for clause. If at any step the processing fails this variable will hold the error information.
        # Done as in multithreaded fashion we can't log error on fly during execution. This variable holds the error and returns after thread run completes.
        strErrorMessage = ''
        intRetries=self.intNumberOfRetries
        for attempt in range(intRetries):
            try:
                # Retrieve the relevant chunks from the file corresponding to the clause 4i 
                strRetrievalQueryClause4i= "Extract any entire statements that explicitly refer to the recognition of medical care to be delivered by the staff and the provisions or protocols for hospitalization in the event of an emergency and the details regarding waivers and releases as described for medical care and treatment."
                strRetrievedDataClause4i = self.objRetrieve.getAISearchRetrievedChunk(self.intRunID, strRetrievalQueryClause4i, intkValue, objSearchClient, objOpenAIClient, dictConfig)

            except Exception as e:
                # Check if any error occurs during retrieval process
                if 'DefaultAzureCredential failed to retrieve a token from the included credentials' in str(e) and attempt < (intRetries-1):
                    time.sleep(3)
                else:
                    strErrorMessage = f"RunID_{str(self.intRunID)} - AML Endpoint - ERROR - Data retrieval query for Requirement 12 has failed due to following error - "+str(e)
                    dictResponseClause4i = {**dictInfoClause4i, "strValidationOutput":"Needs Review",
                    "strBriefSummary":"No response generated due to error at data retrieval",
                    "strDetailedSummary":"No response generated due to error at data retrieval",
                    "strActualQuote":"No response generated due to error at data retrieval "}
                    return (dictResponseClause4i, strErrorMessage)

        try:
            #Actual Quote generation for 4i
            strActualQuotePromptClause4i = f"""You are a waiver form reviewer expert. Your task is to find out the answer from the waiver text given in triple backticks ```{strRetrievedDataClause4i}```.

            Proceed based on the findings:
            If a waiver clause is found, move on to answer the questions below. If no waiver clause is present, notify only that 'No relevant language found'.

            Questions to Answer (If Waiver Clause is Found):
            Review the waiver text and Identify any entire statements that explicitly refer to the recognition of medical care to be delivered by the staff and the provisions or protocols for hospitalization in the event of an emergency and the details regarding waivers and releases as described for medical care and treatment.
            Focus on the aspects of medical care, medical treatment, hospital's protocol for administering medical care and treatment outlined in the waiver text.

            Instructions (If Waiver Clause is Found):
            1) Need entire statements along with medical care, medical treatment related phrases and all answer formatted in points that should be in numeric order. Be specific with your answer.
            2) Do not generate any text on your own. Extract only the sentences from the given waiver text. No explanation, headers and system prompt required.
            """

            strActualQuoteOutputClause4i = getGPTResponse(strActualQuotePromptClause4i, objOpenAIClient, dictConfig)
            # Formatting of the generated actual quote
            strActualQuoteFormattingPrompt4i = f"""Your task is to reformat the text {strActualQuoteOutputClause4i}.
            Process based on your findings:
            - if text is 'No relevant language found.' return same text without quotation marks.
            - Otherwise first enclose the sentence in quotation marks and then number them. If there is only one sentence, then do not number it.   

            Sample output:
            1. "This is sample text1."
            2. "This is sample text2."
            3. "This is sample text3."
            """
            strActualQuoteFormattedOutputClause4i = getGPTResponse(strActualQuoteFormattingPrompt4i, objOpenAIClient, dictConfig)
        except Exception as e:
            # Check if any error occurs during actual quote generation
            strErrorMessage = f"RunID_{str(self.intRunID)} - AML Endpoint - ERROR - Actual quote generation for Requirement 12 has failed due to following error - "+str(e)
            dictResponseClause4i = {**dictInfoClause4i, 
            "strValidationOutput":"Needs Review",
            "strBriefSummary":"No response generated due to error at actual quote generation",
            "strDetailedSummary":"No response generated due to error at actual quote generation",
            "strActualQuote":"Error at response generation for actual quote "}
            return (dictResponseClause4i, strErrorMessage)
        try:
            #Detailed Summary generation for clause 4i
            strDetailedSummaryPromptClause4i = f"""The answer you need to find out from the waiver form given in triple backticks ```{strActualQuoteFormattedOutputClause4i}```.

            Check and validate whether the waiver clauses clearly states or mentions the permission for medical staff 
            to provide routine and emergency medical care required for Attendees.

            Instructions:
            1)The output must begin with the phrase "The waiver file".
            2)Generated output should be clear and concise if found in the document within 30 words if not found notify "The waiver text does not contain language that mentions the acknowledgement of medical care to be provided by the staff within the camp or hospitalization in the case of an emergency.". 
            3)Be specific to your answer.
            4)Refer to the text as "waiver file" wherever applicable while generating the output.
            5)The output must be grammatically correct.
            """

            strDetailedSummaryOutputClause4i = getGPTResponse(strDetailedSummaryPromptClause4i, objOpenAIClient, dictConfig)
        except Exception as e:
            # Check if any error occurs during detailed summary generation
            strErrorMessage = f"RunID_{str(self.intRunID)} - AML Endpoint - ERROR - Detailed summary generation for Requirement 12 has failed due to following error - "+str(e)
            dictResponseClause4i = {**dictInfoClause4i, 
            "strValidationOutput":"Needs Review",
            "strBriefSummary":"No response generated due to error at detailed summary generation",
            "strDetailedSummary":"Error at response generation for detailed summary ",
            "strActualQuote":strActualQuoteFormattedOutputClause4i}
            return (dictResponseClause4i, strErrorMessage)


        try:
            #Brief Summary generation for clause 4i
            strBriefSummaryPromptClause4i = f"""Your task is to evaluate the waiver text enclosed in triple backticks ```{strDetailedSummaryOutputClause4i}```, based on the following conditions and respond if further attention from the underwriter is required or not.

            Use the below conditions to determine if further attention of underwriter is required:
            - Check and validate whether waiver text states contains the language that mentions the acknowledgement or grants permission for medical care or medical treatment and make decisions in emergency situations for Attendees, then it means no further validation of underwriter is required and therefore the text can be considered "Passed validation".
            - If the text does not confirm, then further validation from underwriter is required and the text can be considered for "Needs review".
            - If Passed validation add reasoning "The waiver file contains the language that mentions the acknowledgement medical care or medical treatment to be provided by the staff in case of emergency."
            - If Needs review add reasoning "The waiver file does not contain the required language to mention the acknowledgement of medical care."

            Output format:
            Needs review - along with your reasoning
            or
            Passed validation - along with your reasoning
            """
            strBriefSummaryOutputClause4i = getGPTResponse(strBriefSummaryPromptClause4i, objOpenAIClient, dictConfig)
            strValidationOutput, strBriefSummaryOutputClause4iSplit= getValidationOutputAndBriefSummary(strBriefSummaryOutputClause4i)
            dictResponseClause4i ={**dictInfoClause4i, "strValidationOutput":strValidationOutput, 
            "strBriefSummary":strBriefSummaryOutputClause4iSplit, 
            "strDetailedSummary":strDetailedSummaryOutputClause4i,
            "strActualQuote":strActualQuoteFormattedOutputClause4i
            }
            return (dictResponseClause4i, strErrorMessage)
        except Exception as e:
            # Check if any error occurs during brief summary generation
            strErrorMessage = f"RunID_{str(self.intRunID)} - AML Endpoint - ERROR - Brief summary generation for Requirement 12 has failed due to following error - "+str(e)
            dictResponseClause4i = {**dictInfoClause4i, 
            "strValidationOutput":"Needs Review",
            "strBriefSummary":"Error at response generation for brief summary ",
            "strDetailedSummary":strDetailedSummaryOutputClause4i,
            "strActualQuote":strActualQuoteFormattedOutputClause4i
            }
            return (dictResponseClause4i, strErrorMessage)

    def validateClause6(self, dictClauseInfo:dict, intkValue:int, objSearchClient:SearchClient, objOpenAIClient:AzureOpenAI, dictConfig:dict):
        """
            This function is defined to validate the clause 6 for Camp Operator

            Parameters:
            - dictClauseInfo (dict): Holds details of the clauses like category, description, requirement number
            - intkValue (int): Number of chunks to retrieve
            - objSearchClient: Azure AI search client object
            - objOpenAIClient: Azure OpenAI client
            - dictConfig (dict): configuration details

            return:
            a tuple which contains the following variables
            - dictResponseClause6 (dict): dictionary of clause name, actual quote, detailed summary, brief summary for clause 6
            - strErrorMessage (str): error message if any occurs
        """
        # Get the metadata information of clause 6
        dictInfoClause6=dictClauseInfo["clause_6"]
        # Initialize the error message for clause. If at any step the processing fails this variable will hold the error information.
        # Done as in multithreaded fashion we can't log error on fly during execution. This variable holds the error and returns after thread run completes.
        strErrorMessage = ''
        intRetries=self.intNumberOfRetries
        for attempt in range(intRetries):
            try:
                # Retrieve the relevant chunks from the file corresponding to the clause 6
                strRetrievalQueryClause6="Internal laws or arbitration of a specific state in relation to liability waivers in case of dispute"

                strRetrievedDataClause6 = self.objRetrieve.getAISearchRetrievedChunk(self.intRunID, strRetrievalQueryClause6, intkValue, objSearchClient, objOpenAIClient, dictConfig)
            except Exception as e:
                # Check if any error occurs during retrieval process
                if 'DefaultAzureCredential failed to retrieve a token from the included credentials' in str(e) and attempt < (intRetries-1):
                    time.sleep(3)
                else:
                    strErrorMessage = f"RunID_{str(self.intRunID)} - AML Endpoint - ERROR - Data retrieval query for Requirement 13 has failed due to following error - "+str(e)
                    dictResponseClause6 = {**dictInfoClause6, "strValidationOutput":"Needs Review",
                    "strBriefSummary":"No response generated due to error at data retrieval",
                    "strDetailedSummary":"No response generated due to error at data retrieval",
                    "strActualQuote":"No response generated due to error at data retrieval "}
                    return (dictResponseClause6, strErrorMessage)

        try:
            #Actual Quote generation for clause 6
            strActualQuotePromptClause6 = f""" Use the waiver text enclosed in triple back ticks to identify all sentences
            that refers to internal laws or arbitration of a specific state in relation to liability waivers.

            - If present , all the extracted sentences must be as pointers.
            
            - If not present , then respond saying that
            "No relevant language found."

            Waiver text: '''{strRetrievedDataClause6}'''

            """

            strActualQuoteOutputClause6 = getGPTResponse(strActualQuotePromptClause6, objOpenAIClient, dictConfig)
            # Formatting of the generated actual quote
            if strActualQuoteOutputClause6 != 'No relevant language found.':
                strActualQuoteFormattedOutputClause6 = actualQuoteFormatting(strActualQuoteOutputClause6, objOpenAIClient, dictConfig)
            else:
                strActualQuoteFormattedOutputClause6 = strActualQuoteOutputClause6
        except Exception as e:
            # Check if any error occurs during actual quote generation
            strErrorMessage = f"RunID_{str(self.intRunID)} - AML Endpoint - ERROR - Actual quote generation for Requirement 13 has failed due to following error - "+str(e)
            dictResponseClause6 = {**dictInfoClause6, 
            "strValidationOutput":"Needs Review",
            "strBriefSummary":"No response generated due to error at actual quote generation",
            "strDetailedSummary":"No response generated due to error at actual quote generation",
            "strActualQuote":"Error at response generation for actual quote "}
            return (dictResponseClause6, strErrorMessage)
        try:
            listActualQuoteCheck =["No relevant language found."]
            if np.any([strActualQuoteFormattedOutputClause6 in i for i in listActualQuoteCheck]):
                strDetailedSummaryOutputClause6 = "The waiver file does not contain language indicating the applicable jurisdiction."
            else:
                #Detailed Summary generation for clause 6
                strDetailedSummaryPromptClause6 = f"""
                Use the waiver text enclosed in triple backticks to check whether there is any mention of internal laws of a specific state in relation to
                liability waivers.
                
                If present, begin the response with the statement "The waiver file is under the jurisdiction of". 
                The output generated must be grammatically correct and crisp in one line.


                waiver text: '''{strActualQuoteFormattedOutputClause6}'''
                """
        
                strDetailedSummaryOutputClause6 = getGPTResponse(strDetailedSummaryPromptClause6, objOpenAIClient, dictConfig)
        except Exception as e:
            # Check if any error occurs during detailed summary generation
            strErrorMessage = f"RunID_{str(self.intRunID)} - AML Endpoint - ERROR - Detailed summary generation for Requirement 13 has failed due to following error - "+str(e)
            dictResponseClause6 = {**dictInfoClause6, 
            "strValidationOutput":"Needs Review",
            "strBriefSummary":"No response generated due to error at detailed summary generation",
            "strDetailedSummary":"Error at response generation for detailed summary ",
            "strActualQuote":strActualQuoteFormattedOutputClause6}
            return (dictResponseClause6, strErrorMessage)


        try:
            #Brief Summary generation for clause 6
            strBriefSummaryPromptClause6 = f"""
            Your task is to evaluate the waiver text enclosed in triple backticks,
            based on the following conditions and respond if further attention from the underwriter is 
            required or not.


            Use the below conditions carefully to determine if further attention of underwriter is required:
            - If the waiver text mentions name of State or Country that shall govern the agreement
            then only it means no further validation of underwriter is required and therefore the text can be considered "Passed validation".

            - If the waiver text does not mention, then further validation from underwriter is required and 
            the text can be considered for "Needs review".


            Output format:
            Needs review - along with your reasoning
            or
            Passed validation - along with your reasoning

            Provide the reasoning in only single statement beginning with the phrase "The waiver file is under the jurisdiction of ".
            Ensure the reasoning is grammatically correct


            waiver text: '''{strDetailedSummaryOutputClause6}'''
            """
            strBriefSummaryOutputClause6 = getGPTResponse(strBriefSummaryPromptClause6, objOpenAIClient, dictConfig)
            strValidationOutput, strBriefSummaryOutputClause6Split= getValidationOutputAndBriefSummary(strBriefSummaryOutputClause6)
            
            strRequirementDescriptionClause6 = dictInfoClause6['strReqDescription']
            strNewRequirementDescriptionClause6 = generateBriefSummaryWithRequirement(strRequirementDescriptionClause6, objOpenAIClient, dictConfig)
            strBriefSummaryOutputClause6Split = strNewRequirementDescriptionClause6 +' '+ strBriefSummaryOutputClause6Split
            
            dictResponseClause6 ={**dictInfoClause6, "strValidationOutput":strValidationOutput, 
            "strBriefSummary":strBriefSummaryOutputClause6Split, 
            "strDetailedSummary":strDetailedSummaryOutputClause6,
            "strActualQuote":strActualQuoteFormattedOutputClause6
            }
            return (dictResponseClause6, strErrorMessage)
        except Exception as e:
            # Check if any error occurs during brief summary generation
            strErrorMessage = f"RunID_{str(self.intRunID)} - AML Endpoint - ERROR - Brief summary generation for Requirement 13 has failed due to following error - "+str(e)
            dictResponseClause6 = {**dictInfoClause6, 
            "strValidationOutput":"Needs Review",
            "strBriefSummary":"Error at response generation for brief summary ",
            "strDetailedSummary":strDetailedSummaryOutputClause6,
            "strActualQuote":strActualQuoteFormattedOutputClause6
            }
            return (dictResponseClause6, strErrorMessage)
    