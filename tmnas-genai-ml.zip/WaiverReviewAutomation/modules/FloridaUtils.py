######################################### MODULE INFORMATION ######################################### 
'''
This module consists of utility functions used by clause 4g

'''
################################################# END #################################################

# Import required packages
import re
import io
import fitz
from modules.utils import getBlobServiceClientTokenCredential
import pandas as pd

### check for Florida specific subsection is present in the input text or not
def checkFloridaStatement(strTextData:str):
    '''
    Function to check if Florida state specific statement is present in the text data
    
    Parameters
    - strTextData (str): Waiver text data

    return:
    - boolFloridaStatementMatch(bool) : True/False

    '''    
    strTextData=(' ').join(strTextData.split())
    # Define the pattern with a placeholder for the camp name
    pattern = re.compile(r"READ THIS FORM COMPLETELY AND CAREFULLY\. YOU ARE AGREEING TO LET YOUR MINOR CHILD ENGAGE IN A POTENTIALLY DANGEROUS ACTIVITY\. YOU ARE AGREEING THAT, EVEN IF (.+?) USES REASONABLE CARE IN PROVIDING THIS ACTIVITY, THERE IS A CHANCE YOUR CHILD MAY BE SERIOUSLY INJURED OR KILLED BY PARTICIPATING IN THIS ACTIVITY BECAUSE THERE ARE CERTAIN DANGERS INHERENT IN THE ACTIVITY WHICH CANNOT BE AVOIDED OR ELIMINATED\. BY SIGNING THIS FORM YOU ARE GIVING UP YOUR (CHILD\'S|CHILD'S|CHILD’S|CHILD\’S|CHILDâ€™S) RIGHT AND YOUR RIGHT TO RECOVER FROM (.+?) IN A LAWSUIT FOR ANY PERSONAL INJURY, INCLUDING DEATH, TO YOUR CHILD OR ANY PROPERTY DAMAGE THAT RESULTS FROM THE RISKS THAT ARE A NATURAL PART OF THE ACTIVITY\. YOU HAVE THE RIGHT TO REFUSE TO SIGN THIS FORM, AND (.+?) HAS THE RIGHT TO REFUSE TO LET YOUR CHILD PARTICIPATE IF YOU DO NOT SIGN THIS FORM\.",  re.IGNORECASE|re.DOTALL)
    # Find all matches in the text
    matches = pattern.findall(strTextData)
    boolFloridaStatementMatch=bool(matches)
    return boolFloridaStatementMatch  # Return True if at least one match is found, else False


### check whether Florida specific subsection is present in the input text in uppercase
def checkFloridaStatementUpper(strTextData:str):
    '''
    Function to check if Florida state specific statement is present in the text data in Upper case
    
    Parameters
    - strTextData (str): Waiver text data

    return:
    - boolFloridaStatementMatch(bool) : True/False

    ''' 
    strTextData=(' ').join(strTextData.split())
    # Define the pattern with a placeholder for the camp name
    pattern = re.compile(r"READ THIS FORM COMPLETELY AND CAREFULLY\. YOU ARE AGREEING TO LET YOUR MINOR CHILD ENGAGE IN A POTENTIALLY DANGEROUS ACTIVITY\. YOU ARE AGREEING THAT, EVEN IF (.+?) USES REASONABLE CARE IN PROVIDING THIS ACTIVITY, THERE IS A CHANCE YOUR CHILD MAY BE SERIOUSLY INJURED OR KILLED BY PARTICIPATING IN THIS ACTIVITY BECAUSE THERE ARE CERTAIN DANGERS INHERENT IN THE ACTIVITY WHICH CANNOT BE AVOIDED OR ELIMINATED\. BY SIGNING THIS FORM YOU ARE GIVING UP YOUR (CHILD\'S|CHILD'S|CHILD’S|CHILD\’S) RIGHT AND YOUR RIGHT TO RECOVER FROM (.+?) IN A LAWSUIT FOR ANY PERSONAL INJURY, INCLUDING DEATH, TO YOUR CHILD OR ANY PROPERTY DAMAGE THAT RESULTS FROM THE RISKS THAT ARE A NATURAL PART OF THE ACTIVITY\. YOU HAVE THE RIGHT TO REFUSE TO SIGN THIS FORM, AND (.+?) HAS THE RIGHT TO REFUSE TO LET YOUR CHILD PARTICIPATE IF YOU DO NOT SIGN THIS FORM\.", re.DOTALL)
    # Find all matches in the text
    matches = pattern.findall(strTextData)
    boolFloridaStatementMatchUpper=bool(matches)
    return boolFloridaStatementMatchUpper # Return True if at least one match is found, else False


###if 'State of Florida' is present in the waiver text check for Florida specific subsection is present in the text or not
def checkFloridaStateAndStatement(strTextData:str):
    '''
    Function to check if Florida state specific statement is present in the text data along with the name of the state
    
    Parameters
    -strTextData (str): Waiver text data

    return:
    - if florida text found:
          then florida_state_statement_flag(bool) : True/False
      else:
          str

    '''
    strFloridaCheck='State of Florida'.lower()
    if strFloridaCheck in strTextData.lower():
        boolFloridaStateStatementFlag=checkFloridaStatement(strTextData)
        return boolFloridaStateStatementFlag  # Return True if at least one match is found, else False
    else:
        return "Florida state is not mentioned in the waiver."


### creating detailed response and actual quote for Florida state requirement
def clause4gDetailedOutputGeneration(strWaiverFile:str, strWaiverTextData:str, dictConfig:dict):
    '''
    Function to generate detailed summary for clause 4g
    
    Parameters
    - strWaiverFile (str): Waiver file name
    - strWaiverTextData (str): Waiver text data
    - dictConfig (dict): Configuration details

    return:
    - strDetailedResponseFlag(str) : Detailed summary of clause 4g

    '''    
    strFloridaConditionCheck=''
    strFontConditionCheck=''
    strDetailedResponseFlag=''
    boolSatatementCheck=checkFloridaStatement(strWaiverTextData)
    boolSatatementUppercaseCheck=checkFloridaStatementUpper(strWaiverTextData)
    boolStateSatatementCheck=checkFloridaStateAndStatement(strWaiverTextData)
    if boolStateSatatementCheck==True:
    ###downloading the pdf file from blob storage
        try:
            # Establish the connection with blob resource
            strPdfSourceContainerName=dictConfig['UPLOAD_FILE_CONTAINER']
            objGetBlobClient = getBlobServiceClientTokenCredential(dictConfig)
            # Check whether the connection was successfully established
            if isinstance(objGetBlobClient, Exception):
                # Check for any error during connecting with blob resource
                strErrorMessage = "Failed to establish connection with blob service client with the following exception - "+str(objGetBlobClient)
                raise Exception(strErrorMessage) 
            else:
                try:
                    # Download the blob to a stream
                    objBlobClient = objGetBlobClient.get_blob_client(strPdfSourceContainerName, strWaiverFile)
                    objStream = io.BytesIO()
                    objDownloader = objBlobClient.download_blob()
                    objDownloader.readinto(objStream)
                    objStream.seek(0)
                except Exception as e:
                    # Check for any error while reading file from blob container
                    strErrorMessage = "Failed to read the input file from blob with the following exception - "+str(e)
                    raise Exception(strErrorMessage)
        except Exception as e:
            # If any error occurs the error information is sent back to the calling function
            return {'RunError': e}


        objPdfFileData = fitz.open(stream=objStream, filetype='pdf')
        listPdfProperties=[]
        for intPageNum in range(objPdfFileData.page_count):
            page = objPdfFileData.load_page(intPageNum)
            TextData = page.get_text("dict")
            if "blocks" in TextData:
                for block in TextData["blocks"]:
                    if "lines" in block:
                        for line in block["lines"]:
                            if "spans" in line:
                                for span in line["spans"]:
                                    text = span["text"]
                                    font_size = round(span["size"])
                                    x0, y0 = span["origin"]
                                    listPdfProperties.append([text, font_size,  x0, y0, intPageNum])

        # Create a DataFrame from the extracted data
        dfPdfProperties = pd.DataFrame(listPdfProperties, columns=["strPdfTextData", "numTextFontSize", "floatTextXCord", "floatTextYCord","intPageNum"])
        dfPdfProperties=dfPdfProperties[dfPdfProperties.strPdfTextData!=' ']
        dfPdfProperties=dfPdfProperties.sort_values(['intPageNum', 'floatTextYCord'], ascending=[True, True])
        dfPdfProperties["intYCordDiff"]=dfPdfProperties.groupby('intPageNum')['floatTextYCord'].diff().round()
        dfPdfProperties["intFontSizeDiff"]=dfPdfProperties['numTextFontSize'].diff().round().abs()
        # Since we are using opensource package pymupdf for calculating the font size we are keeping font the difference as 4. Once we move to phase3 we will use adobe package after client confirmation for calculating the font size. As we have tested abode package provide more accurate font size results. Then we will use the font size difference as 5.
        dfPdfProperties['intFontSizeChangeMarker']=(dfPdfProperties["intFontSizeDiff"]>=4).astype(int)
        dfPdfProperties['intFontSizeNoChangeMarker']=(dfPdfProperties["intFontSizeDiff"]==0).astype(int)
        dfPdfProperties=dfPdfProperties.reset_index(drop=True)

        #finding out the indices where there is atleast 4 point change in font size
        listFontSizeChangeIndices=dfPdfProperties.index[dfPdfProperties.intFontSizeChangeMarker==1].tolist()

        # creating group based on indices
        listgroupFontSizeDF=[dfPdfProperties.iloc[listFontSizeChangeIndices[i]:listFontSizeChangeIndices[i+1]] for i in range(len(listFontSizeChangeIndices)-1)]

        #checking if the font size difference in any group is same and y0 difference is also same in that group

        listgroupFontSizeDFCheck=[group for group in listgroupFontSizeDF if (group[group['intFontSizeChangeMarker']!=1]['intFontSizeNoChangeMarker'].nunique()==1) & (group[group['intFontSizeChangeMarker']!=1]['intYCordDiff'].nunique()==1)]

        listChunkFontCheckMarker=[]        
        for j in range(len(listgroupFontSizeDFCheck)):
            dfChunk=listgroupFontSizeDFCheck[j]
            strdfChunkText=dfChunk['strPdfTextData'].str.cat(sep='')
            strdfChunkText=strdfChunkText.strip()
            if checkFloridaStatement(strdfChunkText):
                listChunkFontCheckMarker.append(1)
            else:
                listChunkFontCheckMarker.append(0)

        if 1 in listChunkFontCheckMarker:
            strFontConditionCheck='font check satisfied'

        for i in range(len(listgroupFontSizeDFCheck)):
            dfChunk=listgroupFontSizeDFCheck[i]
            strdfChunkText=dfChunk['strPdfTextData'].str.cat(sep='')
            strdfChunkText=strdfChunkText.strip()
            if ((checkFloridaStatement(strdfChunkText)) & (boolSatatementUppercaseCheck==True)):
                strFloridaConditionCheck='This waiver is part of Florida state and Florida state requirements satisfied.'
                break

    if strFloridaConditionCheck=='This waiver is part of Florida state and Florida state requirements satisfied.':
        strDetailedResponseFlag="This waiver file is part of the State of Florida, and contains the required statement specific to minor child as per the law of the State of Florida. The statement is in uppercase and is 5 points larger than the rest of the text in the document."
    elif boolStateSatatementCheck=="Florida state is not mentioned in the waiver.":
        strDetailedResponseFlag="This waiver file is not part of the state of Florida. Hence, this requirements is not applicable." 
    elif boolStateSatatementCheck==True and strFloridaConditionCheck=='':
        if boolSatatementCheck==False:
            strDetailedResponseFlag='This waiver file is part of the State of Florida, but the statement specific to minor child is not satisfied.'
        else:
            if (strFontConditionCheck=='font check satisfied') & (boolSatatementUppercaseCheck==False):
                strDetailedResponseFlag='This waiver file is part of the State of Florida, but the statement is not as per the guideline in terms of uppercase. But the font size is as per the guideline (5 points bigger than the other text).'
            elif (strFontConditionCheck=='') & (boolSatatementUppercaseCheck==True):
                strDetailedResponseFlag='This waiver file is part of the State of Florida, but the statement is not as per the guideline in terms of font size (The statement is only 3 or 4 points bigger than the other text). The statement is in uppercase.'
            else:
                strDetailedResponseFlag='This waiver file is part of the State of Florida, but the statement is not as per the guideline in terms of font size (The statement is only 3 or 4 points bigger than the other text) and uppercase.'
    elif boolStateSatatementCheck==False:
        strDetailedResponseFlag='This waiver file is part of the State of Florida, but the statement specific to minor child is not satisfied.' 
    return strDetailedResponseFlag


### Extracting the actual quote for Florida specific requirement
def extractTextBetweenSubstrings(strText:str, strStartSubstring:str, strEndSubstring:str):
    '''
    Function to match specific pattern
    
    Parameters
    - text (str): Waiver text data
    - start_substring (str): starting substring
    - end_substring (str): ending substring

    return:
    - matches(str) : return match string

    '''
    pattern = re.escape(strStartSubstring) + r'(.*?)' + re.escape(strEndSubstring)
    matches = re.findall(pattern, strText, re.DOTALL)
    return matches
