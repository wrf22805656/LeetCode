######################################### MODULE INFORMATION ######################################### 
'''
This module does the following process:
    1. Read file from input blob container based on file name
    2. Run document intelligence over the file and extract the page-wise textual content
    3. Push the extracted content to output blob container as .txt file
    4. Updates the metadata SQL DB with the status of this stage
    5. Returns the page-wise extracted content as a list to the calling function

'''
################################################# END #################################################

# Import required packages
import io
from modules.utils import saveMetadataAndValidationResults, loadConfigDetails, getBlobServiceClientTokenCredential
from azure.ai.formrecognizer import DocumentAnalysisClient
from azure.identity import ManagedIdentityCredential

class dataExtraction():
    def __init__(self):
        # Load the required configuration variables from the key vault
        self.config_details = loadConfigDetails('DataExtraction')      
    
    def extractText(self, strDocumentName:str, strProductType:str, intRunID:int):
        '''
        Function to extract text from documents (PDF or .docx)
        
        Parameters:
        - strDocumentName (str): Path of the document
        
        return:
        - dictResult (dict): text extracted from the document
        
        '''
        
        try:
            # Establish the connection with blob resource
            strSourceContainerName=self.config_details["UPLOAD_FILE_CONTAINER"]
            objGetBlobClient = getBlobServiceClientTokenCredential(self.config_details)
            # Check whether the connection was successfully established
            if isinstance(objGetBlobClient, Exception):
                # Check for any error during connecting with blob resource
                strErrorMessage = f"RunID_{str(intRunID)} - AML Endpoint - ERROR - Failed to establish connection with blob service client with the following exception - "+str(objGetBlobClient)
                raise Exception(strErrorMessage)
            else:
                try:
                    # Download the blob to a stream
                    objBlobClient = objGetBlobClient.get_blob_client(strSourceContainerName, strDocumentName)
                    objStream = io.BytesIO()
                    objDownloader = objBlobClient.download_blob()
                    objDownloader.readinto(objStream)
                    objStream.seek(0)
                except Exception as e:
                    # Check for any error while reading file from blob container
                    strErrorMessage = f"RunID_{str(intRunID)} - AML Endpoint - ERROR - Failed to read the input file from blob with the following exception - "+str(e)
                    raise Exception(strErrorMessage)

                try:
                    # Establish the connection with Document Intelligence resource and create the DocumentAnalysisClient object
                    strDocumentIntelligenceEndpoint = self.config_details["DOC_INTELLIGENCE_ENDPOINT"]
                    strDocumentIntelligenceCredential = ManagedIdentityCredential()
                    objDocumentAnalysisClient = DocumentAnalysisClient(endpoint=strDocumentIntelligenceEndpoint, credential=strDocumentIntelligenceCredential)
                    # Extracting the content using DocumentAnalysisClient
                    objPoller = objDocumentAnalysisClient.begin_analyze_document("prebuilt-read", document=objStream)
                    objDocument = objPoller.result()
                    dictResult = objDocument.to_dict()
                except Exception as e:
                    # Check for any error while running data extraction using Document Intelligence resource
                    strErrorMessage = f"RunID_{str(intRunID)} - AML Endpoint - ERROR - Failed to initialise document intelligence client with the following exception - "+str(e)
                    raise Exception(strErrorMessage)
                                             
                try:
                    # Upload the extracted text into storage container
                    strOutputContainerName=self.config_details["EXTRACT_FILE_CONTAINER"]
                    strExtractedFileName = strDocumentName.rsplit('.',1) [0]+'.txt'
                    objBlobClientOut = objGetBlobClient.get_blob_client(strOutputContainerName, strExtractedFileName)
                    objBlobClientOut.upload_blob (dictResult['content'], overwrite=True)
                except Exception as e:
                    # Check for any error that has occurs while uploading
                    strErrorMessage = f"RunID_{str(intRunID)} - AML Endpoint - ERROR - Failed to upload extracted file to blob with the following exception - "+str(e)
                    raise Exception(strErrorMessage)

                try:
                    # Update metadata SQL DB with the status of the stage
                    dictData = {'db_info': {'extracted_file_name' : strExtractedFileName,
                                                'product_type': strProductType,
                                                'run_id': intRunID}}
                    strFunctionName = 'DataExtraction'
                    strRes = saveMetadataAndValidationResults(strFunctionName, dictData, self.config_details)
                except Exception as e:
                    # Check for any error that occurs while updating SQL DB
                    strErrorMessage = f"RunID_{str(intRunID)} - AML Endpoint - ERROR - The Azure function call to save the Metadata/Clause Validation results failed with the error - " + str(e)
                    raise Exception(strErrorMessage)               
                
                return dictResult
        except Exception as e:
            # If any error occurs the error information is sent back to the calling function
            return {'RunError': e}

    def getPageData(self, strFileName:str, strProductType:str, intRunID:int):
        '''
        Function to parse page level data from text extracted of the document

        Parameters: 
        - strFileName (str): file name of the document

        return:
        - listPageData (list): List of dictionaries containing page number and text from each page

        '''
        try:
            # Extracting text from pdf documents
            dictResult = self.extractText(strFileName, strProductType, intRunID)
            
            if len(dictResult)==1 and 'RunError' in dictResult.keys():
                # Check for any error in the data extraction process and raise an exception
                strErrorMessage = str(dictResult['RunError'])
                raise Exception(strErrorMessage)
            else:
                # Getting page level text along with the page number
                listPageData = []
                for page in dictResult["pages"]:
                    strPageString = ""
                    for line in page["lines"]:
                        strPageString = strPageString+"\n"+line["content"]
                    listPageData.append(strPageString)
                return listPageData
        except Exception as e:
            # Check for any error and log the error
            print(str(e))
            return [str(e)]
