######################################### MODULE INFORMATION ######################################### 
'''
This module calls the corresponding python module based on the product type and executes the clauses 
defined.

'''
################################################# END #################################################

# Import required libraries
import sys
import importlib.util

def generateDetailedSummary(strVectorIndexName:str, strProductType:str, strWaiverFileName: str, strProductTypeClassName: str, intRunID: int):
    """
    This function calls the corresponding python file based on the product type 
    and executes the clauses defined.

    Parameters:
	- strVectorIndexName (str): AI search Vector index name
    - strProductType (str): Product type
    - strWaiverFileName (str): Name of the waiver file
    - strProductTypeClassName (str): The name of the python module corresponding to the product type
    - intRunID (int): Run id of the current run
    """    
    try:
        # Load the python module corresponding to the product type
        objModule = importlib.import_module(strProductTypeClassName)
        objProductType = getattr(objModule, strProductTypeClassName)(strVectorIndexName, strWaiverFileName, strProductType, intRunID)
        # Get the clause validation result
        objMethod = getattr(objProductType, "generateWaiverSummary")
        strDetailedSummary = objMethod()
        return strDetailedSummary
    except Exception as e:
        # Capture any exception if it occurs, create a custom error message and log it to the app insights
        strErrorMessage = f"RunID_{str(intRunID)} - AML Endpoint - ERROR - Clause validation process failed due to following error - "+str(e)
        print(strErrorMessage)
        # Raise an Exception with the custom message
        raise Exception(strErrorMessage)