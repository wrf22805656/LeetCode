######################################### MODULE INFORMATION ######################################### 
'''
This module does the following process:
    1. Gets the page-wise extracted content as a list and the file name
    2. For each page-wise content, embeddings are created using openai embedding model and also corresponding metadata is added
    3. After that index with filename is created in AI search and the respective content is being pushed to the index
    4. Updates the metadata SQL DB with the status of the stage
    5. Returns the index name to the calling function after successful creation of index

'''
################################################# END #################################################

# Import required packages
import re
from modules.utils import saveMetadataAndValidationResults, loadConfigDetails, getOpenAIClient, getOpenAIEmbedding
import time
from azure.search.documents import SearchClient  
from azure.search.documents.indexes import SearchIndexClient  
from azure.search.documents.indexes.models import (  
    SearchIndex,  
    SearchField,  
    SearchFieldDataType,  
    SimpleField,  
    SearchableField,  
    SearchIndex,
    SearchField,  
    VectorSearch,
    VectorSearchProfile,
    HnswAlgorithmConfiguration
)
from azure.identity import DefaultAzureCredential

class dataVectorization():
    def __init__(self):
        # Load the required configuration variables from the key vault
        self.config_details = loadConfigDetails('DataVectorization')

    def getAISearchCredential(self):
        '''
        Function to create the AI Search Index Client

        return:
        - objAISearchIndexClient: AI Search Index Client Object
        '''
        # Get the name of the AI Search endpoint from configuration dictionary
        strAISeacrchEndpoint=self.config_details["AI_SEARCH_ENDPOINT"]
        # Establish connection with the AI Search resource and creates the SearchIndexClient
        # Retries to establish connection for 3 times at subsequent interval of 3 seconds if error happens due to not able to get access token using DefaultAzureCredential
        intRetries = 3 #Number of retries
        for attempt in range(intRetries):
            try:
                objCredential = DefaultAzureCredential()
                objAISearchIndexClient = SearchIndexClient(strAISeacrchEndpoint, objCredential)
            except Exception as e:
                # Check for any error while establishing connection with AI Search resource 
                if 'DefaultAzureCredential failed to retrieve a token from the included credentials' in str(e) and attempt < (intRetries-1):
                    time.sleep(3) # Time interval between retries 
        return objAISearchIndexClient

    def createVectorIndex(self, strVectorIndexName:str):
        '''
        Function to create or update the AI Search Vector index

        Parameters:
        - strVectorIndexName (str): Name of the vector index

        '''
        # Initialize the AI SearchIndexClient
        objAISearchIndexClient = self.getAISearchCredential()
        # Define the index fields
        listFields = [
            SimpleField(name="runidPageNo", type=SearchFieldDataType.String, key=True, sortable=True, filterable=True, facetable=True), # Primary key of the chunks in index
            SearchableField(name="runid", type=SearchFieldDataType.String, filterable=True),
            SearchableField(name="pagenumber", type=SearchFieldDataType.String),
            SearchableField(name="content", type=SearchFieldDataType.String),
            SearchField(name="embedding", type=SearchFieldDataType.Collection(SearchFieldDataType.Single),
                        searchable=True, vector_search_dimensions=3072, vector_search_profile_name="my-vector-config"),
        ]
        # Define index profiles and algorithms
        objVectorSearch = VectorSearch(
            profiles=[VectorSearchProfile(name="my-vector-config", algorithm_configuration_name="my-algorithms-config")],
            algorithms=[HnswAlgorithmConfiguration(name="my-algorithms-config")],
        )
        # Initialise SearchIndex
        objVectorIndex = SearchIndex(name=strVectorIndexName, fields=listFields, vector_search=objVectorSearch)
        # Create index or update an existing index
        objAISearchIndexClient.create_or_update_index(objVectorIndex)


    def uploadDocsToAISearchIndex(self, vectorized_doc:list, strVectorIndexName:str):
        '''
        Function to upload the content and corresponding embedding to AI Search Index.

        Parameters:
        - vectorized_doc (list): list of the dictionaries containing chunk information
        - strVectorIndexName (str): Name of the vector index

        '''
        # Get the name of the AI Search endpoint from configuration dictionary 
        strAISeacrchEndpoint=self.config_details["AI_SEARCH_ENDPOINT"]
        # Establish connection with the AI Search resource and creates the SearchIndexClient
        credential = DefaultAzureCredential()
        objAISearchClient = SearchClient(endpoint=strAISeacrchEndpoint, index_name=strVectorIndexName, credential=credential)
        objAISearchClient.merge_or_upload_documents(vectorized_doc)

    def vectorization(self, listInputText:list, strProductType:str, intRunID:int):
        '''
        Function to embed the content, create the index and upload in the index
  
        Parameters:
        - listInputText (list): List of the pagewise input content
        - strProductType (str): Product type of the waiver file
        - intRunID (int): Run ID of the current upload

        return:
        - strIndexName (str): AI Search Vector Index name
        '''
        listVector = []
        try:
            # Initialize the OpenAI client
            objOpenAIClient = getOpenAIClient(self.config_details)
            for i in range(len(listInputText)):
                dictVectorDoc = {}
                strPageNum = str(i+1)
                strRunID = str(intRunID)
                strContent = listInputText[i]
                # Generate embedding for the content
                objVector = getOpenAIEmbedding(strContent, objOpenAIClient, self.config_details)
                dictVectorDoc.update({'runidPageNo': strRunID+'_'+strPageNum})
                dictVectorDoc.update({'runid': strRunID})
                dictVectorDoc.update({'pagenumber': strPageNum})
                dictVectorDoc.update({'content': strContent})
                dictVectorDoc.update({'embedding': objVector})
                listVector.append(dictVectorDoc)
            # Store the embedding to the AI Search vector index
            strIndexName = strProductType
            strIndexName = re.sub('[^A-Za-z0-9]+', '', strIndexName)
            strIndexName = strIndexName.lower()
            self.createVectorIndex(strIndexName)
            self.uploadDocsToAISearchIndex(listVector, strIndexName)
            
            try:
                # Update metadata SQL DB with the status of the stage
                dictData = {'db_info': {'vector_index_name' : strIndexName,
                                            'product_type': strProductType,
                                            'run_id': intRunID}}
                strFunctionName = 'DataVectorization'
                strRes = saveMetadataAndValidationResults(strFunctionName, dictData, self.config_details)        

            except Exception as e:
                # Check for any error that occurs while updating SQL DB
                strErrorMessage = f"The Azure function call to save the Metadata/Clause Validation results has failed - "+str(e)
                raise Exception(strErrorMessage)

            return strIndexName
        except Exception as e:
            # Check for any error and log the error
            strErrorMessage = f"RunID_{str(intRunID)} - AML Endpoint - ERROR - Vectorization failed due to following error - "+str(e)
            print(strErrorMessage)
            return strErrorMessage
        