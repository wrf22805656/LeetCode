######################################### MODULE INFORMATION ######################################### 
'''
This module consists of common utility functions across all the 3 stages namely data extraction, data
vectorization and clause validation.

'''
################################################# END #################################################

# Import required packages
import os
import re
import urllib
import json
import time
from openai import AzureOpenAI
from azure.identity import DefaultAzureCredential, ManagedIdentityCredential, get_bearer_token_provider
from azure.core.credentials import AccessToken, TokenCredential
from azure.storage.blob import BlobServiceClient
from azure.search.documents import SearchClient 
from azure.keyvault.secrets import SecretClient

# This CustomTokenCredential class is created to override the get_token method of the TokenCredential class.
# This is done to avoid multiple calls to fetch access token from Azure. Multiple calls might result is not able to fetch token error.
# Since the token validation stays for hours so instead of getting the same access token multiple times, using the same token.
class CustomTokenCredential(TokenCredential):
    def __init__(self, access_token:AccessToken):
        self._access_token = access_token
    # Class method that is overridden to return the already generated access token instead of making a new call
    def get_token(self, *scopes, **kwargs):
        return self._access_token

def loadConfigDetails(strOperation:str):
        '''
        Function for the config dictionary preparation for different stages

        Parameter:
        - strOperation (str): stage that is calling this function (either DataExtraction, DataVectorization or ClauseValidation)
        
        return:
        - config_details (dict): dictionary of configuration details
        
        '''
        # Reading the json file which has the key vault name
        utilsDir = os.path.dirname(os.path.abspath(__file__))
        cofigFilePath = os.path.join(utilsDir, 'keyvault_name.json')
        with open(cofigFilePath, 'r', encoding='utf-8-sig') as kv_file:
            kv_config = json.load(kv_file)
            strKeyVaultName = kv_config.get('keyVaultName')

        # Initializing the key vault SecretClient to fetch the secrets
        # Retries to establish connection for 3 times at subsequent interval of 3 seconds if error happens due to not able to get access token using DefaultAzureCredential
        intRetries = 3 # Number of retries
        for attempt in range(intRetries):
            try:
                objDefaultCredential = DefaultAzureCredential()
                objGetToken = objDefaultCredential.get_token("https://vault.azure.net/.default")
                objAccessToken = AccessToken(objGetToken.token, objGetToken.expires_on)
            except Exception as e:
                if 'DefaultAzureCredential failed to retrieve a token from the included credentials' in str(e) and attempt < (intRetries-1):
                    time.sleep(3) # Time Interval between retries
        # Create the CustomTokenCredential class
        ObjCustomCredential = CustomTokenCredential(objAccessToken)
        objKVclient = SecretClient(f'https://{strKeyVaultName}.vault.azure.net/', ObjCustomCredential)

        # Fetching secrets only necessary for DataExtraction stage
        if strOperation == 'DataExtraction':
            config_details={
                "STORAGE_ACCOUNT_ENDPOINT": objKVclient.get_secret('STORAGE-ACCOUNT-ENDPOINT').value,
                'DOC_INTELLIGENCE_ENDPOINT': objKVclient.get_secret('DOC-INTELLIGENCE-ENDPOINT').value,
                'UPLOAD_FILE_CONTAINER': objKVclient.get_secret('UPLOAD-FILE-CONTAINER').value,
                'EXTRACT_FILE_CONTAINER': objKVclient.get_secret('EXTRACT-FILE-CONTAINER').value,
                'SAVE_METADATA_AND_RESULTS_FUNCTION': objKVclient.get_secret('SAVE-METADATA-AND-RESULTS-FUNCTION').value
            }
            return config_details
        # Fetching secrets only necessary for DataVectorization stage
        elif strOperation == 'DataVectorization':
            config_details={
                "STORAGE_ACCOUNT_ENDPOINT": objKVclient.get_secret('STORAGE-ACCOUNT-ENDPOINT').value,
                'AI_SEARCH_ENDPOINT': objKVclient.get_secret('AI-SEARCH-ENDPOINT').value,
                'EMBEDDING_MODEL': objKVclient.get_secret('EMBEDDING-MODEL').value,
                'OPENAI_API_VERSION': objKVclient.get_secret('OPENAI-API-VERSION').value,
                'OPENAI_ENDPOINT': objKVclient.get_secret('OPENAI-ENDPOINT').value,
                'SAVE_METADATA_AND_RESULTS_FUNCTION': objKVclient.get_secret('SAVE-METADATA-AND-RESULTS-FUNCTION').value
            }
            return config_details
        # Fetching secrets only necessary for ClauseValidation stage
        elif strOperation == 'ClauseValidation':
            config_details={
                "STORAGE_ACCOUNT_ENDPOINT": objKVclient.get_secret('STORAGE-ACCOUNT-ENDPOINT').value,
                'OPENAI_ENDPOINT': objKVclient.get_secret('OPENAI-ENDPOINT').value,
                'EMBEDDING_MODEL': objKVclient.get_secret('EMBEDDING-MODEL').value,
                'OPENAI_API_VERSION': objKVclient.get_secret('OPENAI-API-VERSION').value,
                'AI_SEARCH_ENDPOINT': objKVclient.get_secret('AI-SEARCH-ENDPOINT').value,
                'DOC_INTELLIGENCE_ENDPOINT': objKVclient.get_secret('DOC-INTELLIGENCE-ENDPOINT').value,
                'LARGE_LANGUAGE_MODEL': objKVclient.get_secret('LANGUAGE-MODEL').value,
                'UPLOAD_FILE_CONTAINER': objKVclient.get_secret('UPLOAD-FILE-CONTAINER').value,
                'EXTRACT_FILE_CONTAINER': objKVclient.get_secret('EXTRACT-FILE-CONTAINER').value,
                'SAVE_METADATA_AND_RESULTS_FUNCTION': objKVclient.get_secret('SAVE-METADATA-AND-RESULTS-FUNCTION').value
            }
            return config_details

def saveMetadataAndValidationResults(strFunctionName:str, dictData:dict, dictConfig:dict):
    '''
    Function to update the metadata table with status of different stage runs

    Parameters:
    - strFunctionName (str): Name of the stage (Data Extraction, Data Vectorization or Clause Validation)
    - dictData (dict): Datails that needs to be pushed to the DB
    - dictConfig (dict): configuration details

    return:
    - dictResult (dict): Response from DB after entry
    '''
    jsonBody = str.encode(json.dumps(dictData))
    # Get the azure function url from the configuration dictionary
    strFuncApp = dictConfig['SAVE_METADATA_AND_RESULTS_FUNCTION']
    # Calling the azure function to save the metadata and clause validation results
    strUrl = f"{strFuncApp}?function_name={strFunctionName}"
    dictHeaders = {'Content-Type':'application/json'}
    req = urllib.request.Request(strUrl, jsonBody, dictHeaders)
    jsonResponse = urllib.request.urlopen(req)
    dictResult = jsonResponse.read()
    return dictResult

def getBlobServiceClientTokenCredential(dictConfig:dict):
    '''
    Function to create a blob service client for the storage account

    Parameters:
    - dictConfig (dict): configuration details

    return:
    - objBlobServiceClient : Blob service client object

    '''
    try:
        strStorageAccountEndpoint = dictConfig["STORAGE_ACCOUNT_ENDPOINT"]   
        objCredential=ManagedIdentityCredential()
        # Create the BlobServiceClient object 
        objBlobServiceClient = BlobServiceClient(strStorageAccountEndpoint, credential=objCredential)
        return objBlobServiceClient
    except Exception as e:
        return e

def getAISearchClient(strVectorIndexName:str, dictConfig:dict):
    '''
    Function to get the AI search client object

    Parameters:
    - strVectorIndexName (str): Name of the AI search index
    - dictConfig (dict): configuration details

    return:
    - objSearchClient: Azure AI search client object
    '''
    strAISearchEndpoint=dictConfig["AI_SEARCH_ENDPOINT"]
    # Establish connection with the AI Search resource and creates the SearchClient
    # Retries to establish connection for 3 times at subsequent interval of 3 seconds if error happens due to not able to get access token using DefaultAzureCredential
    intRetries = 3 #Number of retries
    for attempt in range(intRetries):
        try:
            objDefaultCredential = DefaultAzureCredential()
            objGetToken = objDefaultCredential.get_token("https://search.azure.com/.default")
            objAccessToken = AccessToken(objGetToken.token, objGetToken.expires_on)
        except Exception as e:
            if 'DefaultAzureCredential failed to retrieve a token from the included credentials' in str(e) and attempt < (intRetries-1):
                time.sleep(3) #Time interval between reties
    ObjCustomCredential = CustomTokenCredential(objAccessToken)
    # Initialize AI SearchClient
    objSearchClient = SearchClient(strAISearchEndpoint, strVectorIndexName, credential=ObjCustomCredential)
    return objSearchClient
        
def getOpenAIClient(dictConfig:dict):
    '''
    Function to get the openai client after authentication

    Parameters:
    - dictConfig (dict): configuration details

    return:
    - objOpenAIClient - Azure OpenAI client object which can be used for content generation
    '''
    # Initialise AzureOpenAI client
    objTokenProvider = get_bearer_token_provider(DefaultAzureCredential(), "https://cognitiveservices.azure.com/.default")
    objOpenAIClient = AzureOpenAI(
                                api_version=dictConfig['OPENAI_API_VERSION'],
                                azure_endpoint=dictConfig['OPENAI_ENDPOINT'],
                                azure_ad_token_provider=objTokenProvider
                            )
    return objOpenAIClient

def getOpenAIEmbedding(strContent:str, objOpenAIClient:AzureOpenAI, dictConfig:dict):
    '''
    Function to create vector embeddings of the content

    Parameters:
    - strContent (str): Content to be vectorized
    - objOpenAIClient (AzureOpenAI object): The Azure OpenAI client
    - dictConfig (dict): configuration details

    return:
    - objVector: Embedding vector
    '''
    # Generate the embeddings
    objResponse = objOpenAIClient.embeddings.create(model=dictConfig['EMBEDDING_MODEL'], input=strContent)
    objVector = objResponse.data[0].embedding
    return objVector

def getGPTResponse(strPrompt:str, objOpenAIClient:AzureOpenAI, dictConfig:dict):
    '''
    Function to generate response from the Language Model

    Parameters:
    - strPrompt (str): Prompt to be sent to the language model
    - objOpenAIClient (AzureOpenAI object): The Azure OpenAI client
    - dictConfig (dict): configuration details

    return:
    - The response of the Large Language Model
    '''
    # Message information to be sent to Azure OpenAI and generate the response
    listMessages = [{"role": "user","content":strPrompt}]
    objResponse = objOpenAIClient.chat.completions.create(
                                model=dictConfig['LARGE_LANGUAGE_MODEL'],
                                messages=listMessages,
                                temperature=0.0,
                                n=1,
                            )
    return objResponse.choices[0].message.content

def actualQuoteFormatting(strText:str, objOpenAIClient:AzureOpenAI, dictConfig:dict):
    '''
    Function to format the quote according to the specified format

    Parameters:
    - strText (str): Actual quote generated from GPT response
    - objOpenAIClient (AzureOpenAI object): The Azure OpenAI client
    - dictConfig (dict): configuration details

    return:
    - strFormattedAcutalQuote (str): Formatted Actual quote
    '''
    # Prompt for the actual quote formatting
    strActualQuoteFormattingPrompt = f"""

    Your task is to reformat the text {strText} which contains sentences, first enclose the sentence
    in quotation marks and then number them.
    If there is only one sentence, then do not number it.   
    
    Sample output:
    1. "This is sample text1."
    2. "This is sample text2."
    3. "This is sample text3."
    
    """
    # Generate the formatted response
    strFormattedAcutalQuote =  getGPTResponse(strActualQuoteFormattingPrompt, objOpenAIClient, dictConfig)

    return strFormattedAcutalQuote
	
def getValidationOutputAndBriefSummary(strBriefSummaryText:str):
    '''
    Function to split the validation result and the summary separately to displayed in the UI

    Parameters:
    - strBriefSummaryText (str): Brief summary generated from GPT response

    return:
    - strValidationOutput (str): Validation output (Needs Review/ Passed Validation)
    - strBriefSummaryOutput (str): Brief Summary formatted output 
    '''
    strLowerText = strBriefSummaryText.lower()  # Convert text to lowercase for case insensitivity
    # Separate the brief summary output.
    # For Example: "Needs Review - This requirement seems invalid" will be separated into two variables which contains "Needs Review" and "This requirement seems invalid"
    if strLowerText.startswith("needs review"):
        strValidationOutput = "Needs Review"
        strBriefSummaryFormatted = re.search(r'\bneeds review\b[^a-zA-Z0-9]*([\w\W]*)', strBriefSummaryText, re.IGNORECASE)
    elif strLowerText.startswith("passed validation"):
        strValidationOutput = "Passed Validation"
        strBriefSummaryFormatted = re.search(r'\bpassed validation\b[^a-zA-Z0-9]*([\w\W]*)', strBriefSummaryText, re.IGNORECASE)
    else:
        strValidationOutput = "Needs Review"
        strBriefSummaryFormatted = "Validation part can not be identified "+strBriefSummaryText
    # Remove any unnecessary leading or trailing spaces
    if strBriefSummaryFormatted:
        strBriefSummaryOutput = strBriefSummaryFormatted.group(1).strip()
    else:
        strBriefSummaryOutput = strBriefSummaryText

    return strValidationOutput, strBriefSummaryOutput

def generateBriefSummaryWithRequirement(strRequirement:str, objOpenAIClient:AzureOpenAI, dictConfig:dict):
    strpromptreqdes = f""" Your task is to redescribe {strRequirement} in one line without changing the meaning.
    The sentence should start with "Requirement is to".
    Ensure the response is grammatically correct. 
    """
        
    strBriefStatement = getGPTResponse(strpromptreqdes, objOpenAIClient, dictConfig)
    return strBriefStatement