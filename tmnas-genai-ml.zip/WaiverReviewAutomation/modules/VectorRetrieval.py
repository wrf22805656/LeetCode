######################################### MODULE INFORMATION ######################################### 
'''
This module defines the class that helps in the retrieval of the relevant chunks from the Vector
index.

'''
################################################# END #################################################

# Import required libraries
import pandas as pd
from modules.utils import getOpenAIEmbedding
from azure.search.documents.models import VectorizedQuery
from openai import AzureOpenAI
from azure.search.documents import SearchClient

class dataRetrieval():
    def getAISearchRetrievedChunk(self, intRunID:int, strQuery:str, intChunkQuantity:int, objSearchClient:SearchClient, objOpenAIClient:AzureOpenAI, dictConfig:dict):
        '''
        Function to retrieve data from vector index based upon a query

        Parameters:
        - intRunID (int): The run id of the current run
        - strQuery (str): Query with which the function will find the similar chunks
        - intChunkQuantity (int): Number of chunks to retrieve
        - objSearchClient: Azure AI search client object
        - objOpenAIClient: Azure OpenAI client object
        - dictConfig (dict): configuration details

        return:
        - strRetrievedText (str): Retrieved chunks joined page wise into one text 

        '''
        # Get the embedding of the input query
        strEmbeddedQuery = getOpenAIEmbedding(strQuery, objOpenAIClient, dictConfig)
        strVectorQuery = VectorizedQuery(vector=strEmbeddedQuery, k_nearest_neighbors=intChunkQuantity, fields="embedding", exhaustive=True)
        # Pre-filter condition to do the similarity check on chunks that belongs to the respective runid's file
        # This is done as all the chunks of different files belonging to the same product type are stored under same index named as the respective product type
        strFilterCond = "runid eq '"+str(intRunID)+"'"
        # Fetch the relevant chunks
        objVectorResults = objSearchClient.search(  
            search_text=None,
            filter=strFilterCond,  
            select=["pagenumber", "content"],
            vector_queries= [strVectorQuery]
        )
        # Processing of the retrieved chunks
        listPageNumber = []
        listContent = []
        dfChunkWithPageNo = pd.DataFrame(columns = ['pagenumber', 'content'])
        for result in objVectorResults:  
            strContent = result['content']
            intPageNumber = int(result['pagenumber'])
            listPageNumber.append(intPageNumber)
            listContent.append(strContent)

        dfChunkWithPageNo['pagenumber'] = listPageNumber
        dfChunkWithPageNo['content'] = listContent
        dfChunkWithPageNo = dfChunkWithPageNo.sort_values('pagenumber')

        strRetrievedText = ''

        for i in range(len(dfChunkWithPageNo)):
            strContent = dfChunkWithPageNo['content'].iloc[i]
            strRetrievedText = strRetrievedText + strContent

        return strRetrievedText