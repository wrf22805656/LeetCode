######################################### MODULE INFORMATION ######################################### 
'''
This module executes all the clauses related to Camp Operator product type in a multithreaded way. It
also stores the results to the SQL DB.

'''
################################################# END #################################################

# Import required packages
import commonClauseValidation
import json
from concurrent.futures import ThreadPoolExecutor
from modules.utils import saveMetadataAndValidationResults, loadConfigDetails, getAISearchClient, getOpenAIClient

class campOperator(commonClauseValidation.commonClause):
      def __init__(self,strVectorIndexName, strWaiverFileName, strProductType, intRunID):
            super().__init__(strVectorIndexName, strWaiverFileName, strProductType, intRunID)
            self.dictConfig = loadConfigDetails('ClauseValidation') #Load the required configuration variables from the key vault
            self.objSearchClient = getAISearchClient(strVectorIndexName, self.dictConfig) #Get the AISearchClient object
            self.objOpenAIClient = getOpenAIClient(self.dictConfig) #Get the Azure OpenAIClient object
            self.kValue = 3 #Number of chunks to be retrieved during similarity check
            self.strProductType = strProductType
            self.intRunId = intRunID
            # Dictionary that contains metadata information of each clause for the Camp Operator product type
            self.dictClauseInfo={
            "clause_3": {"strReqNo": "Requirement 1",
                  "strReqCaterory": "Activities and Ineligible Exposures",
                  "strReqDescription": "List activities and check for Ineligible Exposures"},
            "clause_4a1": {"strReqNo": "Requirement 2",
                  "strReqCaterory": "Liability Waiver",
                  "strReqDescription": "Check the waiver for mentions of the service provider's name and covers their staff."},
            "clause_4a2":{"strReqNo": "Requirement 3",
                  "strReqCaterory": "Liability Waiver",
                  "strReqDescription": "It confirms the waiver covers claims for liabilities for injury, property damage, wrongful death, and other losses resulting from mistakes, errors, or faults of the provider or its owners, affiliates, employees, or agents."},
            "clause_4b1":{"strReqNo": "Requirement 4",
                  "strReqCaterory": "Assumption of Risk Agreement",
                  "strReqDescription": "Confirm the agreement lists the specific risks inherent in the activity."},
            "clause_4b2":{
                  "strReqNo": "Requirement 5",
                  "strReqCaterory": "Assumption of Risk Agreement",
                  "strReqDescription": "Check that the participant acknowledges understanding these risks may result in injury."},
            "clause_4b3":{"strReqNo": "Requirement 6",
                  "strReqCaterory": "Assumption of Risk Agreement",
                  "strReqDescription": "Validate that the participant is assuming all risks willfully and voluntarily."},
            "clause_4c1":{"strReqNo": "Requirement 7",
                  "strReqCaterory": "Pre-Injury Release",
                  "strReqDescription": "Check that the release conspicuously and unambiguously waives liability for future claims arising from the activity."},
            "clause_4c2":{"strReqNo": "Requirement 8",
                  "strReqCaterory": "Pre-Injury Release",
                  "strReqDescription": "Validate the participant knowingly agreed to the release."},
            "clause_4d":{"strReqNo": "Requirement 9",
                  "strReqCaterory": "Indemnity and Hold Harmless",
                  "strReqDescription": "Check that the agreement clearly states the participant agrees to indemnify and hold the provider harmless against any losses, liabilities and claims arising out of or relating to this transaction"},
            "clause_4g":{"strReqNo": "Requirement 10",
                  "strReqCaterory": "Florida Specific: Notice to the Minor Child’s Parent/Guardian",
                  "strReqDescription": "Notice to the Minor Child’s natural Guardian Florida state requirements: To be enforceable, a waiver or release executed under this subsection must, at a minimum, include the following statement in uppercase type that is at least 5 points larger than, and clearly distinguishable from, the rest of the text of the waiver or release. Refer to link for requirements."},
            "clause_4h":{"strReqNo": "Requirement 11",
                  "strReqCaterory": "Signature Section",
                  "strReqDescription": "Parent or Guardian signature section is appended to the waiver including the date the form was signed."},
            "clause_4i":{"strReqNo": "Requirement 12",
                  "strReqCaterory": "Medical Authorization",
                  "strReqDescription": "Medical Treatment, Waiver and Release i. Acknowledgement of medical care to be provided by the staff"},
            "clause_6":{"strReqNo": "Requirement 13",
                  "strReqCaterory": "Applicable Jurisdiction",
                  "strReqDescription": "Checks compliance with any specific state laws or precedents governing enforceability of liability waivers."}}
            
   
      def generateWaiverSummary(self):
            '''
            Function that excute all the clauses of Camp Operator product type

            return:
            - dictFinalOutput (dict): The final clause validation results
            '''
            # Multithreading to run all clauses in parallel
            with ThreadPoolExecutor() as executor:
                  futures = []
                  # Submit each clause method to the executor
                  futures.append(executor.submit(self.validateClause3, self.dictClauseInfo, self.kValue, self.objSearchClient, self.objOpenAIClient, self.dictConfig))
                  futures.append(executor.submit(self.validateClause4a, self.dictClauseInfo, self.kValue, self.objSearchClient, self.objOpenAIClient, self.dictConfig))
                  futures.append(executor.submit(self.validateClause4b, self.dictClauseInfo, self.kValue, self.objSearchClient, self.objOpenAIClient, self.dictConfig))
                  futures.append(executor.submit(self.validateClause4c, self.dictClauseInfo, self.kValue, self.objSearchClient, self.objOpenAIClient, self.dictConfig))
                  futures.append(executor.submit(self.validateClause4d, self.dictClauseInfo, self.kValue, self.objSearchClient, self.objOpenAIClient, self.dictConfig))
                  futures.append(executor.submit(self.validateClause4g, self.dictClauseInfo, self.dictConfig))
                  futures.append(executor.submit(self.validateClause4h, self.dictClauseInfo, self.kValue, self.objSearchClient, self.objOpenAIClient, self.dictConfig))
                  futures.append(executor.submit(self.validateClause4i, self.dictClauseInfo, self.kValue, self.objSearchClient, self.objOpenAIClient, self.dictConfig))
                  futures.append(executor.submit(self.validateClause6, self.dictClauseInfo, self.kValue, self.objSearchClient, self.objOpenAIClient, self.dictConfig))

                  # Wait for all threads to complete
                  listWaiverDetailedResults = []
                  for future in futures:
                        # Fetch the result and error message (if any) from each thread result
                        # objClauseResult and objClauseError can be of string type or list type. If a clause has multiple sub-clauses, then it will be list else string type.
                        objClauseResult, objClauseError = future.result()
                        if isinstance(objClauseResult, list):
                              listWaiverDetailedResults = listWaiverDetailedResults + objClauseResult
                        else:
                              listWaiverDetailedResults.append(objClauseResult)
                        # Log errors to app insights
                        if isinstance(objClauseError, list):
                              for item in objClauseError:
                                    if item!='':
                                          print(item)
                        else:
                             if objClauseError!='':
                                   print(objClauseError) 

            # Brief View generation
            # Initialize counters
            intRequirementsNumber= len(listWaiverDetailedResults)
            intNumPassedValidation = 0
            intNumNeedsReview = 0

            # Count the number of "Passed Validation" and "Needs Review"
            for item in listWaiverDetailedResults:
                  if item["strValidationOutput"] == "Passed Validation":
                        intNumPassedValidation += 1
                  elif item["strValidationOutput"] == "Needs Review":
                        intNumNeedsReview += 1

            # Capturing Results and storing in SQL DB
            try:
                  dictData = {'db_info': {'listClauseValidationResults': listWaiverDetailedResults,
                              'product_type': self.strProductType,
                              'run_id': self.intRunID}}
                  strFunctionName = 'ClauseValidation'
                  dictResultID = saveMetadataAndValidationResults(strFunctionName, dictData, self.dictConfig)
                  dictResultID = dictResultID.decode()
                  dictResultID = json.loads(dictResultID)

                  # Logic to append results id to the final json
                  for key in dictResultID.keys(): 
                        for i in range(len(listWaiverDetailedResults)):
                              req_no = listWaiverDetailedResults[i].get('strReqNo')
                              if key == req_no:
                                    val = dictResultID.get(key)
                                    listWaiverDetailedResults[i].update({'intResultID': int(val)})
                    
            except Exception as e:
                  strErrorMessage = f"The Azure function call to save the Metadata/Clause Validation results failed with the error: " + str(e)
                  raise Exception(strErrorMessage)

            # Create a dictionary with the counts
            dictWaiverBriefResults = {
                  "intNumberOfRequirements": intRequirementsNumber,
                  "intNumberOfPassedValidation": intNumPassedValidation,
                  "intNumberOfNeedsReview": intNumNeedsReview,
                  "strWaiverFileName":self.strWaiverFileName}
            # Dictionary with the counts and final result
            dictFinalOutput={"listOverallSummary":[dictWaiverBriefResults], "listDetailedSummary":listWaiverDetailedResults}

            return dictFinalOutput
