######################################### MODULE INFORMATION ######################################### 
'''
This module acts as the node entry point for the promptflow's Data Extraction and Chunking stage.

'''
################################################# END #################################################

# Import required packages
from promptflow.core import tool
from modules.DataExtractionAndChunking import *

@tool
def nodeDataExtractionAndChunking(strWaiverFileName: str, strProductType:str, intRunID: int) -> list:
    '''
    Function to call subsequent python module which helps in parsing page level data from text extracted of the document

    Parameters: 
    - strWaiverFileName (str): file name of the document
    - strProductType (str): product type of the document
    - intRunID (int): Run Id of the current run

    return:
    - listExtractedPageData (list): List of dictionaries containing page number and text from each page
    '''
    try:
        objExtractor = dataExtraction()
        listExtractedPageData = objExtractor.getPageData(strWaiverFileName, strProductType, intRunID)
        if len(listExtractedPageData)==1 and 'AML Endpoint - ERROR -' in listExtractedPageData[0]:
            strErrorMessage = f"RunID_{str(intRunID)} - AML Endpoint - ERROR - Data extraction and chunking process has failed"
            raise Exception(strErrorMessage)
        else:
            return listExtractedPageData
    except Exception as e:
        if 'AML Endpoint - ERROR -' in str(e):
            raise Exception(str(e))
        else:
            strErrorMessage = f"RunID_{str(intRunID)} - AML Endpoint - ERROR - Data extraction and chunking process has failed due to following error - "+str(e)
            print(strErrorMessage)
            raise Exception(strErrorMessage)
