######################################### MODULE INFORMATION ######################################### 
'''
This module acts as the node entry point for the promptflow's Clause Validation stage.

'''
################################################# END #################################################

# Import required packages
from promptflow.core import tool
from modules.ClauseValidation import *

@tool
def nodeClauseValidation(strVectorIndexName: str, strProductType: str, strWaiverFileName:str, strProductTypeClassName: str, intRunID: int) -> list:
    '''
    Function to parse generate response for each Clause

    Parameters: 
    - strVectorIndexName (str): AI Search Vector index name
    - strProductType (str): Product type of the document
    - strWaiverFileName (str): file name of the document
    - strProductTypeClassName (str): module name of the product type which has all the clauses related to the product type
    - intRunID (int): Run Id of the current run

    return:
    - dictWaiverOutput (dict): Detailed output of all Clauses along with overall view
    '''
    try:
        dictWaiverOutput=generateDetailedSummary(strVectorIndexName, strProductType, strWaiverFileName, strProductTypeClassName, intRunID)
        return dictWaiverOutput
    except Exception as e:
        if 'AML Endpoint - ERROR -' in str(e):
            raise Exception(str(e))
        else:
            strErrorMessage = f"RunID_{str(intRunID)} - AML Endpoint - ERROR - Clause validation process has failed due to following error - "+str(e)
            print(strErrorMessage)
            raise Exception(strErrorMessage)
        