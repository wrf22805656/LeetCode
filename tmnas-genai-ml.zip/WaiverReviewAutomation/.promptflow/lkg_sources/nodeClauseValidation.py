from promptflow import tool
from modules.ClauseValidation import *

@tool
def clause_validation(strVectorIndexName: str, strProductType: str, strWaiverFileName:str, strProductTypeClassName: str, intRunID: int) -> list:
    '''
    Function to parse generate response for each Clause

    Parameters: 
    - strVectorIndexName (str): AI Search Vector index name
    - strProductType (str): Product type as provided by the user

    return:
    - dictWaiverOutput (dict): Detailed output of all Clauses along with overall view
    '''
    dictWaiverOutput=generateDetailedSummary(strVectorIndexName, strProductType, strWaiverFileName, strProductTypeClassName, intRunID)
    return dictWaiverOutput