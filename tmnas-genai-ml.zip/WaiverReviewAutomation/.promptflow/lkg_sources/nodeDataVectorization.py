from promptflow.core import tool
from modules.DataVectorizationAISearch import *

@tool
def data_vectorization(listExtractedPageData : list, strWaiverFileName: str, strProductType: str, intRunID: int)-> str:
    '''
    Function to parse page level data from text extracted of the document

    Parameters: 
    - file_name (str): file name of the document

    return:
    - listExtractedPageData (list): List of dictionaries containing page number and text from each page
    '''
    objVectorCreation = dataVectorization()
    strVectorIndexName = objVectorCreation.vectorization(listExtractedPageData, strWaiverFileName, strProductType, intRunID)
    if 'ERROR:' not in strVectorIndexName:
        return strVectorIndexName
    else:
        strErrorMessage = strVectorIndexName
        raise Exception(strErrorMessage)
