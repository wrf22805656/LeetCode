from promptflow.core import tool
from modules.DataExtractionAndChunking import *


@tool
def data_extraction_and_chunking(strWaiverFileName: str, strProductType:str, intRunID: int) -> list:
    '''
    Function to parse page level data from text extracted of the document

    Parameters: 
    - strWaiverFileName (str): file name of the document

    return:
    - listExtractedPageData (list): List of dictionaries containing page number and text from each page
    '''
    objExtractor = dataExtraction()
    listExtractedPageData = objExtractor.getPageData(strWaiverFileName, strProductType, intRunID)
    if len(listExtractedPageData)==1 and 'ERROR:' in listExtractedPageData[0]:
        strErrorMessage = "Data extraction and chunking process has failed with the followig error - " + listExtractedPageData[0]
        raise Exception(strErrorMessage)
    else:
        return listExtractedPageData